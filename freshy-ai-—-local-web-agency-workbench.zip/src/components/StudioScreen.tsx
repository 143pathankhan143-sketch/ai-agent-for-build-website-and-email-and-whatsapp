import { useEffect, useState } from 'react';
import { Check, Download, Monitor, RefreshCw, ShieldAlert, Smartphone, Sparkles } from 'lucide-react';
import { t } from '../shared/i18n.ts';
import type {
  AppSettings,
  Business,
  ContentLanguage,
  OutputType,
  TemplateKey,
  UiLanguage,
  WebsiteRecord,
} from '../shared/types.ts';
import { StatusText } from './StatusText.tsx';

interface StudioScreenProps {
  leads: Business[];
  websites: WebsiteRecord[];
  selectedBusinessId: number | null;
  settings: AppSettings | null;
  lang: UiLanguage;
  busy: boolean;
  onSelectBusiness: (id: number) => void;
  onGenerateWebsite: (payload: {
    business_id: number;
    template_key: TemplateKey;
    language: ContentLanguage;
    output_type: OutputType;
    use_ai: boolean;
  }) => Promise<WebsiteRecord | null>;
  onUpdateWebsite: (id: number, payload: Record<string, unknown>) => Promise<void>;
  onRefineWithAi: (id: number) => Promise<void>;
  onRunQa: (id: number) => Promise<void>;
  onApproveWebsite: (id: number) => Promise<void>;
  onPublishReview: (id: number, publicUrl: string, markPublished: boolean) => Promise<void>;
  onOpenOutreach: (businessId: number, websiteId: number) => void;
}

export function StudioScreen({
  leads,
  websites,
  selectedBusinessId,
  settings,
  lang,
  busy,
  onSelectBusiness,
  onGenerateWebsite,
  onUpdateWebsite,
  onRefineWithAi,
  onRunQa,
  onApproveWebsite,
  onPublishReview,
  onOpenOutreach,
}: StudioScreenProps) {
  const dict = t(lang);

  const [genTemplate, setGenTemplate] = useState<TemplateKey>('dental');
  const [genLang, setGenLang] = useState<ContentLanguage>('bilingual');
  const [genOutput, setGenOutput] = useState<OutputType>('html');
  const [genUseAi, setGenUseAi] = useState(false);

  const [selectedWebsiteId, setSelectedWebsiteId] = useState<number | null>(null);
  const [previewViewport, setPreviewViewport] = useState<'desktop' | 'mobile'>('desktop');
  const [previewNonce, setPreviewNonce] = useState(0);

  // Editable draft fields
  const [headline, setHeadline] = useState('');
  const [subheadline, setSubheadline] = useState('');
  const [aboutCopy, setAboutCopy] = useState('');
  const [servicesText, setServicesText] = useState('');
  const [ctaLabel, setCtaLabel] = useState('');
  const [templateKey, setTemplateKey] = useState<TemplateKey>('universal');
  const [contentLang, setContentLang] = useState<ContentLanguage>('bilingual');
  const [outputType, setOutputType] = useState<OutputType>('html');
  const [publicUrl, setPublicUrl] = useState('');

  const businessWebsites = websites.filter((w) =>
    selectedBusinessId ? w.business_id === selectedBusinessId : true
  );

  const activeWebsite =
    websites.find((w) => w.id === selectedWebsiteId) || businessWebsites[0] || websites[0] || null;

  useEffect(() => {
    if (activeWebsite) {
      setSelectedWebsiteId(activeWebsite.id);
      setHeadline(activeWebsite.headline);
      setSubheadline(activeWebsite.subheadline);
      setAboutCopy(activeWebsite.about_copy);
      setCtaLabel(activeWebsite.cta_label);
      setTemplateKey(activeWebsite.template_key);
      setContentLang(activeWebsite.language);
      setOutputType(activeWebsite.output_type);
      setPublicUrl(activeWebsite.public_url || '');
      try {
        const arr = JSON.parse(activeWebsite.services_json);
        setServicesText(Array.isArray(arr) ? arr.join('\n') : '');
      } catch {
        setServicesText('');
      }
      setPreviewNonce((n) => n + 1);
    }
  }, [activeWebsite?.id, activeWebsite?.content_hash, activeWebsite?.updated_at]);

  const handleGenerate = async () => {
    const targetBizId = selectedBusinessId || leads[0]?.id;
    if (!targetBizId) return;
    const created = await onGenerateWebsite({
      business_id: targetBizId,
      template_key: genTemplate,
      language: genLang,
      output_type: genOutput,
      use_ai: genUseAi,
    });
    if (created) {
      setSelectedWebsiteId(created.id);
      setPreviewNonce((n) => n + 1);
    }
  };

  const handleSaveChanges = async () => {
    if (!activeWebsite) return;
    const servicesArr = servicesText
      .split(/\r?\n/)
      .map((s) => s.trim())
      .filter(Boolean);
    await onUpdateWebsite(activeWebsite.id, {
      template_key: templateKey,
      language: contentLang,
      output_type: outputType,
      headline,
      subheadline,
      about_copy: aboutCopy,
      services_json: JSON.stringify(servicesArr),
      cta_label: ctaLabel,
    });
    setPreviewNonce((n) => n + 1);
  };

  const qaChecks = activeWebsite?.qa_results || [];
  const hasQaFail = qaChecks.some((c) => c.outcome === 'fail');
  const isApproved = Boolean(activeWebsite?.active_approval);

  return (
    <div className="space-y-6">
      {/* Top Generator Bar */}
      <section className="bg-white border border-slate-200 rounded-lg p-5">
        <div className="flex flex-wrap items-end gap-4">
          <div className="min-w-[210px] flex-1">
            <label className="block text-xs font-medium text-slate-700 mb-1">Business Lead</label>
            <select
              value={selectedBusinessId ?? leads[0]?.id ?? ''}
              onChange={(e) => onSelectBusiness(Number(e.target.value))}
              className="w-full px-3 py-2 text-sm border border-slate-300 rounded-md bg-white"
            >
              {leads.map((l) => (
                <option key={l.id} value={l.id}>
                  {l.name} ({l.review_status})
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">{dict.labels.templateLabel}</label>
            <select
              value={genTemplate}
              onChange={(e) => setGenTemplate(e.target.value as TemplateKey)}
              className="px-3 py-2 text-sm border border-slate-300 rounded-md bg-white"
            >
              <option value="universal">Universal Business</option>
              <option value="dental">Dental / Clinic</option>
              <option value="jewellery">Jewellery Atelier</option>
              <option value="salon">Hair & Skin Salon</option>
              <option value="restaurant">Restaurant / Bistro</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">{dict.labels.contentLanguage}</label>
            <select
              value={genLang}
              onChange={(e) => setGenLang(e.target.value as ContentLanguage)}
              className="px-3 py-2 text-sm border border-slate-300 rounded-md bg-white"
            >
              <option value="bilingual">Bilingual (EN + HI)</option>
              <option value="en">English</option>
              <option value="hi">Hindi (हिन्दी)</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">{dict.labels.outputType}</label>
            <select
              value={genOutput}
              onChange={(e) => setGenOutput(e.target.value as OutputType)}
              className="px-3 py-2 text-sm border border-slate-300 rounded-md bg-white"
            >
              <option value="html">HTML / CSS / JS</option>
              <option value="react">React / Vite</option>
            </select>
          </div>

          {settings?.ai_enabled && settings?.ai_available ? (
            <label className="inline-flex items-center gap-2 text-xs text-slate-700 py-2 cursor-pointer">
              <input
                type="checkbox"
                checked={genUseAi}
                onChange={(e) => setGenUseAi(e.target.checked)}
                className="rounded border-slate-300 text-teal-700"
              />
              <span>Use Optional AI Copy</span>
            </label>
          ) : null}

          <button
            type="button"
            disabled={busy || leads.length === 0}
            onClick={handleGenerate}
            className="px-4 py-2 text-xs font-medium bg-teal-700 text-white rounded-md hover:bg-teal-800 disabled:opacity-50 cursor-pointer whitespace-nowrap"
          >
            {dict.labels.generateDeterministic}
          </button>
        </div>
      </section>

      {/* Existing Demo Switcher */}
      {websites.length > 0 && (
        <div className="flex flex-wrap items-center justify-between gap-3 bg-white border border-slate-200 rounded-lg px-4 py-3">
          <div className="flex flex-wrap items-center gap-3 text-xs">
            <span className="font-medium text-slate-600">Demo Version:</span>
            <select
              value={activeWebsite?.id ?? ''}
              onChange={(e) => setSelectedWebsiteId(Number(e.target.value))}
              className="px-2.5 py-1.5 text-xs border border-slate-300 rounded bg-white"
            >
              {websites.map((w) => (
                <option key={w.id} value={w.id}>
                  #{w.id} · {w.business_name} · v{w.version} ({w.output_type.toUpperCase()} / {w.status})
                </option>
              ))}
            </select>
            {activeWebsite ? <StatusText status={activeWebsite.status} lang={lang} /> : null}
          </div>
          {activeWebsite ? (
            <div className="text-xs font-mono tabular-nums text-slate-500">
              Hash: {activeWebsite.content_hash.slice(0, 14)}…
            </div>
          ) : null}
        </div>
      )}

      {!activeWebsite ? (
        <div className="bg-white border border-slate-200 rounded-lg p-10 text-center text-sm text-slate-500">
          {dict.labels.emptyWebsites}
        </div>
      ) : (
        <div className="grid grid-cols-1 xl:grid-cols-12 gap-6 items-start">
          {/* Left Column: Editor + QA + Approvals */}
          <div className="xl:col-span-5 space-y-6">
            {/* Editor */}
            <section className="bg-white border border-slate-200 rounded-lg p-5 space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-slate-200">
                <h2 className="text-sm font-semibold text-slate-900">
                  {activeWebsite.business_name} · v{activeWebsite.version}
                </h2>
                {settings?.ai_enabled && settings?.ai_available ? (
                  <button
                    type="button"
                    disabled={busy}
                    onClick={() => onRefineWithAi(activeWebsite.id)}
                    className="inline-flex items-center gap-1.5 px-2.5 py-1 text-xs font-medium border border-slate-300 text-slate-700 rounded hover:bg-slate-50 cursor-pointer"
                  >
                    <Sparkles className="w-3.5 h-3.5 text-teal-700" aria-hidden="true" />
                    <span>{dict.labels.generateAiCopy}</span>
                  </button>
                ) : null}
              </div>

              <div className="grid grid-cols-3 gap-2">
                <div>
                  <label className="block text-xs text-slate-600 mb-1">Template</label>
                  <select
                    value={templateKey}
                    onChange={(e) => setTemplateKey(e.target.value as TemplateKey)}
                    className="w-full px-2 py-1.5 text-xs border border-slate-300 rounded bg-white"
                  >
                    <option value="universal">universal</option>
                    <option value="dental">dental</option>
                    <option value="jewellery">jewellery</option>
                    <option value="salon">salon</option>
                    <option value="restaurant">restaurant</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs text-slate-600 mb-1">Language</label>
                  <select
                    value={contentLang}
                    onChange={(e) => setContentLang(e.target.value as ContentLanguage)}
                    className="w-full px-2 py-1.5 text-xs border border-slate-300 rounded bg-white"
                  >
                    <option value="bilingual">bilingual</option>
                    <option value="en">en</option>
                    <option value="hi">hi</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs text-slate-600 mb-1">Output</label>
                  <select
                    value={outputType}
                    onChange={(e) => setOutputType(e.target.value as OutputType)}
                    className="w-full px-2 py-1.5 text-xs border border-slate-300 rounded bg-white"
                  >
                    <option value="html">HTML/CSS/JS</option>
                    <option value="react">React/Vite</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">{dict.labels.headline}</label>
                <input
                  type="text"
                  value={headline}
                  onChange={(e) => setHeadline(e.target.value)}
                  className="w-full px-3 py-1.5 text-sm border border-slate-300 rounded-md"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">{dict.labels.subheadline}</label>
                <input
                  type="text"
                  value={subheadline}
                  onChange={(e) => setSubheadline(e.target.value)}
                  className="w-full px-3 py-1.5 text-sm border border-slate-300 rounded-md"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">{dict.labels.aboutCopy}</label>
                <textarea
                  rows={3}
                  value={aboutCopy}
                  onChange={(e) => setAboutCopy(e.target.value)}
                  className="w-full p-2.5 text-xs border border-slate-300 rounded-md"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">{dict.labels.servicesList}</label>
                <textarea
                  rows={3}
                  value={servicesText}
                  onChange={(e) => setServicesText(e.target.value)}
                  className="w-full p-2.5 text-xs border border-slate-300 rounded-md"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">{dict.labels.ctaLabel}</label>
                <input
                  type="text"
                  value={ctaLabel}
                  onChange={(e) => setCtaLabel(e.target.value)}
                  className="w-full px-3 py-1.5 text-sm border border-slate-300 rounded-md"
                />
              </div>

              <button
                type="button"
                disabled={busy}
                onClick={handleSaveChanges}
                className="w-full py-2 text-xs font-medium bg-slate-900 text-white rounded-md hover:bg-slate-800 cursor-pointer"
              >
                {dict.labels.saveDraft}
              </button>
            </section>

            {/* Automated QA Panel */}
            <section className="bg-white border border-slate-200 rounded-lg p-5 space-y-3">
              <div className="flex items-center justify-between pb-3 border-b border-slate-200">
                <h3 className="text-sm font-semibold text-slate-900">{dict.labels.qaChecklist}</h3>
                <button
                  type="button"
                  disabled={busy}
                  onClick={() => onRunQa(activeWebsite.id)}
                  className="inline-flex items-center gap-1.5 px-2.5 py-1 text-xs font-medium border border-slate-300 rounded hover:bg-slate-50 cursor-pointer"
                >
                  <RefreshCw className="w-3 h-3" aria-hidden="true" />
                  <span>{dict.labels.runQa}</span>
                </button>
              </div>
              <div className="divide-y divide-slate-100">
                {qaChecks.map((chk) => (
                  <div key={chk.id} className="py-2 text-xs">
                    <div className="flex items-center justify-between gap-2">
                      <span className="font-mono text-slate-800">{chk.check_name}</span>
                      <StatusText status={chk.outcome} lang={lang} />
                    </div>
                    <p className="mt-0.5 text-slate-600">{chk.details}</p>
                  </div>
                ))}
              </div>
            </section>

            {/* Approval + Publish Review + ZIP Export */}
            <section className="bg-white border border-slate-200 rounded-lg p-5 space-y-4">
              <div className="flex items-center justify-between pb-3 border-b border-slate-200">
                <h3 className="text-sm font-semibold text-slate-900">{dict.labels.approvalGate}</h3>
                <StatusText status={isApproved ? 'approved' : activeWebsite.status} lang={lang} />
              </div>

              <div className="text-xs text-slate-600 space-y-1">
                <div>
                  Snapshot hash: <span className="font-mono text-slate-900">{activeWebsite.content_hash.slice(0, 20)}…</span>
                </div>
                {activeWebsite.active_approval ? (
                  <div className="text-emerald-700">
                    Approved at {new Date(activeWebsite.active_approval.approved_at).toLocaleString()}
                  </div>
                ) : (
                  <div className="text-amber-700 flex items-center gap-1.5">
                    <ShieldAlert className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
                    <span>Not approved for current content hash.</span>
                  </div>
                )}
              </div>

              <div className="flex flex-wrap gap-2">
                <button
                  type="button"
                  disabled={busy || hasQaFail}
                  onClick={() => onApproveWebsite(activeWebsite.id)}
                  className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium bg-teal-700 text-white rounded-md hover:bg-teal-800 disabled:opacity-45 cursor-pointer"
                >
                  <Check className="w-3.5 h-3.5" aria-hidden="true" />
                  <span>{dict.labels.approveWebsite}</span>
                </button>

                <a
                  href={`/api/websites/${activeWebsite.id}/export-zip`}
                  className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium border border-slate-300 text-slate-700 rounded-md hover:bg-slate-50"
                >
                  <Download className="w-3.5 h-3.5" aria-hidden="true" />
                  <span>
                    {dict.labels.exportZip} ({activeWebsite.output_type.toUpperCase()})
                  </span>
                </a>
              </div>

              {/* Separate Publish Gate */}
              <div className="pt-4 border-t border-slate-200 space-y-2">
                <div className="text-xs font-semibold text-slate-800">
                  Separate Publish Review Gate (Optional Hosting URL)
                </div>
                <input
                  type="url"
                  value={publicUrl}
                  onChange={(e) => setPublicUrl(e.target.value)}
                  placeholder="https://demo-hosting.example.org/preview"
                  className="w-full px-3 py-1.5 text-xs border border-slate-300 rounded"
                />
                <div className="flex flex-wrap gap-2">
                  <button
                    type="button"
                    disabled={busy || !isApproved}
                    onClick={() => onPublishReview(activeWebsite.id, publicUrl, true)}
                    className="px-3 py-1.5 text-xs font-medium border border-slate-300 text-slate-700 rounded hover:bg-slate-50 disabled:opacity-45 cursor-pointer"
                  >
                    Approve Public URL
                  </button>
                  <button
                    type="button"
                    disabled={!isApproved}
                    onClick={() => onOpenOutreach(activeWebsite.business_id, activeWebsite.id)}
                    className="px-3 py-1.5 text-xs font-medium text-teal-700 border border-teal-700/30 rounded hover:bg-teal-50 disabled:opacity-45 cursor-pointer"
                  >
                    Create Outreach Draft →
                  </button>
                </div>
              </div>
            </section>
          </div>

          {/* Right Column: Sandboxed Preview */}
          <section className="xl:col-span-7 bg-white border border-slate-200 rounded-lg overflow-hidden">
            <div className="px-5 py-3 border-b border-slate-200 flex items-center justify-between gap-4">
              <div>
                <h3 className="text-sm font-semibold text-slate-900">{dict.labels.previewPanel}</h3>
                <p className="text-xs text-slate-500">
                  Robots <span className="font-mono">noindex</span> · Unofficial banner · Disabled inquiry form
                </p>
              </div>
              <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-md">
                <button
                  type="button"
                  onClick={() => setPreviewViewport('desktop')}
                  className={`inline-flex items-center gap-1 px-2.5 py-1 text-xs rounded cursor-pointer ${
                    previewViewport === 'desktop' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600'
                  }`}
                >
                  <Monitor className="w-3.5 h-3.5" aria-hidden="true" />
                  <span>Desktop</span>
                </button>
                <button
                  type="button"
                  onClick={() => setPreviewViewport('mobile')}
                  className={`inline-flex items-center gap-1 px-2.5 py-1 text-xs rounded cursor-pointer ${
                    previewViewport === 'mobile' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600'
                  }`}
                >
                  <Smartphone className="w-3.5 h-3.5" aria-hidden="true" />
                  <span>375px</span>
                </button>
              </div>
            </div>

            <div className="bg-slate-100 p-4 flex justify-center">
              <iframe
                key={`${activeWebsite.id}-${previewNonce}`}
                title="Concept website demo preview"
                src={`/api/websites/${activeWebsite.id}/preview?v=${previewNonce}`}
                sandbox=""
                className={`bg-white border border-slate-200 rounded transition-all ${
                  previewViewport === 'mobile' ? 'w-[375px] h-[680px]' : 'w-full h-[760px]'
                }`}
              />
            </div>
          </section>
        </div>
      )}
    </div>
  );
}
