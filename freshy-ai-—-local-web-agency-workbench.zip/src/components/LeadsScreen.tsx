import { useMemo, useState, type ChangeEvent, type FormEvent } from 'react';
import { Download, Plus, Search, Upload } from 'lucide-react';
import { t } from '../shared/i18n.ts';
import type { Business, Campaign, LeadStatus, UiLanguage } from '../shared/types.ts';
import { StatusText } from './StatusText.tsx';

interface LeadsScreenProps {
  leads: Business[];
  campaigns: Campaign[];
  selectedCampaignId: number | null;
  lang: UiLanguage;
  busy: boolean;
  onSelectCampaignFilter: (campaignId: number | null) => void;
  onAddLead: (payload: Record<string, unknown>) => Promise<void>;
  onImportCsv: (csvText: string, campaignId: number | null) => Promise<void>;
  onUpdateStatus: (id: number, status: LeadStatus, purgePii?: boolean) => Promise<void>;
  onOpenResearch: (businessId: number) => void;
  onOpenStudio: (businessId: number) => void;
}

const STATUS_TABS: Array<{ key: 'all' | LeadStatus; labelEn: string; labelHi: string }> = [
  { key: 'all', labelEn: 'All', labelHi: 'सभी' },
  { key: 'new', labelEn: 'New', labelHi: 'नया' },
  { key: 'researched', labelEn: 'Researched', labelHi: 'रिसर्च पूर्ण' },
  { key: 'review_required', labelEn: 'Review Required', labelHi: 'समीक्षा आवश्यक' },
  { key: 'verified', labelEn: 'Verified', labelHi: 'सत्यापित' },
  { key: 'rejected', labelEn: 'Rejected', labelHi: 'अस्वीकृत' },
];

export function LeadsScreen({
  leads,
  campaigns,
  selectedCampaignId,
  lang,
  busy,
  onSelectCampaignFilter,
  onAddLead,
  onImportCsv,
  onUpdateStatus,
  onOpenResearch,
  onOpenStudio,
}: LeadsScreenProps) {
  const dict = t(lang);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | LeadStatus>('all');
  const [showAddForm, setShowAddForm] = useState(false);
  const [showCsvImport, setShowCsvImport] = useState(false);

  // Manual form state
  const [name, setName] = useState('');
  const [category, setCategory] = useState('Dental Clinic');
  const [locality, setLocality] = useState('');
  const [address, setAddress] = useState('');
  const [officialUrl, setOfficialUrl] = useState('');
  const [sourceUrl, setSourceUrl] = useState('');
  const [permittedUse, setPermittedUse] = useState('Manually reviewed public listing');
  const [email, setEmail] = useState('');
  const [campaignId, setCampaignId] = useState<string>(
    selectedCampaignId ? String(selectedCampaignId) : campaigns[0] ? String(campaigns[0].id) : ''
  );

  // CSV state
  const [csvText, setCsvText] = useState(
    'name,category,locality,address,official_url,email,source_url\nLotus Dental Care (Sample),Dental Clinic,"Malviya Nagar, Jaipur","Block B, Malviya Nagar",https://example.org/lotus,,https://example.org/lotus'
  );

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return leads.filter((lead) => {
      if (statusFilter !== 'all' && lead.review_status !== statusFilter) return false;
      if (selectedCampaignId && lead.campaign_id !== selectedCampaignId) return false;
      if (!q) return true;
      return (
        lead.name.toLowerCase().includes(q) ||
        lead.locality.toLowerCase().includes(q) ||
        lead.category.toLowerCase().includes(q)
      );
    });
  }, [leads, search, statusFilter, selectedCampaignId]);

  const handleManualSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !category.trim() || !locality.trim()) return;
    await onAddLead({
      campaign_id: campaignId ? Number(campaignId) : null,
      name: name.trim(),
      category: category.trim(),
      locality: locality.trim(),
      address: address.trim(),
      official_url: officialUrl.trim(),
      source_url: sourceUrl.trim(),
      permitted_use_notes: permittedUse.trim(),
      email: email.trim(),
    });
    setName('');
    setAddress('');
    setOfficialUrl('');
    setSourceUrl('');
    setEmail('');
    setShowAddForm(false);
  };

  const handleCsvFile = (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') setCsvText(reader.result);
    };
    reader.readAsText(file);
  };

  return (
    <div className="space-y-6">
      {/* Toolbar */}
      <div className="bg-white border border-slate-200 rounded-lg p-4 flex flex-wrap items-center justify-between gap-4">
        <div className="flex flex-wrap items-center gap-3 flex-1 min-w-[260px]">
          <div className="relative flex-1 min-w-[220px] max-w-sm">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" aria-hidden="true" />
            <input
              type="search"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder={dict.labels.searchLeads}
              className="w-full pl-9 pr-3 py-2 text-sm border border-slate-300 rounded-md focus:outline-none focus:border-teal-700"
            />
          </div>

          <select
            aria-label={dict.labels.allCampaigns}
            value={selectedCampaignId ? String(selectedCampaignId) : ''}
            onChange={(e) => onSelectCampaignFilter(e.target.value ? Number(e.target.value) : null)}
            className="px-3 py-2 text-sm border border-slate-300 rounded-md bg-white focus:outline-none focus:border-teal-700"
          >
            <option value="">{dict.labels.allCampaigns}</option>
            {campaigns.map((c) => (
              <option key={c.id} value={c.id}>
                {c.name}
              </option>
            ))}
          </select>
        </div>

        <div className="flex flex-wrap items-center gap-2 shrink-0">
          <button
            type="button"
            onClick={() => {
              setShowAddForm((v) => !v);
              setShowCsvImport(false);
            }}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium bg-teal-700 text-white rounded-md hover:bg-teal-800 cursor-pointer whitespace-nowrap"
          >
            <Plus className="w-3.5 h-3.5" aria-hidden="true" />
            <span>{dict.labels.addLead}</span>
          </button>

          <button
            type="button"
            onClick={() => {
              setShowCsvImport((v) => !v);
              setShowAddForm(false);
            }}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium border border-slate-300 text-slate-700 rounded-md hover:bg-slate-50 cursor-pointer whitespace-nowrap"
          >
            <Upload className="w-3.5 h-3.5" aria-hidden="true" />
            <span>{dict.labels.importCsv}</span>
          </button>

          <a
            href="/api/leads/export-csv"
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium border border-slate-300 text-slate-700 rounded-md hover:bg-slate-50 whitespace-nowrap"
          >
            <Download className="w-3.5 h-3.5" aria-hidden="true" />
            <span>{dict.labels.exportCsv}</span>
          </a>
        </div>
      </div>

      {/* Segmented Status Tabs */}
      <div className="flex flex-wrap items-center gap-1 p-1 bg-slate-200/70 rounded-lg w-fit">
        {STATUS_TABS.map((tab) => (
          <button
            key={tab.key}
            type="button"
            onClick={() => setStatusFilter(tab.key)}
            className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap cursor-pointer ${
              statusFilter === tab.key ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            {lang === 'hi' ? tab.labelHi : tab.labelEn}
          </button>
        ))}
      </div>

      {/* Add Lead Form Drawer */}
      {showAddForm && (
        <section className="bg-white border border-slate-200 rounded-lg p-6">
          <h3 className="text-sm font-semibold text-slate-900 pb-3 border-b border-slate-200">
            {dict.labels.addLead}
          </h3>
          <form onSubmit={handleManualSubmit} className="mt-4 grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">{dict.labels.businessName} *</label>
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-md"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">{dict.labels.category} *</label>
              <input
                type="text"
                required
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-md"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">{dict.labels.locality} *</label>
              <input
                type="text"
                required
                value={locality}
                onChange={(e) => setLocality(e.target.value)}
                placeholder="e.g. Vaishali Nagar, Jaipur"
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-md"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">{dict.labels.address}</label>
              <input
                type="text"
                value={address}
                onChange={(e) => setAddress(e.target.value)}
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-md"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">{dict.labels.officialUrl}</label>
              <input
                type="url"
                value={officialUrl}
                onChange={(e) => setOfficialUrl(e.target.value)}
                placeholder="https://..."
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-md"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">{dict.labels.sourceUrl}</label>
              <input
                type="url"
                value={sourceUrl}
                onChange={(e) => setSourceUrl(e.target.value)}
                placeholder="https://..."
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-md"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                {lang === 'hi' ? 'सार्वजनिक ईमेल (वैकल्पिक)' : 'Public Email (Leave empty if unknown)'}
              </label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-md"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">{dict.labels.permittedUse}</label>
              <input
                type="text"
                value={permittedUse}
                onChange={(e) => setPermittedUse(e.target.value)}
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-md"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Campaign</label>
              <select
                value={campaignId}
                onChange={(e) => setCampaignId(e.target.value)}
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-md bg-white"
              >
                <option value="">Unassigned</option>
                {campaigns.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name}
                  </option>
                ))}
              </select>
            </div>
            <div className="md:col-span-3 flex items-center gap-3 pt-2">
              <button
                type="submit"
                disabled={busy}
                className="px-4 py-2 text-xs font-medium bg-teal-700 text-white rounded-md hover:bg-teal-800 cursor-pointer"
              >
                {dict.labels.addLead}
              </button>
              <button
                type="button"
                onClick={() => setShowAddForm(false)}
                className="px-4 py-2 text-xs font-medium border border-slate-300 text-slate-700 rounded-md hover:bg-slate-50 cursor-pointer"
              >
                Cancel
              </button>
            </div>
          </form>
        </section>
      )}

      {/* CSV Import Drawer */}
      {showCsvImport && (
        <section className="bg-white border border-slate-200 rounded-lg p-6 space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-4 pb-3 border-b border-slate-200">
            <div>
              <h3 className="text-sm font-semibold text-slate-900">{dict.labels.importCsv}</h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Required columns: <span className="font-mono">name,category,locality</span>. Optional:{' '}
                <span className="font-mono">address,official_url,email,source_url</span>. Duplicates are flagged for
                manual review rather than auto-merged.
              </p>
            </div>
            <label className="px-3 py-1.5 text-xs font-medium border border-slate-300 text-slate-700 rounded-md hover:bg-slate-50 cursor-pointer">
              Upload .csv file
              <input type="file" accept=".csv,text/csv" onChange={handleCsvFile} className="sr-only" />
            </label>
          </div>
          <textarea
            rows={5}
            value={csvText}
            onChange={(e) => setCsvText(e.target.value)}
            className="w-full p-3 text-xs font-mono border border-slate-300 rounded-md"
          />
          <div className="flex items-center gap-3">
            <button
              type="button"
              disabled={busy}
              onClick={async () => {
                await onImportCsv(csvText, selectedCampaignId || (campaigns[0]?.id ?? null));
                setShowCsvImport(false);
              }}
              className="px-4 py-2 text-xs font-medium bg-teal-700 text-white rounded-md hover:bg-teal-800 cursor-pointer"
            >
              {dict.labels.importCsv}
            </button>
            <button
              type="button"
              onClick={() => setShowCsvImport(false)}
              className="px-4 py-2 text-xs font-medium border border-slate-300 text-slate-700 rounded-md hover:bg-slate-50 cursor-pointer"
            >
              Cancel
            </button>
          </div>
        </section>
      )}

      {/* Leads Table */}
      <section className="bg-white border border-slate-200 rounded-lg overflow-hidden">
        {filtered.length === 0 ? (
          <div className="p-8 text-center space-y-3">
            <p className="text-sm text-slate-600 max-w-md mx-auto">{dict.labels.emptyLeads}</p>
            <button
              type="button"
              onClick={() => setShowAddForm(true)}
              className="px-4 py-2 text-xs font-medium bg-teal-700 text-white rounded-md hover:bg-teal-800 cursor-pointer"
            >
              {dict.labels.addLead}
            </button>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-200 text-xs text-slate-500 font-medium bg-slate-50/70">
                  <th className="py-3 px-5">{dict.labels.businessName}</th>
                  <th className="py-3 px-4">{dict.labels.locality}</th>
                  <th className="py-3 px-4">Email</th>
                  <th className="py-3 px-4">{dict.labels.reviewStatus}</th>
                  <th className="py-3 px-4 text-right">Demos</th>
                  <th className="py-3 px-5 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-xs">
                {filtered.map((lead) => (
                  <tr key={lead.id} className="hover:bg-slate-50/70">
                    <td className="py-3 px-5">
                      <div className="font-medium text-slate-900 text-sm">{lead.name}</div>
                      <div className="text-xs text-slate-500 flex flex-wrap items-center gap-1.5 mt-0.5">
                        <span>{lead.category}</span>
                        {lead.campaign_name ? (
                          <>
                            <span aria-hidden="true">·</span>
                            <span>{lead.campaign_name}</span>
                          </>
                        ) : null}
                      </div>
                      {lead.notes && lead.notes.toLowerCase().includes('duplicate') ? (
                        <div className="mt-1 text-xs text-amber-700">{lead.notes}</div>
                      ) : null}
                    </td>
                    <td className="py-3 px-4 text-slate-700">{lead.locality}</td>
                    <td className="py-3 px-4">
                      {lead.primary_email ? (
                        <div>
                          <span className="font-mono text-slate-800">{lead.primary_email}</span>
                          <div className="mt-0.5">
                            <StatusText status={lead.suppressed ? 'suppressed' : lead.email_status || 'unknown'} lang={lang} />
                          </div>
                        </div>
                      ) : (
                        <StatusText status="unknown" lang={lang} />
                      )}
                    </td>
                    <td className="py-3 px-4">
                      <StatusText status={lead.review_status} lang={lang} />
                    </td>
                    <td className="py-3 px-4 text-right font-mono tabular-nums text-slate-700">
                      {lead.website_count ?? 0}
                    </td>
                    <td className="py-3 px-5 text-right">
                      <div className="inline-flex items-center gap-2 justify-end">
                        <button
                          type="button"
                          onClick={() => onOpenResearch(lead.id)}
                          className="px-2.5 py-1.5 text-xs font-medium border border-slate-300 text-slate-700 rounded hover:bg-slate-50 cursor-pointer whitespace-nowrap"
                        >
                          {dict.labels.openResearch}
                        </button>
                        <button
                          type="button"
                          onClick={() => onOpenStudio(lead.id)}
                          className="px-2.5 py-1.5 text-xs font-medium bg-teal-700 text-white rounded hover:bg-teal-800 cursor-pointer whitespace-nowrap"
                        >
                          {dict.labels.openStudio}
                        </button>
                        {lead.review_status !== 'rejected' ? (
                          <button
                            type="button"
                            disabled={busy}
                            onClick={() => onUpdateStatus(lead.id, 'rejected', true)}
                            className="px-2.5 py-1.5 text-xs font-medium text-red-700 border border-red-200 rounded hover:bg-red-50 cursor-pointer whitespace-nowrap"
                            title="Reject lead and purge unnecessary contact PII"
                          >
                            {dict.labels.reject}
                          </button>
                        ) : null}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>
    </div>
  );
}
