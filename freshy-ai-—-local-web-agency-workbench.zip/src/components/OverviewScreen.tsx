import { ArrowRight, Play, RotateCcw } from 'lucide-react';
import { t, type ScreenId } from '../shared/i18n.ts';
import type { OverviewSummary, UiLanguage } from '../shared/types.ts';
import { StatusText } from './StatusText.tsx';

interface OverviewScreenProps {
  overview: OverviewSummary | null;
  lang: UiLanguage;
  busy: boolean;
  onNavigate: (screen: ScreenId) => void;
  onResetTrial: () => void;
  onRunNextTask: () => void;
}

export function OverviewScreen({
  overview,
  lang,
  busy,
  onNavigate,
  onResetTrial,
  onRunNextTask,
}: OverviewScreenProps) {
  const dict = t(lang);

  if (!overview) {
    return (
      <div className="space-y-6">
        <div className="grid grid-cols-2 lg:grid-cols-6 gap-4">
          {Array.from({ length: 6 }).map((_, i) => (
            <div key={i} className="h-24 bg-white border border-slate-200 rounded-lg animate-pulse" />
          ))}
        </div>
      </div>
    );
  }

  const kpis = [
    { label: dict.labels.totalLeads, value: overview.leads_total, action: () => onNavigate('leads') },
    { label: dict.labels.verifiedLeads, value: overview.leads_verified, action: () => onNavigate('leads') },
    { label: dict.labels.demosToReview, value: overview.websites_needing_review, action: () => onNavigate('studio') },
    {
      label: dict.labels.awaitingApproval,
      value: overview.messages_awaiting_approval,
      action: () => onNavigate('outreach'),
    },
    { label: dict.labels.suppressions, value: overview.suppressions_count, action: () => onNavigate('activity') },
    { label: dict.labels.failedJobs, value: overview.tasks_failed, action: () => onNavigate('activity') },
  ];

  const trialChecklist =
    lang === 'hi'
      ? [
          '1. स्थानीय टेस्ट कैंपेन बनाएँ (Section 9 Trial पहले से लोड है)',
          '2. 3 काल्पनिक लीड्स देखें (असली संपर्क खाली या example.org पर)',
          '3. "Sample Dental Studio" से HTML डेमो बनाएँ',
          '4. QA पैनल में मिसिंग ईमेल चेतावनी सत्यापित करें',
          '5. वेबसाइट अप्रूव करें, फिर एडिट करके अप्रूवल रीसेट जाँचें',
          '6. आउटरीच ड्राफ्ट बनाएँ और खाली प्राप्तकर्ता ब्लॉक जाँचें',
          '7. ऑप्ट-आउट रिकॉर्ड जोड़कर अगला ड्राफ्ट/सेंड ब्लॉक सत्यापित करें',
          '8. Settings में ZIP एक्सपोर्ट और JSON बैकअप रीस्टोर टेस्ट करें',
        ]
      : [
          '1. Inspect local test campaign (Section 9 Trial preloaded)',
          '2. Review 3 fictional leads (Sample Dental Studio missing email)',
          '3. Generate HTML demo for Sample Dental Studio in Studio',
          '4. Verify QA flags missing email cleanly',
          '5. Approve website, edit copy, confirm prior approval resets',
          '6. Create outreach draft; confirm empty recipient stays blocked',
          '7. Record opt-out suppression and confirm follow-up/send blocks',
          '8. Download ZIP package and test JSON backup export/restore',
        ];

  return (
    <div className="space-y-8">
      {/* KPI Grid */}
      <section aria-label="Pipeline metrics">
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
          {kpis.map((item) => (
            <button
              key={item.label}
              type="button"
              onClick={item.action}
              className="text-left bg-white border border-slate-200 rounded-lg p-4 hover:border-teal-700/50 transition-colors cursor-pointer"
            >
              <div className="text-xs text-slate-500 truncate">{item.label}</div>
              <div className="mt-2 text-2xl font-semibold text-slate-900 font-mono tabular-nums">
                {item.value}
              </div>
            </button>
          ))}
        </div>
      </section>

      {/* Main Split: Active Campaign + Section 9 Guided Trial */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
        <section className="lg:col-span-5 bg-white border border-slate-200 rounded-lg p-6 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between gap-4 pb-4 border-b border-slate-200">
              <h2 className="text-base font-semibold text-slate-900">{dict.labels.activeCampaign}</h2>
              {overview.active_campaign ? (
                <StatusText status={overview.active_campaign.status} lang={lang} />
              ) : null}
            </div>
            {overview.active_campaign ? (
              <div className="mt-4 space-y-3 text-sm">
                <div className="font-medium text-slate-900">{overview.active_campaign.name}</div>
                <div className="text-xs text-slate-500 flex flex-wrap items-center gap-2">
                  <span>{overview.active_campaign.area}</span>
                  <span aria-hidden="true">·</span>
                  <span>{overview.active_campaign.category}</span>
                  <span aria-hidden="true">·</span>
                  <span className="font-mono tabular-nums">
                    Max {overview.active_campaign.max_leads}
                  </span>
                  <span aria-hidden="true">·</span>
                  <span className="uppercase font-mono">{overview.active_campaign.output_type}</span>
                </div>
                <div className="pt-3 border-t border-slate-100 grid grid-cols-2 gap-3 text-xs">
                  <div>
                    <span className="text-slate-500 block">
                      {lang === 'hi' ? 'स्वीकृत डेमो' : 'Approved Demos'}
                    </span>
                    <span className="font-mono tabular-nums font-semibold text-slate-900 text-sm">
                      {overview.websites_approved} / {overview.websites_total}
                    </span>
                  </div>
                  <div>
                    <span className="text-slate-500 block">
                      {lang === 'hi' ? 'कतार में कार्य' : 'Queued Tasks'}
                    </span>
                    <span className="font-mono tabular-nums font-semibold text-slate-900 text-sm">
                      {overview.tasks_queued}
                    </span>
                  </div>
                </div>
              </div>
            ) : (
              <p className="mt-4 text-sm text-slate-500">
                {lang === 'hi' ? 'कोई सक्रिय कैंपेन नहीं है।' : 'No campaign configured yet.'}
              </p>
            )}
          </div>

          <div className="mt-6 pt-4 border-t border-slate-200 flex flex-wrap items-center gap-3">
            <button
              type="button"
              onClick={onRunNextTask}
              disabled={busy || overview.tasks_queued === 0}
              className="inline-flex items-center gap-2 px-4 py-2 text-xs font-medium bg-teal-700 text-white rounded-md hover:bg-teal-800 disabled:opacity-45 cursor-pointer whitespace-nowrap"
            >
              <Play className="w-3.5 h-3.5" aria-hidden="true" />
              <span>{dict.labels.runNextTask}</span>
            </button>
            <button
              type="button"
              onClick={() => onNavigate('leads')}
              className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-medium border border-slate-300 text-slate-700 rounded-md hover:bg-slate-50 cursor-pointer whitespace-nowrap"
            >
              <span>{dict.screens.leads}</span>
              <ArrowRight className="w-3.5 h-3.5" aria-hidden="true" />
            </button>
          </div>
        </section>

        <section className="lg:col-span-7 bg-white border border-slate-200 rounded-lg p-6 flex flex-col justify-between">
          <div>
            <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-slate-200">
              <div>
                <h2 className="text-base font-semibold text-slate-900">{dict.labels.quickTrialTitle}</h2>
                <p className="mt-1 text-xs text-slate-500">{dict.labels.quickTrialDesc}</p>
              </div>
              <button
                type="button"
                onClick={onResetTrial}
                disabled={busy}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium border border-slate-300 text-slate-700 rounded-md hover:bg-slate-50 cursor-pointer whitespace-nowrap shrink-0"
              >
                <RotateCcw className="w-3.5 h-3.5" aria-hidden="true" />
                <span>{dict.resetTrialCta}</span>
              </button>
            </div>

            <ol className="mt-4 grid grid-cols-1 sm:grid-cols-2 gap-x-6 gap-y-2 text-xs text-slate-700">
              {trialChecklist.map((step) => (
                <li key={step} className="py-1 border-b border-slate-100 last:border-b-0">
                  {step}
                </li>
              ))}
            </ol>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-100 flex flex-wrap items-center gap-3 text-xs">
            <button
              type="button"
              onClick={() => onNavigate('studio')}
              className="text-teal-700 font-medium hover:underline cursor-pointer"
            >
              {dict.screens.studio} →
            </button>
            <span className="text-slate-300" aria-hidden="true">|</span>
            <button
              type="button"
              onClick={() => onNavigate('outreach')}
              className="text-teal-700 font-medium hover:underline cursor-pointer"
            >
              {dict.screens.outreach} →
            </button>
            <span className="text-slate-300" aria-hidden="true">|</span>
            <button
              type="button"
              onClick={() => onNavigate('settings')}
              className="text-teal-700 font-medium hover:underline cursor-pointer"
            >
              {dict.screens.settings} →
            </button>
          </div>
        </section>
      </div>

      {/* Recent Audit Activity */}
      <section className="bg-white border border-slate-200 rounded-lg">
        <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between">
          <h2 className="text-base font-semibold text-slate-900">
            {lang === 'hi' ? 'ताज़ा ऑडिट गतिविधि' : 'Recent Audit Events'}
          </h2>
          <button
            type="button"
            onClick={() => onNavigate('activity')}
            className="text-xs font-medium text-teal-700 hover:underline cursor-pointer"
          >
            {lang === 'hi' ? 'सभी देखें' : 'View all'}
          </button>
        </div>
        {overview.recent_audit.length === 0 ? (
          <div className="p-6 text-sm text-slate-500">{dict.labels.emptyAudit}</div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-200 text-xs text-slate-500 font-medium">
                  <th className="py-2.5 px-6">Action</th>
                  <th className="py-2.5 px-4">Entity</th>
                  <th className="py-2.5 px-4">Actor</th>
                  <th className="py-2.5 px-6 text-right">Timestamp</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-xs">
                {overview.recent_audit.slice(0, 8).map((ev) => (
                  <tr key={ev.id} className="hover:bg-slate-50/70">
                    <td className="py-2.5 px-6 font-medium text-slate-900">{ev.action}</td>
                    <td className="py-2.5 px-4 font-mono tabular-nums text-slate-600">
                      {ev.entity_type} #{ev.entity_id}
                    </td>
                    <td className="py-2.5 px-4 text-slate-600">{ev.actor}</td>
                    <td className="py-2.5 px-6 text-right font-mono tabular-nums text-slate-500">
                      {new Date(ev.created_at).toLocaleString()}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>
    </div>
  );
}
