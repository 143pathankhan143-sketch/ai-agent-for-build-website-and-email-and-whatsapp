import { useState, type FormEvent } from 'react';
import { Globe, ShieldCheck } from 'lucide-react';
import { t } from '../shared/i18n.ts';
import type {
  Business,
  ContactChannel,
  ContactRecord,
  FactRecord,
  LeadStatus,
  SourceRecord,
  UiLanguage,
  VerificationStatus,
} from '../shared/types.ts';
import { StatusText } from './StatusText.tsx';

interface ResearchScreenProps {
  leads: Business[];
  selectedLeadId: number | null;
  detail: {
    business: Business;
    sources: SourceRecord[];
    facts: FactRecord[];
    contacts: ContactRecord[];
  } | null;
  lang: UiLanguage;
  busy: boolean;
  onSelectLead: (id: number) => void;
  onUpdateLeadStatus: (id: number, status: LeadStatus) => Promise<void>;
  onFetchOfficialUrl: (businessId: number, url: string) => Promise<void>;
  onAddSource: (businessId: number, url: string, notes: string) => Promise<void>;
  onAddFact: (businessId: number, payload: Record<string, unknown>) => Promise<void>;
  onUpdateFact: (factId: number, payload: Record<string, unknown>) => Promise<void>;
  onAddContact: (businessId: number, payload: Record<string, unknown>) => Promise<void>;
  onUpdateContact: (contactId: number, payload: Record<string, unknown>) => Promise<void>;
  onAddPermission: (contactId: number, evidence: string) => Promise<void>;
  onOpenStudio: (businessId: number) => void;
}

export function ResearchScreen({
  leads,
  selectedLeadId,
  detail,
  lang,
  busy,
  onSelectLead,
  onUpdateLeadStatus,
  onFetchOfficialUrl,
  onAddSource,
  onAddFact,
  onUpdateFact,
  onAddContact,
  onUpdateContact,
  onAddPermission,
  onOpenStudio,
}: ResearchScreenProps) {
  const dict = t(lang);

  const [fetchUrl, setFetchUrl] = useState('');
  const [srcUrl, setSrcUrl] = useState('');
  const [srcNotes, setSrcNotes] = useState('');
  const [factField, setFactField] = useState('services');
  const [factValue, setFactValue] = useState('');
  const [factSourceId, setFactSourceId] = useState('');

  const [contactChannel, setContactChannel] = useState<ContactChannel>('email');
  const [contactValue, setContactValue] = useState('');
  const [contactStatus, setContactStatus] = useState<VerificationStatus>('verified');
  const [permEvidence, setPermEvidence] = useState('');

  const [editingFactId, setEditingFactId] = useState<number | null>(null);
  const [editingFactVal, setEditingFactVal] = useState('');

  const business = detail?.business;

  const handleFetch = async (e: FormEvent) => {
    e.preventDefault();
    if (!business) return;
    await onFetchOfficialUrl(business.id, fetchUrl.trim() || business.official_url);
  };

  const handleAddSource = async (e: FormEvent) => {
    e.preventDefault();
    if (!business || !srcUrl.trim()) return;
    await onAddSource(business.id, srcUrl.trim(), srcNotes.trim());
    setSrcUrl('');
    setSrcNotes('');
  };

  const handleAddFact = async (e: FormEvent) => {
    e.preventDefault();
    if (!business || !factField.trim()) return;
    await onAddFact(business.id, {
      field_name: factField.trim(),
      value: factValue.trim(),
      source_id: factSourceId ? Number(factSourceId) : detail?.sources[0]?.id ?? null,
      verification_status: 'unverified',
      confidence: 'medium',
    });
    setFactValue('');
  };

  const handleAddContact = async (e: FormEvent) => {
    e.preventDefault();
    if (!business) return;
    await onAddContact(business.id, {
      channel: contactChannel,
      value: contactValue.trim(),
      source_id: detail?.sources[0]?.id ?? null,
      verification_status: contactValue.trim() ? contactStatus : 'unknown',
      permission_evidence: permEvidence.trim(),
    });
    setContactValue('');
    setPermEvidence('');
  };

  return (
    <div className="space-y-6">
      {/* Selector & Status Header */}
      <div className="bg-white border border-slate-200 rounded-lg p-5 flex flex-wrap items-center justify-between gap-4">
        <div className="flex flex-wrap items-center gap-3">
          <label htmlFor="research-lead-select" className="text-xs font-medium text-slate-600">
            Lead:
          </label>
          <select
            id="research-lead-select"
            value={selectedLeadId ?? ''}
            onChange={(e) => onSelectLead(Number(e.target.value))}
            className="px-3 py-2 text-sm border border-slate-300 rounded-md bg-white min-w-[260px]"
          >
            {leads.map((l) => (
              <option key={l.id} value={l.id}>
                {l.name} ({l.locality})
              </option>
            ))}
          </select>
          {business ? <StatusText status={business.review_status} lang={lang} /> : null}
        </div>

        {business ? (
          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              disabled={busy}
              onClick={() => onUpdateLeadStatus(business.id, 'verified')}
              className="px-3 py-1.5 text-xs font-medium border border-emerald-300 text-emerald-800 rounded hover:bg-emerald-50 cursor-pointer whitespace-nowrap"
            >
              {dict.labels.verify}
            </button>
            <button
              type="button"
              disabled={busy}
              onClick={() => onUpdateLeadStatus(business.id, 'review_required')}
              className="px-3 py-1.5 text-xs font-medium border border-amber-300 text-amber-800 rounded hover:bg-amber-50 cursor-pointer whitespace-nowrap"
            >
              {dict.statuses.review_required}
            </button>
            <button
              type="button"
              onClick={() => onOpenStudio(business.id)}
              className="px-3.5 py-1.5 text-xs font-medium bg-teal-700 text-white rounded hover:bg-teal-800 cursor-pointer whitespace-nowrap"
            >
              {dict.labels.openStudio} →
            </button>
          </div>
        ) : null}
      </div>

      {!business ? (
        <div className="bg-white border border-slate-200 rounded-lg p-8 text-sm text-slate-500">
          Select a business lead to inspect sources, facts, and contact verification.
        </div>
      ) : (
        <>
          {/* Safe Official URL Fetcher */}
          <section className="bg-white border border-slate-200 rounded-lg p-5">
            <div className="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-slate-200">
              <div className="flex items-center gap-2">
                <Globe className="w-4 h-4 text-teal-700" aria-hidden="true" />
                <h2 className="text-sm font-semibold text-slate-900">{dict.labels.fetchOfficialUrl}</h2>
              </div>
              <span className="text-xs text-slate-500">
                Blocks localhost/private IPs · Revalidates redirects · Imports as unverified
              </span>
            </div>
            <form onSubmit={handleFetch} className="mt-3 flex flex-wrap items-center gap-3">
              <input
                type="url"
                value={fetchUrl}
                onChange={(e) => setFetchUrl(e.target.value)}
                placeholder={business.official_url || 'https://example.org/business-page'}
                className="flex-1 min-w-[260px] px-3 py-2 text-sm border border-slate-300 rounded-md"
              />
              <button
                type="submit"
                disabled={busy}
                className="px-4 py-2 text-xs font-medium bg-slate-900 text-white rounded-md hover:bg-slate-800 cursor-pointer whitespace-nowrap"
              >
                {dict.labels.fetchOfficialUrl}
              </button>
            </form>
          </section>

          {/* Two-Column Facts & Contacts */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
            {/* Left: Sources + Facts */}
            <section className="lg:col-span-7 bg-white border border-slate-200 rounded-lg p-6 space-y-5">
              <h2 className="text-base font-semibold text-slate-900 pb-3 border-b border-slate-200">
                {dict.labels.factsSection}
              </h2>

              {/* Sources */}
              <div className="space-y-2">
                <div className="text-xs font-medium text-slate-600">Collected Sources ({detail.sources.length})</div>
                {detail.sources.map((s) => (
                  <div key={s.id} className="p-3 bg-slate-50 border border-slate-200 rounded-md text-xs space-y-1">
                    <div className="font-mono text-slate-800 break-all">{s.url}</div>
                    <div className="text-slate-500 flex flex-wrap items-center gap-2">
                      <span className="font-mono tabular-nums">{new Date(s.retrieved_at).toLocaleString()}</span>
                      <span aria-hidden="true">·</span>
                      <span>{s.permitted_use_notes || 'No notes'}</span>
                    </div>
                  </div>
                ))}

                <form onSubmit={handleAddSource} className="pt-2 grid grid-cols-1 sm:grid-cols-12 gap-2">
                  <input
                    type="url"
                    required
                    value={srcUrl}
                    onChange={(e) => setSrcUrl(e.target.value)}
                    placeholder="Add source https://..."
                    className="sm:col-span-5 px-2.5 py-1.5 text-xs border border-slate-300 rounded"
                  />
                  <input
                    type="text"
                    value={srcNotes}
                    onChange={(e) => setSrcNotes(e.target.value)}
                    placeholder="Permitted use note"
                    className="sm:col-span-5 px-2.5 py-1.5 text-xs border border-slate-300 rounded"
                  />
                  <button
                    type="submit"
                    disabled={busy}
                    className="sm:col-span-2 px-3 py-1.5 text-xs font-medium border border-slate-300 text-slate-700 rounded hover:bg-slate-50 cursor-pointer"
                  >
                    + Source
                  </button>
                </form>
              </div>

              {/* Facts */}
              <div className="pt-4 border-t border-slate-200 space-y-3">
                <div className="text-xs font-medium text-slate-600">Business Facts ({detail.facts.length})</div>
                {detail.facts.map((fact) => (
                  <div key={fact.id} className="p-3 border border-slate-200 rounded-md text-xs space-y-2">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <span className="font-semibold text-slate-900">{fact.field_name}</span>
                      <StatusText status={fact.verification_status} lang={lang} />
                    </div>

                    {editingFactId === fact.id ? (
                      <div className="space-y-2">
                        <textarea
                          rows={3}
                          value={editingFactVal}
                          onChange={(e) => setEditingFactVal(e.target.value)}
                          className="w-full p-2 text-xs border border-slate-300 rounded"
                        />
                        <div className="flex items-center gap-2">
                          <button
                            type="button"
                            onClick={async () => {
                              await onUpdateFact(fact.id, { value: editingFactVal });
                              setEditingFactId(null);
                            }}
                            className="px-2.5 py-1 text-xs font-medium bg-teal-700 text-white rounded cursor-pointer"
                          >
                            Save
                          </button>
                          <button
                            type="button"
                            onClick={() => setEditingFactId(null)}
                            className="px-2.5 py-1 text-xs border border-slate-300 rounded cursor-pointer"
                          >
                            Cancel
                          </button>
                        </div>
                      </div>
                    ) : (
                      <div className="text-slate-700 whitespace-pre-wrap">{fact.value || '—'}</div>
                    )}

                    <div className="flex flex-wrap items-center justify-between gap-2 pt-1 border-t border-slate-100 text-slate-500">
                      <span className="truncate max-w-[260px]">
                        Source: {fact.source_url || 'None linked'}
                      </span>
                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          onClick={() => {
                            setEditingFactId(fact.id);
                            setEditingFactVal(fact.value);
                          }}
                          className="text-slate-700 hover:underline cursor-pointer"
                        >
                          Edit
                        </button>
                        <button
                          type="button"
                          onClick={() => onUpdateFact(fact.id, { verification_status: 'verified' })}
                          className="text-emerald-700 hover:underline cursor-pointer"
                        >
                          {dict.labels.verify}
                        </button>
                        <button
                          type="button"
                          onClick={() => onUpdateFact(fact.id, { verification_status: 'unknown' })}
                          className="text-amber-700 hover:underline cursor-pointer"
                        >
                          {dict.labels.markUnknown}
                        </button>
                      </div>
                    </div>
                  </div>
                ))}

                <form onSubmit={handleAddFact} className="pt-3 border-t border-slate-200 space-y-2">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    <input
                      type="text"
                      value={factField}
                      onChange={(e) => setFactField(e.target.value)}
                      placeholder="Field (services, opening_hours, about)"
                      className="px-2.5 py-1.5 text-xs border border-slate-300 rounded"
                    />
                    <select
                      value={factSourceId}
                      onChange={(e) => setFactSourceId(e.target.value)}
                      className="px-2.5 py-1.5 text-xs border border-slate-300 rounded bg-white"
                    >
                      <option value="">Link Source (optional)</option>
                      {detail.sources.map((s) => (
                        <option key={s.id} value={s.id}>
                          #{s.id} {s.url.slice(0, 40)}
                        </option>
                      ))}
                    </select>
                  </div>
                  <textarea
                    rows={2}
                    value={factValue}
                    onChange={(e) => setFactValue(e.target.value)}
                    placeholder="Verified business fact value..."
                    className="w-full p-2 text-xs border border-slate-300 rounded"
                  />
                  <button
                    type="submit"
                    disabled={busy}
                    className="px-3 py-1.5 text-xs font-medium bg-teal-700 text-white rounded hover:bg-teal-800 cursor-pointer"
                  >
                    {dict.labels.addFact}
                  </button>
                </form>
              </div>
            </section>

            {/* Right: Contacts & Permissions */}
            <section className="lg:col-span-5 bg-white border border-slate-200 rounded-lg p-6 space-y-5">
              <div className="pb-3 border-b border-slate-200">
                <h2 className="text-base font-semibold text-slate-900">{dict.labels.contactsSection}</h2>
                <p className="text-xs text-slate-500 mt-1">
                  Missing emails stay <span className="font-mono">unknown</span>. Phone numbers are never auto-converted to WhatsApp links.
                </p>
              </div>

              <div className="space-y-3">
                {detail.contacts.length === 0 ? (
                  <p className="text-xs text-slate-500">No public contacts recorded yet.</p>
                ) : (
                  detail.contacts.map((ct) => (
                    <div key={ct.id} className="p-3 border border-slate-200 rounded-md text-xs space-y-2">
                      <div className="flex items-center justify-between gap-2">
                        <span className="font-mono font-semibold text-slate-800 uppercase">{ct.channel}</span>
                        <StatusText status={ct.is_suppressed ? 'suppressed' : ct.verification_status} lang={lang} />
                      </div>
                      <div className="font-mono text-slate-900 break-all">
                        {ct.value || '(empty — email unknown)'}
                      </div>
                      <div className="text-slate-600 flex items-center gap-1.5">
                        <ShieldCheck className="w-3.5 h-3.5 text-slate-400 shrink-0" aria-hidden="true" />
                        <span>
                          {ct.permission ? `Permission: ${ct.permission.evidence}` : 'No permission evidence recorded'}
                        </span>
                      </div>
                      <div className="flex flex-wrap items-center gap-2 pt-1 border-t border-slate-100">
                        <button
                          type="button"
                          onClick={() => onUpdateContact(ct.id, { verification_status: 'verified' })}
                          className="text-emerald-700 hover:underline cursor-pointer"
                        >
                          {dict.labels.verify}
                        </button>
                        <button
                          type="button"
                          onClick={() => onUpdateContact(ct.id, { verification_status: 'unknown' })}
                          className="text-amber-700 hover:underline cursor-pointer"
                        >
                          {dict.labels.markUnknown}
                        </button>
                        {!ct.permission ? (
                          <button
                            type="button"
                            onClick={() =>
                              onAddPermission(ct.id, 'Verified public business inquiry contact on official page')
                            }
                            className="text-teal-700 hover:underline cursor-pointer"
                          >
                            + Record Permission Evidence
                          </button>
                        ) : null}
                      </div>
                    </div>
                  ))
                )}
              </div>

              <form onSubmit={handleAddContact} className="pt-4 border-t border-slate-200 space-y-3">
                <div className="text-xs font-semibold text-slate-900">{dict.labels.addContact}</div>
                <div className="grid grid-cols-2 gap-2">
                  <select
                    value={contactChannel}
                    onChange={(e) => setContactChannel(e.target.value as ContactChannel)}
                    className="px-2.5 py-1.5 text-xs border border-slate-300 rounded bg-white"
                  >
                    <option value="email">email</option>
                    <option value="whatsapp_link">whatsapp_link (wa.me URL only)</option>
                    <option value="phone">phone (voice reference only)</option>
                  </select>
                  <select
                    value={contactStatus}
                    onChange={(e) => setContactStatus(e.target.value as VerificationStatus)}
                    className="px-2.5 py-1.5 text-xs border border-slate-300 rounded bg-white"
                  >
                    <option value="verified">verified</option>
                    <option value="unverified">unverified</option>
                    <option value="unknown">unknown</option>
                  </select>
                </div>
                <input
                  type="text"
                  value={contactValue}
                  onChange={(e) => setContactValue(e.target.value)}
                  placeholder={
                    contactChannel === 'whatsapp_link'
                      ? 'https://wa.me/...'
                      : contactChannel === 'email'
                        ? 'contact@example.org'
                        : '+91-...'
                  }
                  className="w-full px-2.5 py-1.5 text-xs border border-slate-300 rounded"
                />
                <input
                  type="text"
                  value={permEvidence}
                  onChange={(e) => setPermEvidence(e.target.value)}
                  placeholder="Permission / public listing evidence note"
                  className="w-full px-2.5 py-1.5 text-xs border border-slate-300 rounded"
                />
                <button
                  type="submit"
                  disabled={busy}
                  className="w-full py-2 text-xs font-medium bg-slate-900 text-white rounded hover:bg-slate-800 cursor-pointer"
                >
                  {dict.labels.addContact}
                </button>
              </form>
            </section>
          </div>
        </>
      )}
    </div>
  );
}
