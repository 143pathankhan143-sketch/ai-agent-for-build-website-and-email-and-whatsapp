import { AlertTriangle, CheckCircle2, CircleSlash, Clock, XCircle } from 'lucide-react';
import { t } from '../shared/i18n.ts';
import type { UiLanguage } from '../shared/types.ts';

interface StatusTextProps {
  status: string;
  lang: UiLanguage;
}

export function StatusText({ status, lang }: StatusTextProps) {
  const dict = t(lang);
  const label = (dict.statuses as Record<string, string>)[status] || status;

  if (['verified', 'approved', 'published', 'sent', 'pass', 'completed', 'active'].includes(status)) {
    return (
      <span className="inline-flex items-center gap-1.5 text-xs font-medium text-emerald-700 whitespace-nowrap">
        <CheckCircle2 className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
        <span>{label}</span>
      </span>
    );
  }

  if (['review_required', 'warning', 'publish_review', 'paused', 'unverified', 'delivery_unknown'].includes(status)) {
    return (
      <span className="inline-flex items-center gap-1.5 text-xs font-medium text-amber-700 whitespace-nowrap">
        <AlertTriangle className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
        <span>{label}</span>
      </span>
    );
  }

  if (['qa_failed', 'failed', 'fail', 'rejected', 'suppressed', 'cancelled'].includes(status)) {
    const Icon = status === 'suppressed' || status === 'cancelled' ? CircleSlash : XCircle;
    return (
      <span className="inline-flex items-center gap-1.5 text-xs font-medium text-red-700 whitespace-nowrap">
        <Icon className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
        <span>{label}</span>
      </span>
    );
  }

  return (
    <span className="inline-flex items-center gap-1.5 text-xs font-medium text-slate-600 whitespace-nowrap">
      <Clock className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
      <span>{label}</span>
    </span>
  );
}
