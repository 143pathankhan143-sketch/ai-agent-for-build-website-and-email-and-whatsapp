import { useState, type FormEvent } from 'react';
import { Pause, Play } from 'lucide-react';
import { t } from '../shared/i18n.ts';
import type { Campaign, ContentLanguage, OutputType, UiLanguage } from '../shared/types.ts';
import { StatusText } from './StatusText.tsx';

interface NewCampaignScreenProps {
  campaigns: Campaign[];
  lang: UiLanguage;
  busy: boolean;
  onCreateCampaign: (payload: {
    name: string;
    area: string;
    category: string;
    language: ContentLanguage;
    output_type: OutputType;
    max_leads: number;
  }) => Promise<void>;
  onToggleCampaignStatus: (id: number, nextStatus: 'active' | 'paused') => Promise<void>;
  onSelectCampaignForLeads: (id: number) => void;
}

const PRESET_CATEGORIES = [
  'Dental Clinic',
  'Jewellery Store',
  'Hair & Skin Salon',
  'Restaurant & Cafe',
  'Physiotherapy Clinic',
  'Local Boutique',
];

export function NewCampaignScreen({
  campaigns,
  lang,
  busy,
  onCreateCampaign,
  onToggleCampaignStatus,
  onSelectCampaignForLeads,
}: NewCampaignScreenProps) {
  const dict = t(lang);
  const [name, setName] = useState('');
  const [area, setArea] = useState('Malviya Nagar, Jaipur');
  const [category, setCategory] = useState('Dental Clinic');
  const [language, setLanguage] = useState<ContentLanguage>('bilingual');
  const [outputType, setOutputType] = useState<OutputType>('html');
  const [maxLeads, setMaxLeads] = useState(3);

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (!area.trim() || !category.trim()) return;
    await onCreateCampaign({
      name: name.trim(),
      area: area.trim(),
      category: category.trim(),
      language,
      output_type: outputType,
      max_leads: maxLeads,
    });
    setName('');
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
      <section className="lg:col-span-5 bg-white border border-slate-200 rounded-lg p-6">
        <h2 className="text-base font-semibold text-slate-900 pb-4 border-b border-slate-200">
          {dict.screens.new_campaign}
        </h2>
        <form onSubmit={handleSubmit} className="mt-4 space-y-4">
          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1" htmlFor="camp-name">
              {dict.labels.campaignName}
            </label>
            <input
              id="camp-name"
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. Jaipur Dental Outreach Batch 1"
              className="w-full px-3 py-2 text-sm border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-teal-700/20 focus:border-teal-700"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1" htmlFor="camp-area">
              {dict.labels.area} *
            </label>
            <input
              id="camp-area"
              type="text"
              required
              value={area}
              onChange={(e) => setArea(e.target.value)}
              className="w-full px-3 py-2 text-sm border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-teal-700/20 focus:border-teal-700"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1" htmlFor="camp-cat">
              {dict.labels.category} *
            </label>
            <input
              id="camp-cat"
              list="category-presets"
              required
              value={category}
              onChange={(e) => setCategory(e.target.value)}
              className="w-full px-3 py-2 text-sm border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-teal-700/20 focus:border-teal-700"
            />
            <datalist id="category-presets">
              {PRESET_CATEGORIES.map((c) => (
                <option key={c} value={c} />
              ))}
            </datalist>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1" htmlFor="camp-lang">
                {dict.labels.contentLanguage}
              </label>
              <select
                id="camp-lang"
                value={language}
                onChange={(e) => setLanguage(e.target.value as ContentLanguage)}
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-md bg-white focus:outline-none focus:border-teal-700"
              >
                <option value="bilingual">Bilingual (EN + HI)</option>
                <option value="en">English</option>
                <option value="hi">Hindi (हिन्दी)</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1" htmlFor="camp-out">
                {dict.labels.outputType}
              </label>
              <select
                id="camp-out"
                value={outputType}
                onChange={(e) => setOutputType(e.target.value as OutputType)}
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-md bg-white focus:outline-none focus:border-teal-700"
              >
                <option value="html">Plain HTML / CSS / JS</option>
                <option value="react">React / Vite Project</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1" htmlFor="camp-max">
              {dict.labels.maxLeads} (1–100)
            </label>
            <input
              id="camp-max"
              type="number"
              min={1}
              max={100}
              value={maxLeads}
              onChange={(e) => setMaxLeads(Number(e.target.value) || 3)}
              className="w-32 px-3 py-2 text-sm font-mono tabular-nums border border-slate-300 rounded-md focus:outline-none focus:border-teal-700"
            />
          </div>

          <button
            type="submit"
            disabled={busy}
            className="w-full py-2.5 px-4 text-sm font-medium bg-teal-700 text-white rounded-md hover:bg-teal-800 disabled:opacity-50 cursor-pointer"
          >
            {dict.labels.createCampaign}
          </button>
        </form>
      </section>

      <section className="lg:col-span-7 bg-white border border-slate-200 rounded-lg">
        <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between">
          <h2 className="text-base font-semibold text-slate-900">{dict.labels.allCampaigns}</h2>
          <span className="text-xs font-mono tabular-nums text-slate-500">{campaigns.length}</span>
        </div>
        <div className="divide-y divide-slate-100">
          {campaigns.map((c) => (
            <div key={c.id} className="p-5 flex flex-wrap items-center justify-between gap-4 hover:bg-slate-50/70">
              <div>
                <div className="flex items-center gap-3">
                  <span className="text-sm font-semibold text-slate-900">{c.name}</span>
                  <StatusText status={c.status} lang={lang} />
                </div>
                <div className="mt-1 text-xs text-slate-500 flex flex-wrap items-center gap-2">
                  <span>{c.area}</span>
                  <span aria-hidden="true">·</span>
                  <span>{c.category}</span>
                  <span aria-hidden="true">·</span>
                  <span className="uppercase font-mono">{c.output_type}</span>
                  <span aria-hidden="true">·</span>
                  <span>{c.language}</span>
                  <span aria-hidden="true">·</span>
                  <span className="font-mono tabular-nums">
                    {c.lead_count ?? 0}/{c.max_leads} leads
                  </span>
                </div>
              </div>

              <div className="flex items-center gap-2 shrink-0">
                <button
                  type="button"
                  onClick={() => onToggleCampaignStatus(c.id, c.status === 'active' ? 'paused' : 'active')}
                  disabled={busy}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium border border-slate-300 text-slate-700 rounded-md hover:bg-slate-50 cursor-pointer whitespace-nowrap"
                >
                  {c.status === 'active' ? (
                    <>
                      <Pause className="w-3.5 h-3.5" aria-hidden="true" />
                      <span>{dict.labels.pauseQueue}</span>
                    </>
                  ) : (
                    <>
                      <Play className="w-3.5 h-3.5" aria-hidden="true" />
                      <span>{dict.labels.resumeQueue}</span>
                    </>
                  )}
                </button>
                <button
                  type="button"
                  onClick={() => onSelectCampaignForLeads(c.id)}
                  className="px-3 py-1.5 text-xs font-medium text-teal-700 border border-teal-700/30 rounded-md hover:bg-teal-50 cursor-pointer whitespace-nowrap"
                >
                  {dict.screens.leads} →
                </button>
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
