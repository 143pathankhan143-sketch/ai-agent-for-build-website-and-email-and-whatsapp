import { useEffect, useState, type ChangeEvent, type FormEvent } from 'react';
import { Download, RotateCcw, Upload } from 'lucide-react';
import { t } from '../shared/i18n.ts';
import type { AppSettings, UiLanguage } from '../shared/types.ts';

interface SettingsScreenProps {
  settings: AppSettings | null;
  lang: UiLanguage;
  busy: boolean;
  onSaveSettings: (payload: Partial<AppSettings>) => Promise<void>;
  onRestoreBackup: (jsonObj: unknown) => Promise<void>;
  onResetTrial: () => Promise<void>;
}

export function SettingsScreen({
  settings,
  lang,
  busy,
  onSaveSettings,
  onRestoreBackup,
  onResetTrial,
}: SettingsScreenProps) {
  const dict = t(lang);
  const [uiLang, setUiLang] = useState<UiLanguage>(settings?.ui_language || 'en');
  const [aiEnabled, setAiEnabled] = useState<boolean>(settings?.ai_enabled ?? true);
  const [followupDefault, setFollowupDefault] = useState<boolean>(settings?.followup_default_enabled ?? false);
  const [followupDays, setFollowupDays] = useState<number>(settings?.followup_days ?? 6);
  const [senderName, setSenderName] = useState<string>(settings?.agency_sender_name ?? 'Freshy Web Studio');
  const [senderEmail, setSenderEmail] = useState<string>(settings?.agency_sender_email ?? 'studio@example.org');

  useEffect(() => {
    if (settings) {
      setUiLang(settings.ui_language);
      setAiEnabled(settings.ai_enabled);
      setFollowupDefault(settings.followup_default_enabled);
      setFollowupDays(settings.followup_days);
      setSenderName(settings.agency_sender_name);
      setSenderEmail(settings.agency_sender_email);
    }
  }, [settings]);

  const handleSave = async (e: FormEvent) => {
    e.preventDefault();
    await onSaveSettings({
      ui_language: uiLang,
      ai_enabled: aiEnabled,
      followup_default_enabled: followupDefault,
      followup_days: followupDays,
      agency_sender_name: senderName,
      agency_sender_email: senderEmail,
    });
  };

  const handleRestoreFile = async (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const text = await file.text();
    const parsed = JSON.parse(text);
    await onRestoreBackup(parsed);
    e.target.value = '';
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
      <section className="lg:col-span-7 bg-white border border-slate-200 rounded-lg p-6">
        <h2 className="text-base font-semibold text-slate-900 pb-4 border-b border-slate-200">
          {dict.screens.settings}
        </h2>
        <form onSubmit={handleSave} className="mt-4 space-y-5">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1" htmlFor="set-lang">
                {dict.labels.languageToggle}
              </label>
              <select
                id="set-lang"
                value={uiLang}
                onChange={(e) => setUiLang(e.target.value as UiLanguage)}
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-md bg-white"
              >
                <option value="en">English</option>
                <option value="hi">हिन्दी (Hindi)</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1" htmlFor="set-fup-days">
                Follow-up Delay (5–7 Days)
              </label>
              <input
                id="set-fup-days"
                type="number"
                min={5}
                max={7}
                value={followupDays}
                onChange={(e) => setFollowupDays(Number(e.target.value) || 6)}
                className="w-full px-3 py-2 text-sm font-mono tabular-nums border border-slate-300 rounded-md"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1" htmlFor="set-sender-name">
                Agency Sender Name
              </label>
              <input
                id="set-sender-name"
                type="text"
                value={senderName}
                onChange={(e) => setSenderName(e.target.value)}
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-md"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1" htmlFor="set-sender-email">
                Agency Sender Email
              </label>
              <input
                id="set-sender-email"
                type="email"
                value={senderEmail}
                onChange={(e) => setSenderEmail(e.target.value)}
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-md"
              />
            </div>
          </div>

          <div className="space-y-3 pt-2 border-t border-slate-200">
            <label className="flex items-start gap-3 cursor-pointer">
              <input
                type="checkbox"
                checked={aiEnabled}
                onChange={(e) => setAiEnabled(e.target.checked)}
                className="mt-0.5 rounded border-slate-300 text-teal-700"
              />
              <span className="text-xs text-slate-700">
                <strong className="block text-slate-900">Enable Optional AI Copy Assistance</strong>
                Deterministic templates always remain active as the primary fallback. Server key configured:{' '}
                <span className="font-mono">{settings?.ai_available ? 'Yes' : 'Not set'}</span>.
              </span>
            </label>

            <label className="flex items-start gap-3 cursor-pointer">
              <input
                type="checkbox"
                checked={followupDefault}
                onChange={(e) => setFollowupDefault(e.target.checked)}
                className="mt-0.5 rounded border-slate-300 text-teal-700"
              />
              <span className="text-xs text-slate-700">
                <strong className="block text-slate-900">Enable Follow-Up Drafts by Default (Policy Default: Off)</strong>
                Even when enabled, at most one follow-up draft is permitted after 5–7 days, subject to human reapproval and non-suppression.
              </span>
            </label>
          </div>

          <button
            type="submit"
            disabled={busy}
            className="px-4 py-2 text-xs font-medium bg-teal-700 text-white rounded-md hover:bg-teal-800 cursor-pointer"
          >
            {dict.labels.saveSettings}
          </button>
        </form>
      </section>

      <section className="lg:col-span-5 bg-white border border-slate-200 rounded-lg p-6 space-y-5">
        <h2 className="text-base font-semibold text-slate-900 pb-4 border-b border-slate-200">
          SQLite Backup, Restore & Trial Reset
        </h2>

        <div className="space-y-3 text-xs text-slate-600">
          <p>
            Export all 15 SQLite tables (campaigns, leads, sources, facts, contacts, websites, QA checks, approvals, suppressions, tasks, and audit logs) into a portable JSON backup.
          </p>
          <a
            href="/api/backup/export"
            className="inline-flex items-center gap-2 px-4 py-2 text-xs font-medium bg-slate-900 text-white rounded-md hover:bg-slate-800"
          >
            <Download className="w-3.5 h-3.5" aria-hidden="true" />
            <span>{dict.labels.exportBackup}</span>
          </a>
        </div>

        <div className="pt-4 border-t border-slate-200 space-y-2 text-xs">
          <div className="font-semibold text-slate-900">{dict.labels.restoreBackup}</div>
          <label className="inline-flex items-center gap-2 px-4 py-2 text-xs font-medium border border-slate-300 text-slate-700 rounded-md hover:bg-slate-50 cursor-pointer">
            <Upload className="w-3.5 h-3.5" aria-hidden="true" />
            <span>Select Backup .json File</span>
            <input type="file" accept=".json,application/json" onChange={handleRestoreFile} className="sr-only" />
          </label>
        </div>

        <div className="pt-4 border-t border-slate-200 space-y-2 text-xs">
          <div className="font-semibold text-slate-900">{dict.labels.quickTrialTitle}</div>
          <p className="text-slate-500">{dict.labels.quickTrialDesc}</p>
          <button
            type="button"
            disabled={busy}
            onClick={onResetTrial}
            className="inline-flex items-center gap-2 px-4 py-2 text-xs font-medium border border-amber-300 text-amber-800 rounded-md hover:bg-amber-50 cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" aria-hidden="true" />
            <span>{dict.resetTrialCta}</span>
          </button>
        </div>
      </section>
    </div>
  );
}
