import { useState, type FormEvent } from 'react';
import { AlertCircle, Check, CircleSlash, Clock, Send } from 'lucide-react';
import { t } from '../shared/i18n.ts';
import type { AppSettings, Business, MessageRecord, UiLanguage, WebsiteRecord } from '../shared/types.ts';
import { StatusText } from './StatusText.tsx';

interface OutreachScreenProps {
  leads: Business[];
  websites: WebsiteRecord[];
  messages: MessageRecord[];
  settings: AppSettings | null;
  lang: UiLanguage;
  busy: boolean;
  onCreateDraft: (payload: {
    business_id: number;
    website_id: number | null;
    channel: 'email' | 'whatsapp_link';
    language: 'en' | 'hi';
    use_ai: boolean;
  }) => Promise<void>;
  onUpdateDraft: (id: number, payload: { subject: string; body: string; attachment_note: string }) => Promise<void>;
  onApproveDraft: (id: number) => Promise<void>;
  onManualSend: (id: number) => Promise<void>;
  onRecordResponse: (id: number, outcome: 'replied' | 'opt_out' | 'delivery_unknown') => Promise<void>;
  onScheduleFollowup: (messageId: number, days: number) => Promise<void>;
}

export function OutreachScreen({
  leads,
  websites,
  messages,
  settings,
  lang,
  busy,
  onCreateDraft,
  onUpdateDraft,
  onApproveDraft,
  onManualSend,
  onRecordResponse,
  onScheduleFollowup,
}: OutreachScreenProps) {
  const dict = t(lang);

  const [businessId, setBusinessId] = useState<number>(leads[0]?.id ?? 0);
  const [websiteId, setWebsiteId] = useState<string>('');
  const [channel, setChannel] = useState<'email' | 'whatsapp_link'>('email');
  const [draftLang, setDraftLang] = useState<'en' | 'hi'>(lang);
  const [useAi, setUseAi] = useState(false);

  const [editingId, setEditingId] = useState<number | null>(null);
  const [editSubject, setEditSubject] = useState('');
  const [editBody, setEditBody] = useState('');
  const [editNote, setEditNote] = useState('');

  const selectedBizWebsites = websites.filter((w) => w.business_id === (businessId || leads[0]?.id));

  const handleCreate = async (e: FormEvent) => {
    e.preventDefault();
    const targetBiz = businessId || leads[0]?.id;
    if (!targetBiz) return;
    await onCreateDraft({
      business_id: targetBiz,
      website_id: websiteId ? Number(websiteId) : selectedBizWebsites[0]?.id ?? null,
      channel,
      language: draftLang,
      use_ai: useAi,
    });
  };

  return (
    <div className="space-y-6">
      {/* Strict Policy Banner */}
      <div className="bg-white border border-slate-200 rounded-lg px-5 py-3.5 text-xs text-slate-700 flex items-center gap-2.5">
        <AlertCircle className="w-4 h-4 text-teal-700 shrink-0" aria-hidden="true" />
        <span>{dict.labels.noBulkSendNotice}</span>
      </div>

      {/* Create Draft Form */}
      <section className="bg-white border border-slate-200 rounded-lg p-5">
        <h2 className="text-sm font-semibold text-slate-900 pb-3 border-b border-slate-200">
          {dict.labels.outreachCreate}
        </h2>
        <form onSubmit={handleCreate} className="mt-4 flex flex-wrap items-end gap-4">
          <div className="min-w-[220px] flex-1">
            <label className="block text-xs font-medium text-slate-700 mb-1">Business Lead</label>
            <select
              value={businessId || leads[0]?.id || ''}
              onChange={(e) => {
                setBusinessId(Number(e.target.value));
                setWebsiteId('');
              }}
              className="w-full px-3 py-2 text-sm border border-slate-300 rounded-md bg-white"
            >
              {leads.map((l) => (
                <option key={l.id} value={l.id}>
                  {l.name} ({l.primary_email || 'No email'})
                </option>
              ))}
            </select>
          </div>

          <div className="min-w-[200px]">
            <label className="block text-xs font-medium text-slate-700 mb-1">Linked Concept Demo</label>
            <select
              value={websiteId}
              onChange={(e) => setWebsiteId(e.target.value)}
              className="w-full px-3 py-2 text-sm border border-slate-300 rounded-md bg-white"
            >
              <option value="">Latest Demo ({selectedBizWebsites[0]?.status || 'none'})</option>
              {selectedBizWebsites.map((w) => (
                <option key={w.id} value={w.id}>
                  v{w.version} · {w.output_type.toUpperCase()} · {w.status}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">{dict.labels.channel}</label>
            <select
              value={channel}
              onChange={(e) => setChannel(e.target.value as 'email' | 'whatsapp_link')}
              className="px-3 py-2 text-sm border border-slate-300 rounded-md bg-white"
            >
              <option value="email">Email (Manual-First)</option>
              <option value="whatsapp_link">Permitted WhatsApp Link</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">Language</label>
            <select
              value={draftLang}
              onChange={(e) => setDraftLang(e.target.value as 'en' | 'hi')}
              className="px-3 py-2 text-sm border border-slate-300 rounded-md bg-white"
            >
              <option value="en">English</option>
              <option value="hi">Hindi (हिन्दी)</option>
            </select>
          </div>

          {settings?.ai_enabled && settings?.ai_available ? (
            <label className="inline-flex items-center gap-2 text-xs text-slate-700 py-2 cursor-pointer">
              <input
                type="checkbox"
                checked={useAi}
                onChange={(e) => setUseAi(e.target.checked)}
                className="rounded border-slate-300 text-teal-700"
              />
              <span>AI Draft Assist</span>
            </label>
          ) : null}

          <button
            type="submit"
            disabled={busy || leads.length === 0}
            className="px-4 py-2 text-xs font-medium bg-teal-700 text-white rounded-md hover:bg-teal-800 disabled:opacity-50 cursor-pointer whitespace-nowrap"
          >
            {dict.labels.outreachCreate}
          </button>
        </form>
      </section>

      {/* Draft List */}
      {messages.length === 0 ? (
        <div className="bg-white border border-slate-200 rounded-lg p-10 text-center text-sm text-slate-500">
          {dict.labels.emptyOutreach}
        </div>
      ) : (
        <div className="space-y-4">
          {messages.map((msg) => {
            const blockers = msg.blockers || [];
            const isEditing = editingId === msg.id;
            const isApproved = Boolean(msg.active_approval);

            return (
              <article key={msg.id} className="bg-white border border-slate-200 rounded-lg p-6 space-y-4">
                {/* Header */}
                <div className="flex flex-wrap items-center justify-between gap-4 pb-3 border-b border-slate-200">
                  <div>
                    <div className="flex flex-wrap items-center gap-3">
                      <h3 className="text-base font-semibold text-slate-900">{msg.business_name}</h3>
                      <StatusText status={msg.status} lang={lang} />
                    </div>
                    <div className="mt-1 text-xs text-slate-500 flex flex-wrap items-center gap-2">
                      <span className="uppercase font-mono">{msg.channel}</span>
                      <span aria-hidden="true">·</span>
                      <span>{msg.purpose === 'follow_up' ? 'Follow-up' : 'Initial Demo'}</span>
                      <span aria-hidden="true">·</span>
                      <span>
                        {dict.labels.recipient}:{' '}
                        <strong className="font-mono text-slate-800">
                          {msg.contact_value || '(missing)'}
                        </strong>
                      </span>
                      <span aria-hidden="true">·</span>
                      <span className="font-mono tabular-nums">Hash: {msg.content_hash.slice(0, 12)}…</span>
                    </div>
                  </div>

                  <div className="flex flex-wrap items-center gap-2">
                    {msg.status !== 'sent' && msg.status !== 'suppressed' ? (
                      <>
                        <button
                          type="button"
                          onClick={() => {
                            if (isEditing) {
                              setEditingId(null);
                            } else {
                              setEditingId(msg.id);
                              setEditSubject(msg.subject);
                              setEditBody(msg.body);
                              setEditNote(msg.attachment_note);
                            }
                          }}
                          className="px-3 py-1.5 text-xs font-medium border border-slate-300 text-slate-700 rounded hover:bg-slate-50 cursor-pointer"
                        >
                          {isEditing ? 'Cancel Edit' : 'Edit Draft'}
                        </button>

                        <button
                          type="button"
                          disabled={busy || blockers.length > 0}
                          onClick={() => onApproveDraft(msg.id)}
                          className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium bg-teal-700 text-white rounded hover:bg-teal-800 disabled:opacity-45 cursor-pointer whitespace-nowrap"
                        >
                          <Check className="w-3.5 h-3.5" aria-hidden="true" />
                          <span>{dict.labels.approveMessage}</span>
                        </button>

                        <button
                          type="button"
                          disabled={busy || blockers.length > 0 || !isApproved}
                          onClick={() => onManualSend(msg.id)}
                          className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium bg-slate-900 text-white rounded hover:bg-slate-800 disabled:opacity-45 cursor-pointer whitespace-nowrap"
                        >
                          <Send className="w-3.5 h-3.5" aria-hidden="true" />
                          <span>{dict.labels.confirmManualSend}</span>
                        </button>
                      </>
                    ) : null}

                    {msg.status === 'sent' ? (
                      <>
                        <button
                          type="button"
                          disabled={busy}
                          onClick={() => onRecordResponse(msg.id, 'replied')}
                          className="px-2.5 py-1.5 text-xs font-medium border border-emerald-300 text-emerald-800 rounded hover:bg-emerald-50 cursor-pointer"
                        >
                          {dict.labels.logReply}
                        </button>
                        <button
                          type="button"
                          disabled={busy}
                          onClick={() => onRecordResponse(msg.id, 'delivery_unknown')}
                          className="px-2.5 py-1.5 text-xs font-medium border border-amber-300 text-amber-800 rounded hover:bg-amber-50 cursor-pointer"
                        >
                          Mark Delivery Unknown
                        </button>
                        <button
                          type="button"
                          disabled={busy}
                          onClick={() => onScheduleFollowup(msg.id, settings?.followup_days ?? 6)}
                          className="inline-flex items-center gap-1 px-2.5 py-1.5 text-xs font-medium border border-slate-300 text-slate-700 rounded hover:bg-slate-50 cursor-pointer"
                        >
                          <Clock className="w-3.5 h-3.5" aria-hidden="true" />
                          <span>{dict.labels.scheduleFollowUp}</span>
                        </button>
                      </>
                    ) : null}

                    {msg.status !== 'suppressed' ? (
                      <button
                        type="button"
                        disabled={busy}
                        onClick={() => onRecordResponse(msg.id, 'opt_out')}
                        className="inline-flex items-center gap-1 px-2.5 py-1.5 text-xs font-medium border border-red-200 text-red-700 rounded hover:bg-red-50 cursor-pointer"
                      >
                        <CircleSlash className="w-3.5 h-3.5" aria-hidden="true" />
                        <span>{dict.labels.recordOptOut}</span>
                      </button>
                    ) : null}
                  </div>
                </div>

                {/* Blockers List */}
                {blockers.length > 0 && msg.status !== 'sent' && (
                  <div className="p-3 bg-amber-50 border border-amber-200 rounded-md text-xs text-amber-900 space-y-1">
                    <div className="font-semibold">Send & Approval Blockers:</div>
                    <ul className="list-disc pl-5 space-y-0.5">
                      {blockers.map((blk) => (
                        <li key={blk}>{blk}</li>
                      ))}
                    </ul>
                  </div>
                )}

                {/* Draft Content or Edit Form */}
                {isEditing ? (
                  <div className="space-y-3">
                    <div>
                      <label className="block text-xs font-medium text-slate-700 mb-1">{dict.labels.subject}</label>
                      <input
                        type="text"
                        value={editSubject}
                        onChange={(e) => setEditSubject(e.target.value)}
                        className="w-full px-3 py-1.5 text-sm border border-slate-300 rounded-md"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-medium text-slate-700 mb-1">{dict.labels.body}</label>
                      <textarea
                        rows={6}
                        value={editBody}
                        onChange={(e) => setEditBody(e.target.value)}
                        className="w-full p-3 text-xs border border-slate-300 rounded-md"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-medium text-slate-700 mb-1">
                        {dict.labels.attachmentNote}
                      </label>
                      <input
                        type="text"
                        value={editNote}
                        onChange={(e) => setEditNote(e.target.value)}
                        className="w-full px-3 py-1.5 text-xs border border-slate-300 rounded-md"
                      />
                    </div>
                    <button
                      type="button"
                      disabled={busy}
                      onClick={async () => {
                        await onUpdateDraft(msg.id, {
                          subject: editSubject,
                          body: editBody,
                          attachment_note: editNote,
                        });
                        setEditingId(null);
                      }}
                      className="px-4 py-2 text-xs font-medium bg-slate-900 text-white rounded hover:bg-slate-800 cursor-pointer"
                    >
                      Save Edits (Invalidates Prior Approval)
                    </button>
                  </div>
                ) : (
                  <div className="space-y-2 text-xs">
                    <div className="font-semibold text-slate-900 text-sm">{msg.subject}</div>
                    <pre className="whitespace-pre-wrap font-sans text-slate-700 bg-slate-50 border border-slate-200 rounded-md p-4 leading-relaxed">
                      {msg.body}
                    </pre>
                    <div className="text-slate-500">
                      {dict.labels.attachmentNote}: <span className="font-mono">{msg.attachment_note || 'None'}</span>
                    </div>
                  </div>
                )}
              </article>
            );
          })}
        </div>
      )}
    </div>
  );
}
