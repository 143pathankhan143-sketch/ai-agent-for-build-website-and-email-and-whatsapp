import { useState, type FormEvent } from 'react';
import { Pause, Play, Trash2, XCircle } from 'lucide-react';
import { t } from '../shared/i18n.ts';
import type { AuditEventRecord, SuppressionRecord, TaskRecord, UiLanguage } from '../shared/types.ts';
import { StatusText } from './StatusText.tsx';

interface ActivityScreenProps {
  tasks: TaskRecord[];
  suppressions: SuppressionRecord[];
  audit: AuditEventRecord[];
  lang: UiLanguage;
  busy: boolean;
  onRunNextTask: () => Promise<void>;
  onUpdateTaskStatus: (id: number, status: 'queued' | 'paused' | 'cancelled') => Promise<void>;
  onAddSuppression: (contact: string, channel: string, reason: string) => Promise<void>;
  onDeleteSuppression: (id: number) => Promise<void>;
}

export function ActivityScreen({
  tasks,
  suppressions,
  audit,
  lang,
  busy,
  onRunNextTask,
  onUpdateTaskStatus,
  onAddSuppression,
  onDeleteSuppression,
}: ActivityScreenProps) {
  const dict = t(lang);
  const [supContact, setSupContact] = useState('');
  const [supChannel, setSupChannel] = useState('email');
  const [supReason, setSupReason] = useState('Manual opt-out request');

  const handleAddSuppression = async (e: FormEvent) => {
    e.preventDefault();
    if (!supContact.trim()) return;
    await onAddSuppression(supContact.trim(), supChannel, supReason.trim());
    setSupContact('');
  };

  return (
    <div className="space-y-6">
      {/* Orchestrator Queue */}
      <section className="bg-white border border-slate-200 rounded-lg overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-200 flex flex-wrap items-center justify-between gap-4">
          <div>
            <h2 className="text-base font-semibold text-slate-900">Orchestrator Queue</h2>
            <p className="text-xs text-slate-500">
              Bounded retries, pause/resume controls, and scheduled follow-up drafts.
            </p>
          </div>
          <button
            type="button"
            disabled={busy}
            onClick={onRunNextTask}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium bg-teal-700 text-white rounded-md hover:bg-teal-800 cursor-pointer whitespace-nowrap"
          >
            <Play className="w-3.5 h-3.5" aria-hidden="true" />
            <span>{dict.labels.runNextTask}</span>
          </button>
        </div>

        {tasks.length === 0 ? (
          <div className="p-6 text-sm text-slate-500">No tasks in queue.</div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-200 text-xs text-slate-500 font-medium bg-slate-50/70">
                  <th className="py-2.5 px-6">Task Type</th>
                  <th className="py-2.5 px-4">Business / Campaign</th>
                  <th className="py-2.5 px-4">Status</th>
                  <th className="py-2.5 px-4 text-right">Attempts</th>
                  <th className="py-2.5 px-4">Last Error</th>
                  <th className="py-2.5 px-6 text-right">Controls</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-xs">
                {tasks.map((task) => (
                  <tr key={task.id} className="hover:bg-slate-50/70">
                    <td className="py-3 px-6 font-mono text-slate-900">{task.task_type}</td>
                    <td className="py-3 px-4 text-slate-700">
                      <div>{task.business_name || '—'}</div>
                      <div className="text-slate-400">{task.campaign_name || ''}</div>
                    </td>
                    <td className="py-3 px-4">
                      <StatusText status={task.status} lang={lang} />
                    </td>
                    <td className="py-3 px-4 text-right font-mono tabular-nums text-slate-700">
                      {task.attempt_count}/{task.max_attempts}
                    </td>
                    <td className="py-3 px-4 text-slate-500 max-w-[260px] truncate">{task.last_error || '—'}</td>
                    <td className="py-3 px-6 text-right">
                      <div className="inline-flex items-center gap-2">
                        {task.status === 'queued' ? (
                          <button
                            type="button"
                            onClick={() => onUpdateTaskStatus(task.id, 'paused')}
                            className="p-1 text-slate-600 hover:text-slate-900 cursor-pointer"
                            title="Pause task"
                          >
                            <Pause className="w-3.5 h-3.5" />
                          </button>
                        ) : null}
                        {task.status === 'paused' ? (
                          <button
                            type="button"
                            onClick={() => onUpdateTaskStatus(task.id, 'queued')}
                            className="p-1 text-teal-700 hover:text-teal-900 cursor-pointer"
                            title="Resume task"
                          >
                            <Play className="w-3.5 h-3.5" />
                          </button>
                        ) : null}
                        {task.status === 'queued' || task.status === 'paused' ? (
                          <button
                            type="button"
                            onClick={() => onUpdateTaskStatus(task.id, 'cancelled')}
                            className="p-1 text-red-700 hover:text-red-900 cursor-pointer"
                            title="Cancel task"
                          >
                            <XCircle className="w-3.5 h-3.5" />
                          </button>
                        ) : null}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>

      {/* Opt-Out Suppressions + Audit Log Split */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        <section className="lg:col-span-5 bg-white border border-slate-200 rounded-lg p-6 space-y-4">
          <h2 className="text-base font-semibold text-slate-900 pb-3 border-b border-slate-200">
            {dict.labels.suppressions}
          </h2>
          <form onSubmit={handleAddSuppression} className="space-y-2.5">
            <div className="grid grid-cols-3 gap-2">
              <select
                value={supChannel}
                onChange={(e) => setSupChannel(e.target.value)}
                className="px-2.5 py-1.5 text-xs border border-slate-300 rounded bg-white"
              >
                <option value="email">email</option>
                <option value="whatsapp_link">whatsapp_link</option>
                <option value="phone">phone</option>
              </select>
              <input
                type="text"
                required
                value={supContact}
                onChange={(e) => setSupContact(e.target.value)}
                placeholder="contact@example.org"
                className="col-span-2 px-2.5 py-1.5 text-xs border border-slate-300 rounded"
              />
            </div>
            <input
              type="text"
              value={supReason}
              onChange={(e) => setSupReason(e.target.value)}
              placeholder="Suppression reason"
              className="w-full px-2.5 py-1.5 text-xs border border-slate-300 rounded"
            />
            <button
              type="submit"
              disabled={busy}
              className="w-full py-2 text-xs font-medium bg-slate-900 text-white rounded hover:bg-slate-800 cursor-pointer"
            >
              {dict.labels.addSuppression}
            </button>
          </form>

          <div className="divide-y divide-slate-100 pt-2">
            {suppressions.map((s) => (
              <div key={s.id} className="py-2.5 flex items-center justify-between gap-3 text-xs">
                <div>
                  <div className="font-mono text-slate-900">{s.normalized_contact}</div>
                  <div className="text-slate-500">
                    {s.channel} · {s.reason}
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => onDeleteSuppression(s.id)}
                  className="p-1.5 text-slate-400 hover:text-red-700 cursor-pointer"
                  title="Remove suppression"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            ))}
          </div>
        </section>

        <section className="lg:col-span-7 bg-white border border-slate-200 rounded-lg overflow-hidden">
          <div className="px-6 py-4 border-b border-slate-200">
            <h2 className="text-base font-semibold text-slate-900">Audit Trail</h2>
          </div>
          {audit.length === 0 ? (
            <div className="p-6 text-sm text-slate-500">{dict.labels.emptyAudit}</div>
          ) : (
            <div className="max-h-[460px] overflow-y-auto divide-y divide-slate-100">
              {audit.map((ev) => (
                <div key={ev.id} className="px-6 py-3 text-xs flex items-start justify-between gap-4">
                  <div>
                    <div className="font-medium text-slate-900">
                      {ev.action}{' '}
                      <span className="font-mono font-normal text-slate-500">
                        ({ev.entity_type} #{ev.entity_id})
                      </span>
                    </div>
                    {ev.safe_metadata && ev.safe_metadata !== '{}' ? (
                      <div className="mt-0.5 font-mono text-[11px] text-slate-500 break-all">{ev.safe_metadata}</div>
                    ) : null}
                  </div>
                  <div className="text-right shrink-0 text-slate-500 font-mono tabular-nums">
                    <div>{ev.actor}</div>
                    <div>{new Date(ev.created_at).toLocaleString()}</div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </section>
      </div>
    </div>
  );
}
