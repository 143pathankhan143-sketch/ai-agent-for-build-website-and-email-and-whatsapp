import type {
  AppSettings,
  AuditEventRecord,
  Business,
  Campaign,
  ContactRecord,
  FactRecord,
  MessageRecord,
  OverviewSummary,
  SourceRecord,
  SuppressionRecord,
  TaskRecord,
  WebsiteRecord,
} from '../shared/types.ts';

async function request<T>(url: string, options?: RequestInit): Promise<T> {
  const res = await fetch(url, {
    headers: { 'Content-Type': 'application/json', ...(options?.headers || {}) },
    ...options,
  });
  const text = await res.text();
  let data: unknown = null;
  try {
    data = text ? JSON.parse(text) : null;
  } catch {
    data = text;
  }
  if (!res.ok) {
    const msg =
      data && typeof data === 'object' && 'error' in data
        ? String((data as { error: unknown }).error)
        : `Request failed (${res.status})`;
    throw new Error(msg);
  }
  return data as T;
}

export const api = {
  getOverview: () => request<OverviewSummary>('/api/overview'),
  getCampaigns: () => request<Campaign[]>('/api/campaigns'),
  createCampaign: (payload: {
    name?: string;
    area: string;
    category: string;
    language: string;
    output_type: string;
    max_leads: number;
  }) => request<Campaign>('/api/campaigns', { method: 'POST', body: JSON.stringify(payload) }),
  setCampaignStatus: (id: number, status: 'active' | 'paused' | 'completed') =>
    request<Campaign>(`/api/campaigns/${id}/status`, { method: 'PATCH', body: JSON.stringify({ status }) }),

  getLeads: (campaignId?: number | null) =>
    request<Business[]>(campaignId ? `/api/leads?campaignId=${campaignId}` : '/api/leads'),
  createLead: (payload: Record<string, unknown>) =>
    request<{ lead: Business; duplicate_flagged: boolean; duplicate_note: string }>('/api/leads', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),
  importCsv: (csv_text: string, campaign_id?: number | null) =>
    request<{ imported: number; duplicates: number; errors: string[] }>('/api/leads/import-csv', {
      method: 'POST',
      body: JSON.stringify({ csv_text, campaign_id }),
    }),
  updateLeadStatus: (id: number, review_status: string, purge_unnecessary_pii = false) =>
    request<Business>(`/api/leads/${id}/status`, {
      method: 'PATCH',
      body: JSON.stringify({ review_status, purge_unnecessary_pii }),
    }),
  deleteLead: (id: number) => request<{ deleted: boolean }>(`/api/leads/${id}`, { method: 'DELETE' }),

  getLeadDetail: (id: number) =>
    request<{
      business: Business;
      sources: SourceRecord[];
      facts: FactRecord[];
      contacts: ContactRecord[];
      websites: WebsiteRecord[];
    }>(`/api/leads/${id}/detail`),
  addSource: (businessId: number, payload: { url: string; permitted_use_notes: string }) =>
    request<SourceRecord>(`/api/leads/${businessId}/sources`, { method: 'POST', body: JSON.stringify(payload) }),
  addFact: (businessId: number, payload: Record<string, unknown>) =>
    request<FactRecord>(`/api/leads/${businessId}/facts`, { method: 'POST', body: JSON.stringify(payload) }),
  updateFact: (factId: number, payload: Record<string, unknown>) =>
    request<FactRecord>(`/api/facts/${factId}`, { method: 'PATCH', body: JSON.stringify(payload) }),
  addContact: (businessId: number, payload: Record<string, unknown>) =>
    request<ContactRecord>(`/api/leads/${businessId}/contacts`, { method: 'POST', body: JSON.stringify(payload) }),
  updateContact: (contactId: number, payload: Record<string, unknown>) =>
    request<ContactRecord>(`/api/contacts/${contactId}`, { method: 'PATCH', body: JSON.stringify(payload) }),
  addPermission: (contactId: number, payload: { evidence: string; scope?: string }) =>
    request(`/api/contacts/${contactId}/permissions`, { method: 'POST', body: JSON.stringify(payload) }),
  fetchOfficialUrl: (businessId: number, url?: string) =>
    request<{ fetched: { finalUrl: string; title: string; description: string; emails: string[]; whatsappLinks: string[] } }>(
      `/api/leads/${businessId}/fetch-url`,
      { method: 'POST', body: JSON.stringify({ url }) }
    ),

  getWebsites: () => request<WebsiteRecord[]>('/api/websites'),
  generateWebsite: (payload: Record<string, unknown>) =>
    request<{ website: WebsiteRecord; ai_notice?: string }>('/api/websites/generate', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),
  updateWebsite: (id: number, payload: Record<string, unknown>) =>
    request<{ website: WebsiteRecord; revoked_prior_approval: boolean }>(`/api/websites/${id}`, {
      method: 'PATCH',
      body: JSON.stringify(payload),
    }),
  refineWebsiteWithAi: (id: number) =>
    request<{ website: WebsiteRecord }>(`/api/websites/${id}/ai-copy`, { method: 'POST' }),
  runWebsiteQa: (id: number) => request<WebsiteRecord>(`/api/websites/${id}/qa`, { method: 'POST' }),
  approveWebsite: (id: number) => request<WebsiteRecord>(`/api/websites/${id}/approve`, { method: 'POST' }),
  publishReviewWebsite: (id: number, payload: { public_url: string; mark_published: boolean }) =>
    request<WebsiteRecord>(`/api/websites/${id}/publish-review`, {
      method: 'POST',
      body: JSON.stringify(payload),
    }),

  getOutreach: () => request<MessageRecord[]>('/api/outreach'),
  createOutreachDraft: (payload: Record<string, unknown>) =>
    request<{ message: MessageRecord; ai_notice?: string }>('/api/outreach/draft', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),
  updateOutreachDraft: (id: number, payload: Record<string, unknown>) =>
    request<{ message: MessageRecord; revoked_prior_approval: boolean }>(`/api/outreach/${id}`, {
      method: 'PATCH',
      body: JSON.stringify(payload),
    }),
  approveOutreach: (id: number) => request<MessageRecord>(`/api/outreach/${id}/approve`, { method: 'POST' }),
  manualSendOutreach: (id: number) => request<MessageRecord>(`/api/outreach/${id}/manual-send`, { method: 'POST' }),
  recordOutreachResponse: (id: number, outcome: 'replied' | 'opt_out' | 'delivery_unknown', reason?: string) =>
    request(`/api/outreach/${id}/response`, { method: 'POST', body: JSON.stringify({ outcome, reason }) }),

  getSuppressions: () => request<SuppressionRecord[]>('/api/suppressions'),
  addSuppression: (payload: { contact: string; channel: string; reason: string }) =>
    request<SuppressionRecord>('/api/suppressions', { method: 'POST', body: JSON.stringify(payload) }),
  deleteSuppression: (id: number) => request(`/api/suppressions/${id}`, { method: 'DELETE' }),

  getTasks: () => request<TaskRecord[]>('/api/tasks'),
  runNextTask: () => request<{ ran: boolean; message?: string; task_type?: string }>('/api/tasks/run-next', { method: 'POST' }),
  scheduleFollowup: (message_id: number, days: number) =>
    request<TaskRecord>('/api/tasks/schedule-followup', {
      method: 'POST',
      body: JSON.stringify({ message_id, days }),
    }),
  updateTaskStatus: (id: number, status: 'queued' | 'paused' | 'cancelled') =>
    request<TaskRecord>(`/api/tasks/${id}`, { method: 'PATCH', body: JSON.stringify({ status }) }),

  getAudit: () => request<AuditEventRecord[]>('/api/audit'),
  getSettings: () => request<AppSettings>('/api/settings'),
  updateSettings: (payload: Partial<AppSettings>) =>
    request<AppSettings>('/api/settings', { method: 'PATCH', body: JSON.stringify(payload) }),
  resetDentalTrial: () => request<{ ok: boolean; campaign_id: number }>('/api/trial/reset-dental', { method: 'POST' }),
  restoreBackup: (payload: unknown) =>
    request<{ ok: boolean; restored_rows: number }>('/api/backup/restore', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),
};
