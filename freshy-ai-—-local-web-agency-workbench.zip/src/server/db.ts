import fs from 'node:fs';
import path from 'node:path';
import Database from 'better-sqlite3';
import { normalizeContact, normalizeIdentity, sha256 } from './security.ts';

const DATA_DIR = path.resolve(process.cwd(), 'data');
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

const DB_PATH = path.join(DATA_DIR, 'freshy.db');
export const db = new Database(DB_PATH);
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

export function initDatabase(): void {
  db.exec(`
    CREATE TABLE IF NOT EXISTS campaigns (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      area TEXT NOT NULL,
      category TEXT NOT NULL,
      language TEXT NOT NULL DEFAULT 'bilingual',
      output_type TEXT NOT NULL DEFAULT 'html',
      max_leads INTEGER NOT NULL DEFAULT 3,
      status TEXT NOT NULL DEFAULT 'active',
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS businesses (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      category TEXT NOT NULL,
      locality TEXT NOT NULL,
      address TEXT NOT NULL DEFAULT '',
      official_url TEXT NOT NULL DEFAULT '',
      normalized_identity TEXT NOT NULL,
      review_status TEXT NOT NULL DEFAULT 'new',
      notes TEXT NOT NULL DEFAULT '',
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS campaign_businesses (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      campaign_id INTEGER NOT NULL,
      business_id INTEGER NOT NULL,
      stage TEXT NOT NULL DEFAULT 'new',
      selected_at TEXT NOT NULL,
      UNIQUE(campaign_id, business_id),
      FOREIGN KEY (campaign_id) REFERENCES campaigns(id) ON DELETE CASCADE,
      FOREIGN KEY (business_id) REFERENCES businesses(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS sources (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      business_id INTEGER NOT NULL,
      url TEXT NOT NULL,
      retrieved_at TEXT NOT NULL,
      permitted_use_notes TEXT NOT NULL DEFAULT '',
      FOREIGN KEY (business_id) REFERENCES businesses(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS facts (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      business_id INTEGER NOT NULL,
      field_name TEXT NOT NULL,
      value TEXT NOT NULL,
      source_id INTEGER,
      verified_at TEXT,
      verification_status TEXT NOT NULL DEFAULT 'unverified',
      confidence TEXT NOT NULL DEFAULT 'medium',
      FOREIGN KEY (business_id) REFERENCES businesses(id) ON DELETE CASCADE,
      FOREIGN KEY (source_id) REFERENCES sources(id) ON DELETE SET NULL
    );

    CREATE TABLE IF NOT EXISTS contacts (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      business_id INTEGER NOT NULL,
      channel TEXT NOT NULL,
      value TEXT NOT NULL,
      source_id INTEGER,
      verification_status TEXT NOT NULL DEFAULT 'unknown',
      created_at TEXT NOT NULL,
      FOREIGN KEY (business_id) REFERENCES businesses(id) ON DELETE CASCADE,
      FOREIGN KEY (source_id) REFERENCES sources(id) ON DELETE SET NULL
    );

    CREATE TABLE IF NOT EXISTS permissions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      contact_id INTEGER NOT NULL,
      channel TEXT NOT NULL,
      scope TEXT NOT NULL,
      evidence TEXT NOT NULL,
      recorded_at TEXT NOT NULL,
      revoked_at TEXT,
      FOREIGN KEY (contact_id) REFERENCES contacts(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS websites (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      business_id INTEGER NOT NULL,
      campaign_id INTEGER,
      version INTEGER NOT NULL DEFAULT 1,
      template_key TEXT NOT NULL DEFAULT 'universal',
      language TEXT NOT NULL DEFAULT 'bilingual',
      output_type TEXT NOT NULL DEFAULT 'html',
      headline TEXT NOT NULL DEFAULT '',
      subheadline TEXT NOT NULL DEFAULT '',
      about_copy TEXT NOT NULL DEFAULT '',
      services_json TEXT NOT NULL DEFAULT '[]',
      cta_label TEXT NOT NULL DEFAULT '',
      content_hash TEXT NOT NULL,
      local_path TEXT NOT NULL DEFAULT '',
      public_url TEXT NOT NULL DEFAULT '',
      status TEXT NOT NULL DEFAULT 'draft',
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      FOREIGN KEY (business_id) REFERENCES businesses(id) ON DELETE CASCADE,
      FOREIGN KEY (campaign_id) REFERENCES campaigns(id) ON DELETE SET NULL
    );

    CREATE TABLE IF NOT EXISTS qa_results (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      website_id INTEGER NOT NULL,
      check_name TEXT NOT NULL,
      outcome TEXT NOT NULL,
      details TEXT NOT NULL,
      checked_at TEXT NOT NULL,
      FOREIGN KEY (website_id) REFERENCES websites(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS messages (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      business_id INTEGER NOT NULL,
      campaign_id INTEGER,
      contact_id INTEGER,
      website_id INTEGER,
      channel TEXT NOT NULL DEFAULT 'email',
      purpose TEXT NOT NULL DEFAULT 'initial_demo',
      subject TEXT NOT NULL DEFAULT '',
      body TEXT NOT NULL DEFAULT '',
      attachment_note TEXT NOT NULL DEFAULT '',
      content_hash TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'draft',
      follow_up_enabled INTEGER NOT NULL DEFAULT 0,
      follow_up_days INTEGER NOT NULL DEFAULT 6,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      FOREIGN KEY (business_id) REFERENCES businesses(id) ON DELETE CASCADE,
      FOREIGN KEY (campaign_id) REFERENCES campaigns(id) ON DELETE SET NULL,
      FOREIGN KEY (contact_id) REFERENCES contacts(id) ON DELETE SET NULL,
      FOREIGN KEY (website_id) REFERENCES websites(id) ON DELETE SET NULL
    );

    CREATE TABLE IF NOT EXISTS approvals (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      entity_type TEXT NOT NULL,
      entity_id INTEGER NOT NULL,
      content_hash TEXT NOT NULL,
      approval_kind TEXT NOT NULL,
      approved_by TEXT NOT NULL,
      approved_at TEXT NOT NULL,
      revoked_at TEXT,
      revoke_reason TEXT
    );

    CREATE TABLE IF NOT EXISTS send_attempts (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      message_id INTEGER NOT NULL,
      idempotency_key TEXT NOT NULL UNIQUE,
      provider_id TEXT NOT NULL,
      status TEXT NOT NULL,
      attempted_at TEXT NOT NULL,
      error TEXT,
      FOREIGN KEY (message_id) REFERENCES messages(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS suppressions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      normalized_contact TEXT NOT NULL,
      channel TEXT NOT NULL,
      reason TEXT NOT NULL DEFAULT 'User opt-out',
      created_at TEXT NOT NULL,
      UNIQUE(normalized_contact, channel)
    );

    CREATE TABLE IF NOT EXISTS tasks (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      campaign_id INTEGER,
      business_id INTEGER,
      task_type TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'queued',
      attempt_count INTEGER NOT NULL DEFAULT 0,
      max_attempts INTEGER NOT NULL DEFAULT 3,
      due_at TEXT NOT NULL,
      last_error TEXT,
      payload_json TEXT NOT NULL DEFAULT '{}',
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      FOREIGN KEY (campaign_id) REFERENCES campaigns(id) ON DELETE CASCADE,
      FOREIGN KEY (business_id) REFERENCES businesses(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS audit_events (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      entity_type TEXT NOT NULL,
      entity_id INTEGER NOT NULL,
      action TEXT NOT NULL,
      actor TEXT NOT NULL,
      created_at TEXT NOT NULL,
      safe_metadata TEXT NOT NULL DEFAULT '{}'
    );

    CREATE TABLE IF NOT EXISTS app_settings (
      key TEXT PRIMARY KEY,
      value TEXT NOT NULL
    );
  `);

  const defaults: Record<string, string> = {
    ui_language: 'en',
    ai_enabled: 'true',
    followup_default_enabled: 'false',
    followup_days: '6',
    agency_sender_name: 'Freshy Web Studio',
    agency_sender_email: 'studio@example.org',
  };

  const insertSetting = db.prepare('INSERT OR IGNORE INTO app_settings (key, value) VALUES (?, ?)');
  for (const [k, v] of Object.entries(defaults)) {
    insertSetting.run(k, v);
  }

  const campaignCount = (db.prepare('SELECT COUNT(*) as count FROM campaigns').get() as { count: number }).count;
  if (campaignCount === 0) {
    seedSampleDentalTrial(false);
  }
}

export function logAuditEvent(
  entityType: string,
  entityId: number,
  action: string,
  actor: string,
  metadata: Record<string, unknown> = {}
): void {
  const safeMeta = JSON.stringify(metadata);
  db.prepare(
    'INSERT INTO audit_events (entity_type, entity_id, action, actor, created_at, safe_metadata) VALUES (?, ?, ?, ?, ?, ?)'
  ).run(entityType, entityId, action, actor, new Date().toISOString(), safeMeta);
}

export function seedSampleDentalTrial(wipeExisting = false): { campaignId: number } {
  const now = new Date().toISOString();

  const runSeed = db.transaction(() => {
    if (wipeExisting) {
      db.exec(`
        DELETE FROM audit_events;
        DELETE FROM tasks;
        DELETE FROM suppressions;
        DELETE FROM send_attempts;
        DELETE FROM approvals;
        DELETE FROM messages;
        DELETE FROM qa_results;
        DELETE FROM websites;
        DELETE FROM permissions;
        DELETE FROM contacts;
        DELETE FROM facts;
        DELETE FROM sources;
        DELETE FROM campaign_businesses;
        DELETE FROM businesses;
        DELETE FROM campaigns;
      `);
    }

    const campRes = db
      .prepare(
        `INSERT INTO campaigns (name, area, category, language, output_type, max_leads, status, created_at, updated_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`
      )
      .run(
        'Section 9 Trial — Jaipur Dental Demo',
        'Vaishali Nagar, Jaipur',
        'Dental Clinic',
        'bilingual',
        'html',
        3,
        'active',
        now,
        now
      );
    const campaignId = Number(campRes.lastInsertRowid);

    // Lead 1: Sample Dental Studio (verified facts, missing email for QA warning/test)
    const b1Res = db
      .prepare(
        `INSERT INTO businesses (name, category, locality, address, official_url, normalized_identity, review_status, notes, created_at, updated_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
      )
      .run(
        'Sample Dental Studio',
        'Dental Clinic',
        'Vaishali Nagar, Jaipur',
        'Plot 14, Nursery Circle, Vaishali Nagar (Fictional Test Record)',
        'https://example.com/sample-dental-studio',
        normalizeIdentity('Sample Dental Studio', 'Vaishali Nagar, Jaipur'),
        'verified',
        'Section 9 fictional trial record. Real email intentionally omitted to verify QA missing-email check.',
        now,
        now
      );
    const b1Id = Number(b1Res.lastInsertRowid);

    db.prepare('INSERT INTO campaign_businesses (campaign_id, business_id, stage, selected_at) VALUES (?, ?, ?, ?)').run(
      campaignId,
      b1Id,
      'verified',
      now
    );

    const s1Id = Number(
      db
        .prepare('INSERT INTO sources (business_id, url, retrieved_at, permitted_use_notes) VALUES (?, ?, ?, ?)')
        .run(
          b1Id,
          'https://example.com/sample-dental-studio',
          now,
          'Fictional Section 9 trial source — safe for local concept demo testing.'
        ).lastInsertRowid
    );

    const insertFact = db.prepare(
      'INSERT INTO facts (business_id, field_name, value, source_id, verified_at, verification_status, confidence) VALUES (?, ?, ?, ?, ?, ?, ?)'
    );
    insertFact.run(
      b1Id,
      'services',
      'Routine Dental Checkups\nPreventive Hygiene & Scaling\nDigital X-Ray Diagnostics',
      s1Id,
      now,
      'verified',
      'high'
    );
    insertFact.run(b1Id, 'opening_hours', 'Mon–Sat 10:00 AM – 7:00 PM (Sample)', s1Id, now, 'verified', 'high');
    insertFact.run(
      b1Id,
      'about',
      'Sample Dental Studio is a fictional neighborhood clinic demonstration focused on transparent preventive care and calm patient visits.',
      s1Id,
      now,
      'verified',
      'high'
    );

    // Intentionally mark email as unknown / empty value for QA verification
    db.prepare(
      'INSERT INTO contacts (business_id, channel, value, source_id, verification_status, created_at) VALUES (?, ?, ?, ?, ?, ?)'
    ).run(b1Id, 'email', '', s1Id, 'unknown', now);

    // Lead 2: Marigold Smile Care (Sample) with verified test email for outreach/suppression flow
    const b2Res = db
      .prepare(
        `INSERT INTO businesses (name, category, locality, address, official_url, normalized_identity, review_status, notes, created_at, updated_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
      )
      .run(
        'Marigold Smile Care (Sample)',
        'Dental Clinic',
        'C-Scheme, Jaipur',
        '22 Ashok Marg, C-Scheme (Fictional Test Record)',
        'https://example.org/marigold-dental-demo',
        normalizeIdentity('Marigold Smile Care (Sample)', 'C-Scheme, Jaipur'),
        'researched',
        'Fictional clinic with verified test email for outreach approval and opt-out suppression testing.',
        now,
        now
      );
    const b2Id = Number(b2Res.lastInsertRowid);
    db.prepare('INSERT INTO campaign_businesses (campaign_id, business_id, stage, selected_at) VALUES (?, ?, ?, ?)').run(
      campaignId,
      b2Id,
      'researched',
      now
    );

    const s2Id = Number(
      db
        .prepare('INSERT INTO sources (business_id, url, retrieved_at, permitted_use_notes) VALUES (?, ?, ?, ?)')
        .run(
          b2Id,
          'https://example.org/marigold-dental-demo',
          now,
          'Fictional test clinic contact page; test email reserved under RFC 2606 example.org.'
        ).lastInsertRowid
    );

    insertFact.run(
      b2Id,
      'services',
      'Pediatric Preventive Care\nRestorative Consultations\nOral Hygiene Education',
      s2Id,
      now,
      'verified',
      'high'
    );
    insertFact.run(b2Id, 'opening_hours', 'Mon–Fri 9:30 AM – 6:30 PM (Sample)', s2Id, now, 'verified', 'medium');

    const c2Id = Number(
      db
        .prepare(
          'INSERT INTO contacts (business_id, channel, value, source_id, verification_status, created_at) VALUES (?, ?, ?, ?, ?, ?)'
        )
        .run(b2Id, 'email', 'contact@example.org', s2Id, 'verified', now).lastInsertRowid
    );

    db.prepare(
      'INSERT INTO permissions (contact_id, channel, scope, evidence, recorded_at) VALUES (?, ?, ?, ?, ?)'
    ).run(
      c2Id,
      'email',
      'one_to_one_demo_proposal',
      'Public business inquiry address listed on official example.org test page.',
      now
    );

    // Lead 3: Duplicate-check fictional record
    const b3Res = db
      .prepare(
        `INSERT INTO businesses (name, category, locality, address, official_url, normalized_identity, review_status, notes, created_at, updated_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
      )
      .run(
        'Arogya Dental & Implant (Sample)',
        'Dental Clinic',
        'Malviya Nagar, Jaipur',
        'Sector 4, Malviya Nagar (Fictional Test Record)',
        '',
        normalizeIdentity('Arogya Dental & Implant (Sample)', 'Malviya Nagar, Jaipur'),
        'review_required',
        'Awaiting manual source URL and contact verification before demo build.',
        now,
        now
      );
    const b3Id = Number(b3Res.lastInsertRowid);
    db.prepare('INSERT INTO campaign_businesses (campaign_id, business_id, stage, selected_at) VALUES (?, ?, ?, ?)').run(
      campaignId,
      b3Id,
      'review_required',
      now
    );

    // Seed an example queued task in orchestrator
    db.prepare(
      `INSERT INTO tasks (campaign_id, business_id, task_type, status, attempt_count, max_attempts, due_at, payload_json, created_at, updated_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    ).run(
      campaignId,
      b1Id,
      'website_build',
      'queued',
      0,
      3,
      now,
      JSON.stringify({ template_key: 'dental', language: 'bilingual', output_type: 'html' }),
      now,
      now
    );

    // Seed an opt-out example suppression for a separate sample contact
    db.prepare(
      'INSERT OR IGNORE INTO suppressions (normalized_contact, channel, reason, created_at) VALUES (?, ?, ?, ?)'
    ).run(
      normalizeContact('email', 'opted-out@example.org'),
      'email',
      'Section 9 sample opt-out suppression test address',
      now
    );

    logAuditEvent('campaign', campaignId, 'trial_seeded', 'system', {
      name: 'Section 9 Trial — Jaipur Dental Demo',
      leads: 3,
    });

    return { campaignId };
  });

  return runSeed();
}

export function computeWebsiteContentHash(fields: {
  template_key: string;
  language: string;
  output_type: string;
  headline: string;
  subheadline: string;
  about_copy: string;
  services_json: string;
  cta_label: string;
}): string {
  return sha256(
    JSON.stringify({
      template_key: fields.template_key,
      language: fields.language,
      output_type: fields.output_type,
      headline: fields.headline,
      subheadline: fields.subheadline,
      about_copy: fields.about_copy,
      services_json: fields.services_json,
      cta_label: fields.cta_label,
    })
  );
}

export function computeMessageContentHash(fields: {
  contact_id: number | null;
  recipient: string;
  channel: string;
  purpose: string;
  subject: string;
  body: string;
  attachment_note: string;
}): string {
  return sha256(
    JSON.stringify({
      contact_id: fields.contact_id,
      recipient: fields.recipient,
      channel: fields.channel,
      purpose: fields.purpose,
      subject: fields.subject,
      body: fields.body,
      attachment_note: fields.attachment_note,
    })
  );
}

const BACKUP_TABLES = [
  'campaigns',
  'businesses',
  'campaign_businesses',
  'sources',
  'facts',
  'contacts',
  'permissions',
  'websites',
  'qa_results',
  'messages',
  'approvals',
  'send_attempts',
  'suppressions',
  'tasks',
  'audit_events',
  'app_settings',
] as const;

export function exportFullBackup(): Record<string, unknown> {
  const tables: Record<string, unknown[]> = {};
  for (const table of BACKUP_TABLES) {
    tables[table] = db.prepare(`SELECT * FROM ${table}`).all();
  }
  return {
    schema_version: 1,
    exported_at: new Date().toISOString(),
    app: 'Freshy AI',
    tables,
  };
}

export function restoreFullBackup(payload: unknown): { restoredRows: number } {
  if (!payload || typeof payload !== 'object') {
    throw new Error('Invalid backup payload.');
  }
  const obj = payload as { schema_version?: number; tables?: Record<string, unknown[]> };
  if (obj.schema_version !== 1 || !obj.tables || typeof obj.tables !== 'object') {
    throw new Error('Unsupported backup format or missing tables object.');
  }

  let restoredRows = 0;
  const runRestore = db.transaction(() => {
    db.pragma('foreign_keys = OFF');
    try {
      for (const table of [...BACKUP_TABLES].reverse()) {
        db.prepare(`DELETE FROM ${table}`).run();
      }
      for (const table of BACKUP_TABLES) {
        const rows = obj.tables?.[table];
        if (!Array.isArray(rows) || rows.length === 0) continue;
        const columnsInfo = db.prepare(`PRAGMA table_info(${table})`).all() as Array<{ name: string }>;
        const validCols = new Set(columnsInfo.map((c) => c.name));
        for (const row of rows) {
          if (!row || typeof row !== 'object') continue;
          const record = row as Record<string, unknown>;
          const cols = Object.keys(record).filter((k) => validCols.has(k));
          if (cols.length === 0) continue;
          const placeholders = cols.map(() => '?').join(', ');
          const stmt = db.prepare(`INSERT INTO ${table} (${cols.join(', ')}) VALUES (${placeholders})`);
          stmt.run(...cols.map((c) => record[c] ?? null));
          restoredRows += 1;
        }
      }
    } finally {
      db.pragma('foreign_keys = ON');
    }
    logAuditEvent('system', 0, 'backup_restored', 'operator', { restoredRows });
  });

  runRestore();
  return { restoredRows };
}
