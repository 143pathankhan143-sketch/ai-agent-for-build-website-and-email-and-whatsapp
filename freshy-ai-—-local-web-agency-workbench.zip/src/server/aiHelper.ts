import { GoogleGenAI, Type } from '@google/genai';
import type { ContentLanguage, FactRecord, TemplateKey } from '../shared/types.ts';

function getClient(): GoogleGenAI | null {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey || apiKey === 'MY_GEMINI_API_KEY') {
    return null;
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

export function isAiAvailable(): boolean {
  const apiKey = process.env.GEMINI_API_KEY;
  return Boolean(apiKey && apiKey !== 'MY_GEMINI_API_KEY');
}

export interface AiWebsiteCopyResult {
  usedAi: boolean;
  reason?: string;
  headline: string;
  subheadline: string;
  about_copy: string;
  cta_label: string;
}

export async function generateWebsiteCopyWithAi(params: {
  businessName: string;
  category: string;
  locality: string;
  templateKey: TemplateKey;
  language: ContentLanguage;
  verifiedFacts: FactRecord[];
  fallback: {
    headline: string;
    subheadline: string;
    about_copy: string;
    cta_label: string;
  };
}): Promise<AiWebsiteCopyResult> {
  const ai = getClient();
  if (!ai) {
    return {
      usedAi: false,
      reason: 'GEMINI_API_KEY is not configured; deterministic template copy preserved.',
      ...params.fallback,
    };
  }

  const factsSummary = params.verifiedFacts
    .filter((f) => f.verification_status === 'verified')
    .map((f) => `${f.field_name}: ${f.value}`)
    .join('\n');

  const langDirective =
    params.language === 'hi'
      ? 'Write all fields in natural, respectful Hindi (Devanagari script).'
      : params.language === 'bilingual'
        ? 'Write clear bilingual English + Hindi copy (e.g. English headline paired concisely with Hindi, or balanced Hindi/English phrases).'
        : 'Write all fields in crisp, professional English.';

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-4-hydrogen',
      contents: `Business Name: ${params.businessName}
Category: ${params.category}
Locality: ${params.locality}
Template: ${params.templateKey}
Verified Facts:
${factsSummary || 'No extra verified facts supplied beyond name, category, and locality.'}

${langDirective}`,
      config: {
        systemInstruction:
          'You are writing copy for an unofficial concept demo website. STRICT RULES: Never invent doctor names, licenses, treatment outcomes, prices, opening hours, customer reviews, awards, or phone numbers. Rely ONLY on the verified facts provided. If something is missing, keep copy general and honest. Return concise JSON matching the schema.',
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            headline: { type: Type.STRING, description: 'Short hero headline (max 12 words).' },
            subheadline: { type: Type.STRING, description: 'Concise 1-sentence subheadline grounded in verified facts.' },
            about_copy: { type: Type.STRING, description: '2-3 factual sentences describing the business without unverified claims.' },
            cta_label: { type: Type.STRING, description: 'Short CTA button text such as Concept Inquiry Preview.' },
          },
          required: ['headline', 'subheadline', 'about_copy', 'cta_label'],
        },
      },
    });

    const parsed = JSON.parse((response.text ?? '{}').trim()) as Partial<{
      headline: string;
      subheadline: string;
      about_copy: string;
      cta_label: string;
    }>;

    return {
      usedAi: true,
      headline: parsed.headline?.trim() || params.fallback.headline,
      subheadline: parsed.subheadline?.trim() || params.fallback.subheadline,
      about_copy: parsed.about_copy?.trim() || params.fallback.about_copy,
      cta_label: parsed.cta_label?.trim() || params.fallback.cta_label,
    };
  } catch (err) {
    return {
      usedAi: false,
      reason: err instanceof Error ? err.message : 'AI generation failed; deterministic template copy preserved.',
      ...params.fallback,
    };
  }
}

export interface AiOutreachResult {
  usedAi: boolean;
  reason?: string;
  subject: string;
  body: string;
}

export async function generateOutreachWithAi(params: {
  businessName: string;
  locality: string;
  category: string;
  senderName: string;
  channel: 'email' | 'whatsapp_link';
  language: 'en' | 'hi';
  demoReference: string;
  fallbackSubject: string;
  fallbackBody: string;
}): Promise<AiOutreachResult> {
  const ai = getClient();
  if (!ai) {
    return {
      usedAi: false,
      reason: 'GEMINI_API_KEY is not configured; deterministic outreach template preserved.',
      subject: params.fallbackSubject,
      body: params.fallbackBody,
    };
  }

  const langInstruction =
    params.language === 'hi'
      ? 'Write the message in polite, concise Hindi (Devanagari script).'
      : 'Write the message in polite, concise English.';

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-4-hydrogen',
      contents: `Recipient Business: ${params.businessName} (${params.category}, ${params.locality})
Sender: ${params.senderName}
Channel: ${params.channel}
Concept Demo Reference: ${params.demoReference}
${langInstruction}`,
      config: {
        systemInstruction:
          'Draft an honest, zero-pressure 1-to-1 outreach message introducing an unofficial concept website demo. STRICT RULES: Never claim affiliation ("we are your agency" is forbidden). State clearly it is an unofficial concept demo. Include a simple one-line opt-out instruction (reply "Stop" or "Opt out"). Do not invent metrics, guarantees, or tracking pixels.',
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            subject: { type: Type.STRING, description: 'Honest, concise email subject line.' },
            body: { type: Type.STRING, description: 'Short 3-paragraph message body including unofficial demo notice and opt-out line.' },
          },
          required: ['subject', 'body'],
        },
      },
    });

    const parsed = JSON.parse((response.text ?? '{}').trim()) as Partial<{ subject: string; body: string }>;
    return {
      usedAi: true,
      subject: parsed.subject?.trim() || params.fallbackSubject,
      body: parsed.body?.trim() || params.fallbackBody,
    };
  } catch (err) {
    return {
      usedAi: false,
      reason: err instanceof Error ? err.message : 'AI drafting failed; deterministic template preserved.',
      subject: params.fallbackSubject,
      body: params.fallbackBody,
    };
  }
}
