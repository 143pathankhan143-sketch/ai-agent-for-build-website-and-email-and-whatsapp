import crypto from 'node:crypto';
import dns from 'node:dns/promises';
import net from 'node:net';

export function sha256(value: string): string {
  return crypto.createHash('sha256').update(value, 'utf8').digest('hex');
}

export function escapeHtml(input: string): string {
  return String(input ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

export function normalizeText(value: string): string {
  return String(value ?? '')
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9\u0900-\u097f]+/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

export function normalizeIdentity(name: string, locality: string): string {
  return `${normalizeText(name)}::${normalizeText(locality)}`;
}

export function normalizeContact(channel: string, value: string): string {
  const trimmed = String(value ?? '').trim().toLowerCase();
  if (channel === 'email') return trimmed;
  if (channel === 'whatsapp_link') return trimmed.replace(/\/+$/, '');
  return trimmed.replace(/[\s\-().]+/g, '');
}

export function isPrivateOrReservedIp(ip: string): boolean {
  if (!net.isIP(ip)) return true;

  // Handle IPv4-mapped IPv6 like ::ffff:127.0.0.1
  if (ip.includes(':') && ip.toLowerCase().startsWith('::ffff:')) {
    const v4 = ip.slice(7);
    if (net.isIPv4(v4)) return isPrivateOrReservedIp(v4);
  }

  if (net.isIPv4(ip)) {
    const parts = ip.split('.').map(Number);
    if (parts.length !== 4) return true;
    const [a, b] = parts;
    if (a === 0) return true; // 0.0.0.0/8
    if (a === 10) return true; // 10.0.0.0/8
    if (a === 127) return true; // 127.0.0.0/8 loopback
    if (a === 169 && b === 254) return true; // 169.254.0.0/16 link-local / cloud metadata
    if (a === 172 && b >= 16 && b <= 31) return true; // 172.16.0.0/12
    if (a === 192 && b === 168) return true; // 192.168.0.0/16
    if (a === 100 && b >= 64 && b <= 127) return true; // 100.64.0.0/10 CGNAT
    if (a >= 224) return true; // multicast/reserved
    return false;
  }

  // IPv6 checks
  const lower = ip.toLowerCase();
  if (lower === '::' || lower === '::1') return true;
  if (lower.startsWith('fe80:') || lower.startsWith('fc') || lower.startsWith('fd')) return true;
  return false;
}

export async function validateSafeExternalUrl(rawUrl: string): Promise<URL> {
  let parsed: URL;
  try {
    parsed = new URL(rawUrl.trim());
  } catch {
    throw new Error('Invalid URL format.');
  }

  if (parsed.protocol !== 'http:' && parsed.protocol !== 'https:') {
    throw new Error('Only http:// and https:// URLs are permitted.');
  }

  const host = parsed.hostname.toLowerCase();
  if (!host) {
    throw new Error('Missing URL hostname.');
  }

  if (
    host === 'localhost' ||
    host.endsWith('.localhost') ||
    host.endsWith('.local') ||
    host.endsWith('.internal') ||
    host === 'metadata.google.internal'
  ) {
    throw new Error('Localhost and internal hostnames are blocked for safety.');
  }

  if (net.isIP(host)) {
    if (isPrivateOrReservedIp(host)) {
      throw new Error('Private, loopback, and link-local IP addresses are blocked.');
    }
    return parsed;
  }

  const resolved = await dns.lookup(host, { all: true });
  if (!resolved.length) {
    throw new Error('Could not resolve target hostname.');
  }
  for (const entry of resolved) {
    if (isPrivateOrReservedIp(entry.address)) {
      throw new Error('Target hostname resolves to a blocked private or local IP range.');
    }
  }
  return parsed;
}

export interface SafeFetchResult {
  finalUrl: string;
  title: string;
  description: string;
  emails: string[];
  whatsappLinks: string[];
  bytesRead: number;
}

export async function safeFetchPublicPage(rawUrl: string): Promise<SafeFetchResult> {
  const MAX_REDIRECTS = 3;
  const MAX_BYTES = 512 * 1024;
  const TIMEOUT_MS = 6000;

  let currentUrl = (await validateSafeExternalUrl(rawUrl)).toString();
  let response: Response | null = null;

  for (let hop = 0; hop <= MAX_REDIRECTS; hop++) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), TIMEOUT_MS);
    try {
      response = await fetch(currentUrl, {
        method: 'GET',
        redirect: 'manual',
        signal: controller.signal,
        headers: {
          'User-Agent': 'FreshyAI-SafeResearch/1.0 (Manual User Trigger)',
          Accept: 'text/html,application/xhtml+xml;q=0.9,text/plain;q=0.8',
        },
      });
    } finally {
      clearTimeout(timer);
    }

    if (response.status >= 300 && response.status < 400) {
      const location = response.headers.get('location');
      if (!location) {
        throw new Error('Redirect response missing Location header.');
      }
      const nextUrl = new URL(location, currentUrl).toString();
      currentUrl = (await validateSafeExternalUrl(nextUrl)).toString();
      continue;
    }

    break;
  }

  if (!response || !response.ok) {
    throw new Error(`Target returned HTTP ${response ? response.status : 'error'}.`);
  }

  const contentType = response.headers.get('content-type') || '';
  if (!contentType.includes('text/html') && !contentType.includes('text/plain') && !contentType.includes('xhtml')) {
    throw new Error('Unsupported content type; only HTML or plain text pages can be inspected.');
  }

  const reader = response.body?.getReader();
  if (!reader) {
    throw new Error('Empty response body.');
  }

  const chunks: Uint8Array[] = [];
  let total = 0;
  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    if (value) {
      total += value.byteLength;
      if (total > MAX_BYTES) {
        await reader.cancel();
        break;
      }
      chunks.push(value);
    }
  }

  const buffer = Buffer.concat(chunks.map((c) => Buffer.from(c)));
  const html = buffer.toString('utf8');

  const titleMatch = html.match(/<title[^>]*>([\s\S]*?)<\/title>/i);
  const title = titleMatch ? titleMatch[1].replace(/\s+/g, ' ').trim().slice(0, 180) : '';

  const descMatch =
    html.match(/<meta[^>]*name=["']description["'][^>]*content=["']([^"']*)["']/i) ||
    html.match(/<meta[^>]*content=["']([^"']*)["'][^>]*name=["']description["']/i);
  const description = descMatch ? descMatch[1].replace(/\s+/g, ' ').trim().slice(0, 360) : '';

  const mailtoMatches = [...html.matchAll(/mailto:([a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,})/gi)].map(
    (m) => m[1].toLowerCase()
  );
  const emails = Array.from(new Set(mailtoMatches)).slice(0, 5);

  const waMatches = [...html.matchAll(/https?:\/\/(?:wa\.me|api\.whatsapp\.com)\/[a-zA-Z0-9?=&_%+-]+/gi)].map(
    (m) => m[0]
  );
  const whatsappLinks = Array.from(new Set(waMatches)).slice(0, 3);

  return {
    finalUrl: currentUrl,
    title,
    description,
    emails,
    whatsappLinks,
    bytesRead: total,
  };
}
