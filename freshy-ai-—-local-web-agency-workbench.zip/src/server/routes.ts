import express from 'express';
import type { Request, Response } from 'express';
import {
  computeMessageContentHash,
  computeWebsiteContentHash,
  db,
  exportFullBackup,
  logAuditEvent,
  restoreFullBackup,
  seedSampleDentalTrial,
} from './db.ts';
import {
  generateOutreachWithAi,
  generateWebsiteCopyWithAi,
  isAiAvailable,
} from './aiHelper.ts';
import {
  normalizeContact,
  normalizeIdentity,
  safeFetchPublicPage,
  sha256,
} from './security.ts';
import {
  buildDeterministicWebsiteCopy,
  buildWebsiteZipBuffer,
  inferTemplateKey,
  renderWebsiteHtml,
  runWebsiteQaChecks,
} from './websiteBuilder.ts';
import type {
  AppSettings,
  ApprovalRecord,
  Business,
  Campaign,
  ContactRecord,
  ContentLanguage,
  FactRecord,
  MessageRecord,
  OutputType,
  QaResultRecord,
  SourceRecord,
  TemplateKey,
  WebsiteRecord,
} from '../shared/types.ts';

function getSetting(key: string, fallback = ''): string {
  const row = db.prepare('SELECT value FROM app_settings WHERE key = ?').get(key) as { value: string } | undefined;
  return row ? row.value : fallback;
}

function getAllSettings(): AppSettings {
  return {
    ui_language: getSetting('ui_language', 'en') === 'hi' ? 'hi' : 'en',
    ai_enabled: getSetting('ai_enabled', 'true') === 'true',
    ai_available: isAiAvailable(),
    followup_default_enabled: getSetting('followup_default_enabled', 'false') === 'true',
    followup_days: Number(getSetting('followup_days', '6')) || 6,
    agency_sender_name: getSetting('agency_sender_name', 'Freshy Web Studio'),
    agency_sender_email: getSetting('agency_sender_email', 'studio@example.org'),
  };
}

function isContactSuppressed(channel: string, value: string): boolean {
  if (!value || !value.trim()) return false;
  const norm = normalizeContact(channel, value);
  const row = db
    .prepare('SELECT id FROM suppressions WHERE normalized_contact = ? AND channel = ?')
    .get(norm, channel);
  return Boolean(row);
}

function computeMessageBlockers(msg: MessageRecord): string[] {
  const blockers: string[] = [];
  if (!msg.contact_id || !msg.contact_value || !msg.contact_value.trim()) {
    blockers.push('Recipient contact address/link is missing.');
  } else {
    if (msg.contact_verification_status !== 'verified') {
      blockers.push(`Recipient contact status is "${msg.contact_verification_status || 'unknown'}" (must be verified).`);
    }
    if (isContactSuppressed(msg.channel, msg.contact_value)) {
      blockers.push('Recipient is on the opt-out suppression list.');
    }
    if (msg.channel === 'whatsapp_link' && !msg.contact_value.includes('wa.me') && !msg.contact_value.includes('whatsapp.com')) {
      blockers.push('WhatsApp outreach requires a published public WhatsApp link, not a plain phone number.');
    }
    const perm = db
      .prepare('SELECT id FROM permissions WHERE contact_id = ? AND revoked_at IS NULL')
      .get(msg.contact_id);
    if (!perm) {
      blockers.push('No active permission/consent evidence recorded for this contact.');
    }
  }

  if (!msg.website_id) {
    blockers.push('No linked concept website demo selected.');
  } else if (msg.website_status !== 'approved' && msg.website_status !== 'publish_review' && msg.website_status !== 'published') {
    blockers.push(`Linked concept website status is "${msg.website_status}" (website approval required first).`);
  }

  const hasDemoDelivery =
    (msg.website_public_url && msg.website_public_url.trim().startsWith('http')) ||
    (msg.attachment_note && msg.attachment_note.trim().length > 0 && !msg.attachment_note.includes('localhost'));
  if (!hasDemoDelivery) {
    blockers.push('Provide an approved public demo URL or explicit ZIP/attachment delivery note (never send local file paths).');
  }

  if (msg.body.includes('http://localhost') || msg.body.includes('file://')) {
    blockers.push('Message body contains a local file/localhost link which recipients cannot open.');
  }

  return blockers;
}

function buildDeterministicOutreachText(params: {
  business: Business;
  channel: 'email' | 'whatsapp_link';
  language: 'en' | 'hi';
  senderName: string;
  demoRef: string;
  purpose: 'initial_demo' | 'follow_up';
}): { subject: string; body: string } {
  const { business, language, senderName, demoRef, purpose } = params;

  if (language === 'hi') {
    if (purpose === 'follow_up') {
      return {
        subject: `फ़ॉलो-अप: ${business.name} के लिए अनौपचारिक वेबसाइट कॉन्सेप्ट डेमो`,
        body: `नमस्ते ${business.name} टीम,\n\nपिछले सप्ताह हमने आपके व्यवसाय (${business.locality}) के सार्वजनिक रूप से उपलब्ध विवरण के आधार पर एक अनौपचारिक कॉन्सेप्ट वेबसाइट डेमो साझा किया था (${demoRef})।\n\nयह केवल एक विनम्र फ़ॉलो-अप है। यदि आप समीक्षा करना चाहें तो उत्तर दें।\n\nयदि आप आगे कोई संदेश नहीं चाहते, तो कृपया "Stop" या "Opt out" लिखकर उत्तर दें — हम तुरंत संपर्क बंद कर देंगे।\n\nसादर,\n${senderName}`,
      };
    }
    return {
      subject: `${business.name} के लिए अनौपचारिक कॉन्सेप्ट वेबसाइट डेमो`,
      body: `नमस्ते ${business.name} टीम,\n\nमैं ${senderName} से हूँ (हम आपकी आधिकारिक एजेंसी होने का दावा नहीं करते)। हमने ${business.locality} में आपके व्यवसाय के सत्यापित सार्वजनिक विवरण के आधार पर एक छोटा अनौपचारिक कॉन्सेप्ट वेबसाइट डेमो तैयार किया है: ${demoRef}\n\nयदि आप चाहें तो हम इसे आपकी वास्तविक सामग्री के अनुसार नि:शुल्क दिखा सकते हैं या सुधार सकते हैं।\n\nयदि आप भविष्य में कोई संदेश नहीं चाहते, तो कृपया "Stop" या "Opt out" लिखकर उत्तर दें।\n\nसादर,\n${senderName}`,
    };
  }

  if (purpose === 'follow_up') {
    return {
      subject: `Follow-up: Unofficial concept website demo for ${business.name}`,
      body: `Hello ${business.name} team,\n\nFollowing up briefly on the unofficial concept website demo we prepared for your ${business.category} profile in ${business.locality} (${demoRef}).\n\nIf you would like to review or request edits, feel free to reply here.\n\nIf you prefer not to receive messages from us, reply "Opt out" or "Stop" and we will suppress further outreach immediately.\n\nBest regards,\n${senderName}`,
    };
  }

  return {
    subject: `Unofficial concept website demo for ${business.name}`,
    body: `Hello ${business.name} team,\n\nI am writing from ${senderName} (independent studio — not affiliated with or representing your business). Based strictly on your publicly listed business details in ${business.locality}, we put together a clean, unofficial concept website preview: ${demoRef}\n\nIf this direction looks useful, I would be glad to share the preview or adjust it with your verified details.\n\nIf you do not wish to hear from us again, simply reply "Opt out" or "Stop" and your contact will be removed from future outreach.\n\nBest regards,\n${senderName}`,
  };
}

export function createApiRouter(): express.Router {
  const router = express.Router();

  // 1. Overview
  router.get('/overview', (_req: Request, res: Response) => {
    const campaignsCount = (db.prepare('SELECT COUNT(*) as c FROM campaigns').get() as { c: number }).c;
    const activeCampaign = db.prepare('SELECT * FROM campaigns ORDER BY id DESC LIMIT 1').get() as Campaign | undefined;
    const leadsTotal = (db.prepare('SELECT COUNT(*) as c FROM businesses').get() as { c: number }).c;
    const leadsVerified = (
      db.prepare("SELECT COUNT(*) as c FROM businesses WHERE review_status = 'verified'").get() as { c: number }
    ).c;
    const leadsReviewRequired = (
      db.prepare("SELECT COUNT(*) as c FROM businesses WHERE review_status = 'review_required'").get() as { c: number }
    ).c;
    const websitesTotal = (db.prepare('SELECT COUNT(*) as c FROM websites').get() as { c: number }).c;
    const websitesNeedingReview = (
      db
        .prepare("SELECT COUNT(*) as c FROM websites WHERE status IN ('draft', 'qa_failed', 'review_required')")
        .get() as { c: number }
    ).c;
    const websitesApproved = (
      db
        .prepare("SELECT COUNT(*) as c FROM websites WHERE status IN ('approved', 'publish_review', 'published')")
        .get() as { c: number }
    ).c;
    const messagesAwaitingApproval = (
      db.prepare("SELECT COUNT(*) as c FROM messages WHERE status IN ('draft', 'review_required')").get() as {
        c: number;
      }
    ).c;
    const messagesSent = (db.prepare("SELECT COUNT(*) as c FROM messages WHERE status = 'sent'").get() as { c: number })
      .c;
    const suppressionsCount = (db.prepare('SELECT COUNT(*) as c FROM suppressions').get() as { c: number }).c;
    const tasksFailed = (db.prepare("SELECT COUNT(*) as c FROM tasks WHERE status = 'failed'").get() as { c: number }).c;
    const tasksQueued = (db.prepare("SELECT COUNT(*) as c FROM tasks WHERE status = 'queued'").get() as { c: number }).c;
    const recentAudit = db.prepare('SELECT * FROM audit_events ORDER BY id DESC LIMIT 15').all();

    res.json({
      campaigns_count: campaignsCount,
      active_campaign: activeCampaign || null,
      leads_total: leadsTotal,
      leads_verified: leadsVerified,
      leads_review_required: leadsReviewRequired,
      websites_total: websitesTotal,
      websites_needing_review: websitesNeedingReview,
      websites_approved: websitesApproved,
      messages_awaiting_approval: messagesAwaitingApproval,
      messages_sent: messagesSent,
      suppressions_count: suppressionsCount,
      tasks_failed: tasksFailed,
      tasks_queued: tasksQueued,
      recent_audit: recentAudit,
    });
  });

  // 2. Campaigns
  router.get('/campaigns', (_req: Request, res: Response) => {
    const rows = db
      .prepare(
        `SELECT c.*, (SELECT COUNT(*) FROM campaign_businesses cb WHERE cb.campaign_id = c.id) as lead_count
         FROM campaigns c ORDER BY c.id DESC`
      )
      .all();
    res.json(rows);
  });

  router.post('/campaigns', (req: Request, res: Response) => {
    const { name, area, category, language, output_type, max_leads } = req.body as {
      name?: string;
      area?: string;
      category?: string;
      language?: ContentLanguage;
      output_type?: OutputType;
      max_leads?: number;
    };

    if (!area?.trim() || !category?.trim()) {
      res.status(400).json({ error: 'City/area and business category are required.' });
      return;
    }

    const now = new Date().toISOString();
    const safeName = name?.trim() || `${area.trim()} — ${category.trim()}`;
    const cap = Math.min(Math.max(Number(max_leads) || 3, 1), 100);
    const lang: ContentLanguage = language === 'hi' || language === 'en' ? language : 'bilingual';
    const out: OutputType = output_type === 'react' ? 'react' : 'html';

    const result = db
      .prepare(
        `INSERT INTO campaigns (name, area, category, language, output_type, max_leads, status, created_at, updated_at)
         VALUES (?, ?, ?, ?, ?, ?, 'active', ?, ?)`
      )
      .run(safeName, area.trim(), category.trim(), lang, out, cap, now, now);

    const id = Number(result.lastInsertRowid);
    logAuditEvent('campaign', id, 'campaign_created', 'operator', { area: area.trim(), category: category.trim(), cap });
    const created = db.prepare('SELECT * FROM campaigns WHERE id = ?').get(id);
    res.status(201).json(created);
  });

  router.patch('/campaigns/:id/status', (req: Request, res: Response) => {
    const id = Number(req.params.id);
    const { status } = req.body as { status?: 'active' | 'paused' | 'completed' };
    if (!['active', 'paused', 'completed'].includes(status || '')) {
      res.status(400).json({ error: 'Invalid campaign status.' });
      return;
    }
    const now = new Date().toISOString();
    db.prepare('UPDATE campaigns SET status = ?, updated_at = ? WHERE id = ?').run(status, now, id);
    if (status === 'paused') {
      db.prepare("UPDATE tasks SET status = 'paused', updated_at = ? WHERE campaign_id = ? AND status = 'queued'").run(
        now,
        id
      );
    } else if (status === 'active') {
      db.prepare("UPDATE tasks SET status = 'queued', updated_at = ? WHERE campaign_id = ? AND status = 'paused'").run(
        now,
        id
      );
    }
    logAuditEvent('campaign', id, `campaign_${status}`, 'operator');
    res.json(db.prepare('SELECT * FROM campaigns WHERE id = ?').get(id));
  });

  // 3. Leads
  router.get('/leads', (req: Request, res: Response) => {
    const campaignId = req.query.campaignId ? Number(req.query.campaignId) : null;
    const rows = db
      .prepare(
        `SELECT b.*,
          cb.campaign_id,
          c.name as campaign_name,
          (SELECT value FROM contacts ct WHERE ct.business_id = b.id AND ct.channel = 'email' ORDER BY ct.id DESC LIMIT 1) as primary_email,
          (SELECT verification_status FROM contacts ct WHERE ct.business_id = b.id AND ct.channel = 'email' ORDER BY ct.id DESC LIMIT 1) as email_status,
          (SELECT COUNT(*) FROM websites w WHERE w.business_id = b.id) as website_count,
          (SELECT status FROM websites w WHERE w.business_id = b.id ORDER BY w.version DESC, w.id DESC LIMIT 1) as latest_website_status
         FROM businesses b
         LEFT JOIN campaign_businesses cb ON cb.business_id = b.id
         LEFT JOIN campaigns c ON c.id = cb.campaign_id
         ${campaignId ? 'WHERE cb.campaign_id = ?' : ''}
         ORDER BY b.id DESC`
      )
      .all(...(campaignId ? [campaignId] : [])) as Business[];

    const enriched = rows.map((r) => ({
      ...r,
      suppressed: r.primary_email ? isContactSuppressed('email', r.primary_email) : false,
    }));
    res.json(enriched);
  });

  function insertLeadRecord(input: {
    campaignId?: number | null;
    name: string;
    category: string;
    locality: string;
    address?: string;
    official_url?: string;
    source_url?: string;
    permitted_use_notes?: string;
    email?: string;
    notes?: string;
  }) {
    const now = new Date().toISOString();
    const normId = normalizeIdentity(input.name, input.locality);

    // Check duplicate by normalized_identity OR matching email contact
    const dupByIdentity = db
      .prepare('SELECT id, name FROM businesses WHERE normalized_identity = ? LIMIT 1')
      .get(normId) as { id: number; name: string } | undefined;

    let dupByContact: { id: number; business_id: number } | undefined;
    if (input.email && input.email.trim()) {
      const normEmail = normalizeContact('email', input.email);
      const allEmails = db.prepare("SELECT id, business_id, value FROM contacts WHERE channel = 'email'").all() as Array<{
        id: number;
        business_id: number;
        value: string;
      }>;
      dupByContact = allEmails.find((e) => normalizeContact('email', e.value) === normEmail);
    }

    const isDuplicate = Boolean(dupByIdentity || dupByContact);
    const reviewStatus = isDuplicate ? 'review_required' : 'new';
    const dupNote = isDuplicate
      ? `Potential duplicate detected (${dupByIdentity ? `matching name+locality with #${dupByIdentity.id}` : `matching email with business #${dupByContact?.business_id}`}). Auto-merge disabled; manual review required.`
      : '';

    const combinedNotes = [input.notes?.trim(), dupNote].filter(Boolean).join(' | ');

    const resInsert = db
      .prepare(
        `INSERT INTO businesses (name, category, locality, address, official_url, normalized_identity, review_status, notes, created_at, updated_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
      )
      .run(
        input.name.trim(),
        input.category.trim(),
        input.locality.trim(),
        (input.address || '').trim(),
        (input.official_url || '').trim(),
        normId,
        reviewStatus,
        combinedNotes,
        now,
        now
      );
    const businessId = Number(resInsert.lastInsertRowid);

    if (input.campaignId) {
      db.prepare(
        'INSERT OR IGNORE INTO campaign_businesses (campaign_id, business_id, stage, selected_at) VALUES (?, ?, ?, ?)'
      ).run(input.campaignId, businessId, reviewStatus, now);
    }

    let sourceId: number | null = null;
    const srcUrl = (input.source_url || input.official_url || '').trim();
    if (srcUrl) {
      const srcRes = db
        .prepare('INSERT INTO sources (business_id, url, retrieved_at, permitted_use_notes) VALUES (?, ?, ?, ?)')
        .run(
          businessId,
          srcUrl,
          now,
          (input.permitted_use_notes || 'Operator supplied source URL').trim()
        );
      sourceId = Number(srcRes.lastInsertRowid);
    }

    if (input.email && input.email.trim()) {
      db.prepare(
        'INSERT INTO contacts (business_id, channel, value, source_id, verification_status, created_at) VALUES (?, ?, ?, ?, ?, ?)'
      ).run(businessId, 'email', input.email.trim(), sourceId, 'unverified', now);
    }

    logAuditEvent('business', businessId, 'lead_added', 'operator', {
      duplicateFlagged: isDuplicate,
      campaignId: input.campaignId ?? null,
    });

    return { businessId, isDuplicate, dupNote };
  }

  router.post('/leads', (req: Request, res: Response) => {
    const body = req.body as {
      campaign_id?: number;
      name?: string;
      category?: string;
      locality?: string;
      address?: string;
      official_url?: string;
      source_url?: string;
      permitted_use_notes?: string;
      email?: string;
      notes?: string;
    };

    if (!body.name?.trim() || !body.category?.trim() || !body.locality?.trim()) {
      res.status(400).json({ error: 'Business name, category, and locality are required.' });
      return;
    }

    const result = insertLeadRecord({
      campaignId: body.campaign_id ? Number(body.campaign_id) : null,
      name: body.name,
      category: body.category,
      locality: body.locality,
      address: body.address,
      official_url: body.official_url,
      source_url: body.source_url,
      permitted_use_notes: body.permitted_use_notes,
      email: body.email,
      notes: body.notes,
    });

    const created = db.prepare('SELECT * FROM businesses WHERE id = ?').get(result.businessId);
    res.status(201).json({ lead: created, duplicate_flagged: result.isDuplicate, duplicate_note: result.dupNote });
  });

  router.post('/leads/import-csv', (req: Request, res: Response) => {
    const { csv_text, campaign_id } = req.body as { csv_text?: string; campaign_id?: number };
    if (!csv_text || !csv_text.trim()) {
      res.status(400).json({ error: 'CSV content is empty.' });
      return;
    }

    const lines = csv_text
      .split(/\r?\n/)
      .map((l) => l.trim())
      .filter(Boolean);

    if (lines.length < 2) {
      res.status(400).json({ error: 'CSV must include a header row and at least one data row.' });
      return;
    }

    const parseCsvLine = (line: string): string[] => {
      const cols: string[] = [];
      let current = '';
      let inQuotes = false;
      for (let i = 0; i < line.length; i++) {
        const ch = line[i];
        if (ch === '"') {
          if (inQuotes && line[i + 1] === '"') {
            current += '"';
            i++;
          } else {
            inQuotes = !inQuotes;
          }
        } else if (ch === ',' && !inQuotes) {
          cols.push(current.trim());
          current = '';
        } else {
          current += ch;
        }
      }
      cols.push(current.trim());
      return cols;
    };

    const headers = parseCsvLine(lines[0]).map((h) => h.toLowerCase());
    const idxName = headers.indexOf('name');
    const idxCat = headers.indexOf('category');
    const idxLoc = headers.indexOf('locality');
    if (idxName === -1 || idxCat === -1 || idxLoc === -1) {
      res.status(400).json({ error: 'CSV header must include at minimum: name,category,locality' });
      return;
    }

    const idxAddr = headers.indexOf('address');
    const idxUrl = headers.indexOf('official_url');
    const idxSrc = headers.indexOf('source_url');
    const idxEmail = headers.indexOf('email');

    let imported = 0;
    let duplicates = 0;
    const errors: string[] = [];

    for (let i = 1; i < lines.length; i++) {
      const cols = parseCsvLine(lines[i]);
      const name = cols[idxName] || '';
      const category = cols[idxCat] || '';
      const locality = cols[idxLoc] || '';
      if (!name || !category || !locality) {
        errors.push(`Row ${i + 1}: missing required name, category, or locality.`);
        continue;
      }
      const inserted = insertLeadRecord({
        campaignId: campaign_id ? Number(campaign_id) : null,
        name,
        category,
        locality,
        address: idxAddr >= 0 ? cols[idxAddr] : '',
        official_url: idxUrl >= 0 ? cols[idxUrl] : '',
        source_url: idxSrc >= 0 ? cols[idxSrc] : '',
        email: idxEmail >= 0 ? cols[idxEmail] : '',
      });
      imported++;
      if (inserted.isDuplicate) duplicates++;
    }

    res.json({ imported, duplicates, errors });
  });

  router.get('/leads/export-csv', (_req: Request, res: Response) => {
    const rows = db.prepare('SELECT id, name, category, locality, address, official_url, review_status FROM businesses').all() as Array<
      Record<string, unknown>
    >;
    const esc = (v: unknown) => `"${String(v ?? '').replace(/"/g, '""')}"`;
    const csv = [
      'id,name,category,locality,address,official_url,review_status',
      ...rows.map((r) => [r.id, r.name, r.category, r.locality, r.address, r.official_url, r.review_status].map(esc).join(',')),
    ].join('\n');
    res.setHeader('Content-Type', 'text/csv; charset=utf-8');
    res.setHeader('Content-Disposition', 'attachment; filename="freshy-leads.csv"');
    res.send(csv);
  });

  router.patch('/leads/:id/status', (req: Request, res: Response) => {
    const id = Number(req.params.id);
    const { review_status, purge_unnecessary_pii } = req.body as {
      review_status?: string;
      purge_unnecessary_pii?: boolean;
    };
    if (!['new', 'researched', 'review_required', 'verified', 'rejected'].includes(review_status || '')) {
      res.status(400).json({ error: 'Invalid lead status.' });
      return;
    }
    const now = new Date().toISOString();
    db.prepare('UPDATE businesses SET review_status = ?, updated_at = ? WHERE id = ?').run(review_status, now, id);
    db.prepare('UPDATE campaign_businesses SET stage = ? WHERE business_id = ?').run(review_status, id);

    if (review_status === 'rejected' && purge_unnecessary_pii) {
      db.prepare('DELETE FROM contacts WHERE business_id = ?').run(id);
      db.prepare("UPDATE businesses SET notes = 'Rejected; unnecessary contact PII purged per retention rule.', updated_at = ? WHERE id = ?").run(
        now,
        id
      );
    }

    logAuditEvent('business', id, `lead_status_${review_status}`, 'operator', { purge_unnecessary_pii: Boolean(purge_unnecessary_pii) });
    res.json(db.prepare('SELECT * FROM businesses WHERE id = ?').get(id));
  });

  router.delete('/leads/:id', (req: Request, res: Response) => {
    const id = Number(req.params.id);
    db.prepare('DELETE FROM businesses WHERE id = ?').run(id);
    logAuditEvent('business', id, 'lead_deleted', 'operator');
    res.json({ deleted: true });
  });

  // 4. Research Detail
  router.get('/leads/:id/detail', (req: Request, res: Response) => {
    const id = Number(req.params.id);
    const business = db.prepare('SELECT * FROM businesses WHERE id = ?').get(id) as Business | undefined;
    if (!business) {
      res.status(404).json({ error: 'Business not found.' });
      return;
    }

    const sources = db.prepare('SELECT * FROM sources WHERE business_id = ? ORDER BY id DESC').all(id) as SourceRecord[];
    const facts = db
      .prepare(
        `SELECT f.*, s.url as source_url FROM facts f
         LEFT JOIN sources s ON s.id = f.source_id
         WHERE f.business_id = ? ORDER BY f.id DESC`
      )
      .all(id) as FactRecord[];

    const rawContacts = db
      .prepare(
        `SELECT ct.*, s.url as source_url FROM contacts ct
         LEFT JOIN sources s ON s.id = ct.source_id
         WHERE ct.business_id = ? ORDER BY ct.id DESC`
      )
      .all(id) as ContactRecord[];

    const contacts = rawContacts.map((ct) => {
      const perm = db
        .prepare('SELECT * FROM permissions WHERE contact_id = ? AND revoked_at IS NULL ORDER BY id DESC LIMIT 1')
        .get(ct.id) as ContactRecord['permission'];
      return {
        ...ct,
        is_suppressed: isContactSuppressed(ct.channel, ct.value),
        permission: perm || null,
      };
    });

    const websites = db
      .prepare('SELECT * FROM websites WHERE business_id = ? ORDER BY version DESC, id DESC')
      .all(id) as WebsiteRecord[];

    res.json({ business, sources, facts, contacts, websites });
  });

  router.post('/leads/:id/sources', (req: Request, res: Response) => {
    const businessId = Number(req.params.id);
    const { url, permitted_use_notes } = req.body as { url?: string; permitted_use_notes?: string };
    if (!url?.trim()) {
      res.status(400).json({ error: 'Source URL is required.' });
      return;
    }
    const now = new Date().toISOString();
    const result = db
      .prepare('INSERT INTO sources (business_id, url, retrieved_at, permitted_use_notes) VALUES (?, ?, ?, ?)')
      .run(businessId, url.trim(), now, (permitted_use_notes || '').trim());
    logAuditEvent('source', Number(result.lastInsertRowid), 'source_added', 'operator', { businessId });
    res.status(201).json(db.prepare('SELECT * FROM sources WHERE id = ?').get(result.lastInsertRowid));
  });

  router.post('/leads/:id/facts', (req: Request, res: Response) => {
    const businessId = Number(req.params.id);
    const { field_name, value, source_id, verification_status, confidence } = req.body as {
      field_name?: string;
      value?: string;
      source_id?: number | null;
      verification_status?: string;
      confidence?: string;
    };

    if (!field_name?.trim()) {
      res.status(400).json({ error: 'Fact field name is required.' });
      return;
    }
    const status = ['verified', 'unverified', 'unknown'].includes(verification_status || '')
      ? verification_status!
      : 'unverified';
    const conf = ['high', 'medium', 'low'].includes(confidence || '') ? confidence! : 'medium';
    const now = new Date().toISOString();
    const verifiedAt = status === 'verified' ? now : null;

    const result = db
      .prepare(
        'INSERT INTO facts (business_id, field_name, value, source_id, verified_at, verification_status, confidence) VALUES (?, ?, ?, ?, ?, ?, ?)'
      )
      .run(businessId, field_name.trim(), (value || '').trim(), source_id || null, verifiedAt, status, conf);

    logAuditEvent('fact', Number(result.lastInsertRowid), 'fact_added', 'operator', { businessId, status });
    res.status(201).json(db.prepare('SELECT * FROM facts WHERE id = ?').get(result.lastInsertRowid));
  });

  router.patch('/facts/:id', (req: Request, res: Response) => {
    const factId = Number(req.params.id);
    const { value, verification_status, source_id } = req.body as {
      value?: string;
      verification_status?: string;
      source_id?: number | null;
    };

    const existing = db.prepare('SELECT * FROM facts WHERE id = ?').get(factId) as FactRecord | undefined;
    if (!existing) {
      res.status(404).json({ error: 'Fact not found.' });
      return;
    }

    const nextStatus = verification_status || existing.verification_status;
    const nextValue = value !== undefined ? value : existing.value;
    const nextSource = source_id !== undefined ? source_id : existing.source_id;
    const verifiedAt = nextStatus === 'verified' ? new Date().toISOString() : null;

    db.prepare('UPDATE facts SET value = ?, verification_status = ?, source_id = ?, verified_at = ? WHERE id = ?').run(
      nextValue,
      nextStatus,
      nextSource,
      verifiedAt,
      factId
    );
    logAuditEvent('fact', factId, 'fact_updated', 'operator', { verification_status: nextStatus });
    res.json(db.prepare('SELECT * FROM facts WHERE id = ?').get(factId));
  });

  router.post('/leads/:id/contacts', (req: Request, res: Response) => {
    const businessId = Number(req.params.id);
    const { channel, value, source_id, verification_status, permission_evidence } = req.body as {
      channel?: 'email' | 'whatsapp_link' | 'phone';
      value?: string;
      source_id?: number | null;
      verification_status?: string;
      permission_evidence?: string;
    };

    if (!['email', 'whatsapp_link', 'phone'].includes(channel || '')) {
      res.status(400).json({ error: 'Invalid contact channel.' });
      return;
    }

    if (channel === 'whatsapp_link' && value && !value.includes('wa.me') && !value.includes('whatsapp.com')) {
      res.status(400).json({
        error: 'WhatsApp contact must be a published wa.me or whatsapp.com link. Arbitrary phone numbers cannot be auto-converted.',
      });
      return;
    }

    const status = ['verified', 'unverified', 'unknown'].includes(verification_status || '')
      ? verification_status!
      : 'unknown';
    const now = new Date().toISOString();

    const result = db
      .prepare(
        'INSERT INTO contacts (business_id, channel, value, source_id, verification_status, created_at) VALUES (?, ?, ?, ?, ?, ?)'
      )
      .run(businessId, channel, (value || '').trim(), source_id || null, status, now);
    const contactId = Number(result.lastInsertRowid);

    if (permission_evidence && permission_evidence.trim()) {
      db.prepare('INSERT INTO permissions (contact_id, channel, scope, evidence, recorded_at) VALUES (?, ?, ?, ?, ?)').run(
        contactId,
        channel,
        'one_to_one_demo_proposal',
        permission_evidence.trim(),
        now
      );
    }

    logAuditEvent('contact', contactId, 'contact_added', 'operator', { businessId, channel, status });
    res.status(201).json(db.prepare('SELECT * FROM contacts WHERE id = ?').get(contactId));
  });

  router.patch('/contacts/:id', (req: Request, res: Response) => {
    const contactId = Number(req.params.id);
    const { value, verification_status } = req.body as { value?: string; verification_status?: string };
    const existing = db.prepare('SELECT * FROM contacts WHERE id = ?').get(contactId) as ContactRecord | undefined;
    if (!existing) {
      res.status(404).json({ error: 'Contact not found.' });
      return;
    }
    const nextValue = value !== undefined ? value.trim() : existing.value;
    const nextStatus = ['verified', 'unverified', 'unknown'].includes(verification_status || '')
      ? verification_status!
      : existing.verification_status;
    db.prepare('UPDATE contacts SET value = ?, verification_status = ? WHERE id = ?').run(
      nextValue,
      nextStatus,
      contactId
    );
    logAuditEvent('contact', contactId, 'contact_updated', 'operator', { verification_status: nextStatus });
    res.json(db.prepare('SELECT * FROM contacts WHERE id = ?').get(contactId));
  });

  router.post('/contacts/:id/permissions', (req: Request, res: Response) => {
    const contactId = Number(req.params.id);
    const { evidence, scope } = req.body as { evidence?: string; scope?: string };
    const contact = db.prepare('SELECT * FROM contacts WHERE id = ?').get(contactId) as ContactRecord | undefined;
    if (!contact) {
      res.status(404).json({ error: 'Contact not found.' });
      return;
    }
    if (!evidence?.trim()) {
      res.status(400).json({ error: 'Permission evidence note is required.' });
      return;
    }
    const now = new Date().toISOString();
    const resPerm = db
      .prepare('INSERT INTO permissions (contact_id, channel, scope, evidence, recorded_at) VALUES (?, ?, ?, ?, ?)')
      .run(contactId, contact.channel, (scope || 'one_to_one_demo_proposal').trim(), evidence.trim(), now);
    logAuditEvent('permission', Number(resPerm.lastInsertRowid), 'permission_recorded', 'operator', { contactId });
    res.status(201).json(db.prepare('SELECT * FROM permissions WHERE id = ?').get(resPerm.lastInsertRowid));
  });

  router.post('/leads/:id/fetch-url', async (req: Request, res: Response) => {
    const businessId = Number(req.params.id);
    const { url } = req.body as { url?: string };
    const business = db.prepare('SELECT * FROM businesses WHERE id = ?').get(businessId) as Business | undefined;
    if (!business) {
      res.status(404).json({ error: 'Business not found.' });
      return;
    }
    const targetUrl = (url || business.official_url || '').trim();
    if (!targetUrl) {
      res.status(400).json({ error: 'Provide an official http/https URL to inspect.' });
      return;
    }

    try {
      const fetched = await safeFetchPublicPage(targetUrl);
      const now = new Date().toISOString();
      const srcRes = db
        .prepare('INSERT INTO sources (business_id, url, retrieved_at, permitted_use_notes) VALUES (?, ?, ?, ?)')
        .run(
          businessId,
          fetched.finalUrl,
          now,
          `User-triggered safe fetch (${fetched.bytesRead} bytes). Untrusted third-party HTML; requires human verification.`
        );
      const sourceId = Number(srcRes.lastInsertRowid);

      const insertFact = db.prepare(
        'INSERT INTO facts (business_id, field_name, value, source_id, verified_at, verification_status, confidence) VALUES (?, ?, ?, ?, NULL, ?, ?)'
      );
      if (fetched.title) {
        insertFact.run(businessId, 'page_title', fetched.title, sourceId, 'unverified', 'low');
      }
      if (fetched.description) {
        insertFact.run(businessId, 'about', fetched.description, sourceId, 'unverified', 'low');
      }

      for (const email of fetched.emails) {
        db.prepare(
          'INSERT INTO contacts (business_id, channel, value, source_id, verification_status, created_at) VALUES (?, ?, ?, ?, ?, ?)'
        ).run(businessId, 'email', email, sourceId, 'unverified', now);
      }
      for (const wa of fetched.whatsappLinks) {
        db.prepare(
          'INSERT INTO contacts (business_id, channel, value, source_id, verification_status, created_at) VALUES (?, ?, ?, ?, ?, ?)'
        ).run(businessId, 'whatsapp_link', wa, sourceId, 'unverified', now);
      }

      db.prepare("UPDATE businesses SET review_status = 'review_required', updated_at = ? WHERE id = ?").run(
        now,
        businessId
      );
      logAuditEvent('business', businessId, 'safe_url_fetched', 'operator', {
        url: fetched.finalUrl,
        bytesRead: fetched.bytesRead,
      });

      res.json({ fetched, source_id: sourceId });
    } catch (err) {
      res.status(400).json({ error: err instanceof Error ? err.message : 'Failed to fetch target URL safely.' });
    }
  });

  // 5. Website Studio & Approvals
  function hydrateWebsite(w: WebsiteRecord): WebsiteRecord {
    const qaResults = db.prepare('SELECT * FROM qa_results WHERE website_id = ? ORDER BY id ASC').all(w.id) as QaResultRecord[];
    const activeApproval = db
      .prepare(
        `SELECT * FROM approvals
         WHERE entity_type = 'website' AND entity_id = ? AND content_hash = ? AND revoked_at IS NULL
         ORDER BY id DESC LIMIT 1`
      )
      .get(w.id, w.content_hash) as ApprovalRecord | undefined;
    return {
      ...w,
      qa_results: qaResults,
      active_approval: activeApproval || null,
    };
  }

  function saveWebsiteQa(websiteId: number): { hasFailure: boolean; checks: QaResultRecord[] } {
    const w = db.prepare('SELECT * FROM websites WHERE id = ?').get(websiteId) as WebsiteRecord | undefined;
    if (!w) throw new Error('Website not found.');
    const business = db.prepare('SELECT * FROM businesses WHERE id = ?').get(w.business_id) as Business;
    const facts = db.prepare('SELECT * FROM facts WHERE business_id = ?').all(w.business_id) as FactRecord[];
    const contacts = db.prepare('SELECT * FROM contacts WHERE business_id = ?').all(w.business_id) as ContactRecord[];
    const sourcesCount = (
      db.prepare('SELECT COUNT(*) as c FROM sources WHERE business_id = ?').get(w.business_id) as { c: number }
    ).c;

    const html = renderWebsiteHtml({ website: w, business, facts, contacts });
    const checks = runWebsiteQaChecks({ website: w, business, facts, contacts, sourcesCount, html });
    const now = new Date().toISOString();

    db.prepare('DELETE FROM qa_results WHERE website_id = ?').run(websiteId);
    const ins = db.prepare(
      'INSERT INTO qa_results (website_id, check_name, outcome, details, checked_at) VALUES (?, ?, ?, ?, ?)'
    );
    for (const chk of checks) {
      ins.run(websiteId, chk.check_name, chk.outcome, chk.details, now);
    }

    const hasFailure = checks.some((c) => c.outcome === 'fail');
    const stored = db.prepare('SELECT * FROM qa_results WHERE website_id = ? ORDER BY id ASC').all(websiteId) as QaResultRecord[];
    return { hasFailure, checks: stored };
  }

  router.get('/websites', (_req: Request, res: Response) => {
    const rows = db
      .prepare(
        `SELECT w.*, b.name as business_name, b.category as business_category, b.locality as business_locality
         FROM websites w
         JOIN businesses b ON b.id = w.business_id
         ORDER BY w.id DESC`
      )
      .all() as WebsiteRecord[];
    res.json(rows.map(hydrateWebsite));
  });

  router.post('/websites/generate', async (req: Request, res: Response) => {
    const { business_id, template_key, language, output_type, use_ai } = req.body as {
      business_id?: number;
      template_key?: TemplateKey;
      language?: ContentLanguage;
      output_type?: OutputType;
      use_ai?: boolean;
    };

    const business = db.prepare('SELECT * FROM businesses WHERE id = ?').get(Number(business_id)) as Business | undefined;
    if (!business) {
      res.status(404).json({ error: 'Business lead not found.' });
      return;
    }

    const facts = db.prepare('SELECT * FROM facts WHERE business_id = ?').all(business.id) as FactRecord[];
    const tKey: TemplateKey = template_key || inferTemplateKey(business.category);
    const lang: ContentLanguage = language === 'en' || language === 'hi' ? language : 'bilingual';
    const outType: OutputType = output_type === 'react' ? 'react' : 'html';

    const deterministic = buildDeterministicWebsiteCopy({
      business,
      facts,
      templateKey: tKey,
      language: lang,
    });

    let headline = deterministic.headline;
    let subheadline = deterministic.subheadline;
    let aboutCopy = deterministic.about_copy;
    let ctaLabel = deterministic.cta_label;
    let aiNotice: string | undefined;

    const settings = getAllSettings();
    if (use_ai && settings.ai_enabled) {
      const aiRes = await generateWebsiteCopyWithAi({
        businessName: business.name,
        category: business.category,
        locality: business.locality,
        templateKey: tKey,
        language: lang,
        verifiedFacts: facts,
        fallback: deterministic,
      });
      headline = aiRes.headline;
      subheadline = aiRes.subheadline;
      aboutCopy = aiRes.about_copy;
      ctaLabel = aiRes.cta_label;
      if (!aiRes.usedAi) aiNotice = aiRes.reason;
    }

    const servicesJson = JSON.stringify(deterministic.services);
    const contentHash = computeWebsiteContentHash({
      template_key: tKey,
      language: lang,
      output_type: outType,
      headline,
      subheadline,
      about_copy: aboutCopy,
      services_json: servicesJson,
      cta_label: ctaLabel,
    });

    const latestVer =
      (db.prepare('SELECT MAX(version) as mv FROM websites WHERE business_id = ?').get(business.id) as { mv: number | null })
        ?.mv || 0;
    const version = latestVer + 1;
    const now = new Date().toISOString();
    const cb = db
      .prepare('SELECT campaign_id FROM campaign_businesses WHERE business_id = ? LIMIT 1')
      .get(business.id) as { campaign_id: number } | undefined;

    const insertRes = db
      .prepare(
        `INSERT INTO websites (
          business_id, campaign_id, version, template_key, language, output_type,
          headline, subheadline, about_copy, services_json, cta_label, content_hash,
          local_path, public_url, status, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, '', 'draft', ?, ?)`
      )
      .run(
        business.id,
        cb?.campaign_id || null,
        version,
        tKey,
        lang,
        outType,
        headline,
        subheadline,
        aboutCopy,
        servicesJson,
        ctaLabel,
        contentHash,
        `/api/websites/preview/${business.id}-v${version}`,
        now,
        now
      );
    const websiteId = Number(insertRes.lastInsertRowid);

    const qa = saveWebsiteQa(websiteId);
    const nextStatus = qa.hasFailure ? 'qa_failed' : 'review_required';
    db.prepare('UPDATE websites SET status = ?, updated_at = ? WHERE id = ?').run(nextStatus, now, websiteId);

    logAuditEvent('website', websiteId, 'website_generated', 'operator', {
      businessId: business.id,
      version,
      template_key: tKey,
      output_type: outType,
      qaFailed: qa.hasFailure,
    });

    const full = db
      .prepare(
        `SELECT w.*, b.name as business_name, b.category as business_category, b.locality as business_locality
         FROM websites w JOIN businesses b ON b.id = w.business_id WHERE w.id = ?`
      )
      .get(websiteId) as WebsiteRecord;

    res.status(201).json({ website: hydrateWebsite(full), ai_notice: aiNotice });
  });

  router.patch('/websites/:id', (req: Request, res: Response) => {
    const id = Number(req.params.id);
    const existing = db.prepare('SELECT * FROM websites WHERE id = ?').get(id) as WebsiteRecord | undefined;
    if (!existing) {
      res.status(404).json({ error: 'Website not found.' });
      return;
    }

    const body = req.body as Partial<{
      template_key: TemplateKey;
      language: ContentLanguage;
      output_type: OutputType;
      headline: string;
      subheadline: string;
      about_copy: string;
      services_json: string;
      cta_label: string;
    }>;

    const next = {
      template_key: body.template_key ?? existing.template_key,
      language: body.language ?? existing.language,
      output_type: body.output_type ?? existing.output_type,
      headline: body.headline ?? existing.headline,
      subheadline: body.subheadline ?? existing.subheadline,
      about_copy: body.about_copy ?? existing.about_copy,
      services_json: body.services_json ?? existing.services_json,
      cta_label: body.cta_label ?? existing.cta_label,
    };

    const nextHash = computeWebsiteContentHash(next);
    const hashChanged = nextHash !== existing.content_hash;
    const now = new Date().toISOString();

    let revokedPriorApproval = false;
    if (hashChanged) {
      const rev = db
        .prepare(
          `UPDATE approvals SET revoked_at = ?, revoke_reason = 'Website edited after approval'
           WHERE entity_type = 'website' AND entity_id = ? AND revoked_at IS NULL`
        )
        .run(now, id);
      revokedPriorApproval = rev.changes > 0;
    }

    db.prepare(
      `UPDATE websites SET
        template_key = ?, language = ?, output_type = ?, headline = ?, subheadline = ?,
        about_copy = ?, services_json = ?, cta_label = ?, content_hash = ?,
        version = CASE WHEN ? THEN version + 1 ELSE version END,
        status = ?, updated_at = ?
       WHERE id = ?`
    ).run(
      next.template_key,
      next.language,
      next.output_type,
      next.headline,
      next.subheadline,
      next.about_copy,
      next.services_json,
      next.cta_label,
      nextHash,
      hashChanged ? 1 : 0,
      hashChanged ? 'review_required' : existing.status,
      now,
      id
    );

    const qa = saveWebsiteQa(id);
    if (qa.hasFailure) {
      db.prepare("UPDATE websites SET status = 'qa_failed', updated_at = ? WHERE id = ?").run(now, id);
    }

    logAuditEvent('website', id, 'website_edited', 'operator', {
      hashChanged,
      revokedPriorApproval,
    });

    const updated = db
      .prepare(
        `SELECT w.*, b.name as business_name, b.category as business_category, b.locality as business_locality
         FROM websites w JOIN businesses b ON b.id = w.business_id WHERE w.id = ?`
      )
      .get(id) as WebsiteRecord;

    res.json({ website: hydrateWebsite(updated), revoked_prior_approval: revokedPriorApproval });
  });

  router.post('/websites/:id/ai-copy', async (req: Request, res: Response) => {
    const id = Number(req.params.id);
    const existing = db.prepare('SELECT * FROM websites WHERE id = ?').get(id) as WebsiteRecord | undefined;
    if (!existing) {
      res.status(404).json({ error: 'Website not found.' });
      return;
    }
    const settings = getAllSettings();
    if (!settings.ai_enabled) {
      res.status(400).json({ error: 'Optional AI copy assistance is currently turned off in Settings.' });
      return;
    }

    const business = db.prepare('SELECT * FROM businesses WHERE id = ?').get(existing.business_id) as Business;
    const facts = db.prepare('SELECT * FROM facts WHERE business_id = ?').all(existing.business_id) as FactRecord[];

    const aiRes = await generateWebsiteCopyWithAi({
      businessName: business.name,
      category: business.category,
      locality: business.locality,
      templateKey: existing.template_key,
      language: existing.language,
      verifiedFacts: facts,
      fallback: {
        headline: existing.headline,
        subheadline: existing.subheadline,
        about_copy: existing.about_copy,
        cta_label: existing.cta_label,
      },
    });

    if (!aiRes.usedAi) {
      res.status(503).json({ error: aiRes.reason || 'AI model unavailable.' });
      return;
    }

    const nextHash = computeWebsiteContentHash({
      template_key: existing.template_key,
      language: existing.language,
      output_type: existing.output_type,
      headline: aiRes.headline,
      subheadline: aiRes.subheadline,
      about_copy: aiRes.about_copy,
      services_json: existing.services_json,
      cta_label: aiRes.cta_label,
    });
    const now = new Date().toISOString();

    db.prepare(
      `UPDATE approvals SET revoked_at = ?, revoke_reason = 'AI copy draft applied; reapproval required'
       WHERE entity_type = 'website' AND entity_id = ? AND revoked_at IS NULL`
    ).run(now, id);

    db.prepare(
      `UPDATE websites SET headline = ?, subheadline = ?, about_copy = ?, cta_label = ?, content_hash = ?, version = version + 1, status = 'review_required', updated_at = ?
       WHERE id = ?`
    ).run(aiRes.headline, aiRes.subheadline, aiRes.about_copy, aiRes.cta_label, nextHash, now, id);

    saveWebsiteQa(id);
    logAuditEvent('website', id, 'website_ai_copy_drafted', 'ai_helper');

    const updated = db
      .prepare(
        `SELECT w.*, b.name as business_name, b.category as business_category, b.locality as business_locality
         FROM websites w JOIN businesses b ON b.id = w.business_id WHERE w.id = ?`
      )
      .get(id) as WebsiteRecord;
    res.json({ website: hydrateWebsite(updated) });
  });

  router.post('/websites/:id/qa', (req: Request, res: Response) => {
    const id = Number(req.params.id);
    const existing = db.prepare('SELECT * FROM websites WHERE id = ?').get(id) as WebsiteRecord | undefined;
    if (!existing) {
      res.status(404).json({ error: 'Website not found.' });
      return;
    }
    const qa = saveWebsiteQa(id);
    const now = new Date().toISOString();
    if (qa.hasFailure) {
      db.prepare("UPDATE websites SET status = 'qa_failed', updated_at = ? WHERE id = ?").run(now, id);
    } else if (existing.status === 'qa_failed' || existing.status === 'draft') {
      db.prepare("UPDATE websites SET status = 'review_required', updated_at = ? WHERE id = ?").run(now, id);
    }
    logAuditEvent('website', id, 'website_qa_ran', 'operator', { hasFailure: qa.hasFailure });

    const updated = db
      .prepare(
        `SELECT w.*, b.name as business_name, b.category as business_category, b.locality as business_locality
         FROM websites w JOIN businesses b ON b.id = w.business_id WHERE w.id = ?`
      )
      .get(id) as WebsiteRecord;
    res.json(hydrateWebsite(updated));
  });

  router.post('/websites/:id/approve', (req: Request, res: Response) => {
    const id = Number(req.params.id);
    const w = db.prepare('SELECT * FROM websites WHERE id = ?').get(id) as WebsiteRecord | undefined;
    if (!w) {
      res.status(404).json({ error: 'Website not found.' });
      return;
    }
    const qa = saveWebsiteQa(id);
    if (qa.hasFailure) {
      res.status(400).json({ error: 'Cannot approve website while critical QA checks fail.' });
      return;
    }

    const now = new Date().toISOString();
    db.prepare(
      `UPDATE approvals SET revoked_at = ?, revoke_reason = 'Superseded by new approval'
       WHERE entity_type = 'website' AND entity_id = ? AND approval_kind = 'website_review' AND revoked_at IS NULL`
    ).run(now, id);

    db.prepare(
      `INSERT INTO approvals (entity_type, entity_id, content_hash, approval_kind, approved_by, approved_at)
       VALUES ('website', ?, ?, 'website_review', 'operator', ?)`
    ).run(id, w.content_hash, now);

    db.prepare("UPDATE websites SET status = 'approved', updated_at = ? WHERE id = ?").run(now, id);
    logAuditEvent('website', id, 'website_approved', 'operator', { content_hash: w.content_hash });

    const updated = db
      .prepare(
        `SELECT w.*, b.name as business_name, b.category as business_category, b.locality as business_locality
         FROM websites w JOIN businesses b ON b.id = w.business_id WHERE w.id = ?`
      )
      .get(id) as WebsiteRecord;
    res.json(hydrateWebsite(updated));
  });

  router.post('/websites/:id/publish-review', (req: Request, res: Response) => {
    const id = Number(req.params.id);
    const { public_url, mark_published } = req.body as { public_url?: string; mark_published?: boolean };
    const w = db.prepare('SELECT * FROM websites WHERE id = ?').get(id) as WebsiteRecord | undefined;
    if (!w) {
      res.status(404).json({ error: 'Website not found.' });
      return;
    }
    const activeApproval = db
      .prepare(
        `SELECT * FROM approvals WHERE entity_type = 'website' AND entity_id = ? AND content_hash = ? AND revoked_at IS NULL`
      )
      .get(id, w.content_hash);
    if (!activeApproval) {
      res.status(400).json({ error: 'Website content hash must be approved before publish review.' });
      return;
    }

    const cleanUrl = (public_url || '').trim();
    if (cleanUrl && !cleanUrl.startsWith('https://') && !cleanUrl.startsWith('http://')) {
      res.status(400).json({ error: 'Public demo URL must start with https:// or http://' });
      return;
    }

    const now = new Date().toISOString();
    const nextStatus = mark_published && cleanUrl ? 'published' : 'publish_review';
    if (mark_published && cleanUrl) {
      db.prepare(
        `INSERT INTO approvals (entity_type, entity_id, content_hash, approval_kind, approved_by, approved_at)
         VALUES ('website', ?, ?, 'publish_review', 'operator', ?)`
      ).run(id, w.content_hash, now);
    }

    db.prepare('UPDATE websites SET public_url = ?, status = ?, updated_at = ? WHERE id = ?').run(
      cleanUrl,
      nextStatus,
      now,
      id
    );
    logAuditEvent('website', id, `website_${nextStatus}`, 'operator', { public_url: cleanUrl });

    const updated = db
      .prepare(
        `SELECT w.*, b.name as business_name, b.category as business_category, b.locality as business_locality
         FROM websites w JOIN businesses b ON b.id = w.business_id WHERE w.id = ?`
      )
      .get(id) as WebsiteRecord;
    res.json(hydrateWebsite(updated));
  });

  router.get('/websites/:id/preview', (req: Request, res: Response) => {
    const id = Number(req.params.id);
    const w = db.prepare('SELECT * FROM websites WHERE id = ?').get(id) as WebsiteRecord | undefined;
    if (!w) {
      res.status(404).send('Website demo not found.');
      return;
    }
    const business = db.prepare('SELECT * FROM businesses WHERE id = ?').get(w.business_id) as Business;
    const facts = db.prepare('SELECT * FROM facts WHERE business_id = ?').all(w.business_id) as FactRecord[];
    const contacts = db.prepare('SELECT * FROM contacts WHERE business_id = ?').all(w.business_id) as ContactRecord[];
    const html = renderWebsiteHtml({ website: w, business, facts, contacts });
    res.setHeader('Content-Type', 'text/html; charset=utf-8');
    res.setHeader('X-Robots-Tag', 'noindex, nofollow');
    res.send(html);
  });

  router.get('/websites/:id/export-zip', async (req: Request, res: Response) => {
    const id = Number(req.params.id);
    const w = db.prepare('SELECT * FROM websites WHERE id = ?').get(id) as WebsiteRecord | undefined;
    if (!w) {
      res.status(404).json({ error: 'Website not found.' });
      return;
    }
    const business = db.prepare('SELECT * FROM businesses WHERE id = ?').get(w.business_id) as Business;
    const facts = db.prepare('SELECT * FROM facts WHERE business_id = ?').all(w.business_id) as FactRecord[];
    const contacts = db.prepare('SELECT * FROM contacts WHERE business_id = ?').all(w.business_id) as ContactRecord[];

    const { buffer, filename } = await buildWebsiteZipBuffer({ website: w, business, facts, contacts });
    logAuditEvent('website', id, 'website_zip_exported', 'operator', { output_type: w.output_type, filename });
    res.setHeader('Content-Type', 'application/zip');
    res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
    res.send(buffer);
  });

  // 6. Outreach & Suppression
  function hydrateMessage(m: MessageRecord): MessageRecord {
    const activeApproval = db
      .prepare(
        `SELECT * FROM approvals
         WHERE entity_type = 'message' AND entity_id = ? AND content_hash = ? AND revoked_at IS NULL
         ORDER BY id DESC LIMIT 1`
      )
      .get(m.id, m.content_hash) as ApprovalRecord | undefined;

    const suppressed = m.contact_value ? isContactSuppressed(m.channel, m.contact_value) : false;
    const blockers = computeMessageBlockers(m);
    return {
      ...m,
      is_suppressed: suppressed,
      active_approval: activeApproval || null,
      blockers,
    };
  }

  router.get('/outreach', (_req: Request, res: Response) => {
    const rows = db
      .prepare(
        `SELECT m.*,
          b.name as business_name,
          ct.value as contact_value,
          ct.channel as contact_channel,
          ct.verification_status as contact_verification_status,
          w.status as website_status,
          w.public_url as website_public_url
         FROM messages m
         JOIN businesses b ON b.id = m.business_id
         LEFT JOIN contacts ct ON ct.id = m.contact_id
         LEFT JOIN websites w ON w.id = m.website_id
         ORDER BY m.id DESC`
      )
      .all() as MessageRecord[];

    res.json(rows.map(hydrateMessage));
  });

  router.post('/outreach/draft', async (req: Request, res: Response) => {
    const { business_id, contact_id, website_id, channel, language, purpose, use_ai } = req.body as {
      business_id?: number;
      contact_id?: number | null;
      website_id?: number | null;
      channel?: 'email' | 'whatsapp_link';
      language?: 'en' | 'hi';
      purpose?: 'initial_demo' | 'follow_up';
      use_ai?: boolean;
    };

    const business = db.prepare('SELECT * FROM businesses WHERE id = ?').get(Number(business_id)) as Business | undefined;
    if (!business) {
      res.status(404).json({ error: 'Business lead not found.' });
      return;
    }

    const ch: 'email' | 'whatsapp_link' = channel === 'whatsapp_link' ? 'whatsapp_link' : 'email';
    const lang: 'en' | 'hi' = language === 'hi' ? 'hi' : 'en';
    const purp: 'initial_demo' | 'follow_up' = purpose === 'follow_up' ? 'follow_up' : 'initial_demo';

    const contact = contact_id
      ? (db.prepare('SELECT * FROM contacts WHERE id = ? AND business_id = ?').get(contact_id, business.id) as
          | ContactRecord
          | undefined)
      : (db
          .prepare('SELECT * FROM contacts WHERE business_id = ? AND channel = ? ORDER BY id DESC LIMIT 1')
          .get(business.id, ch) as ContactRecord | undefined);

    if (contact && contact.value && isContactSuppressed(ch, contact.value)) {
      res.status(400).json({
        error: `Draft creation blocked: contact "${contact.value}" is on the opt-out suppression list.`,
      });
      return;
    }

    const website = website_id
      ? (db.prepare('SELECT * FROM websites WHERE id = ? AND business_id = ?').get(website_id, business.id) as
          | WebsiteRecord
          | undefined)
      : (db
          .prepare('SELECT * FROM websites WHERE business_id = ? ORDER BY version DESC, id DESC LIMIT 1')
          .get(business.id) as WebsiteRecord | undefined);

    const settings = getAllSettings();
    const demoRef = website?.public_url?.trim()
      ? website.public_url.trim()
      : 'Attached concept demo ZIP package (shared after approval)';

    const deterministic = buildDeterministicOutreachText({
      business,
      channel: ch,
      language: lang,
      senderName: settings.agency_sender_name,
      demoRef,
      purpose: purp,
    });

    let subject = deterministic.subject;
    let body = deterministic.body;
    let aiNotice: string | undefined;

    if (use_ai && settings.ai_enabled) {
      const aiOut = await generateOutreachWithAi({
        businessName: business.name,
        locality: business.locality,
        category: business.category,
        senderName: settings.agency_sender_name,
        channel: ch,
        language: lang,
        demoReference: demoRef,
        fallbackSubject: deterministic.subject,
        fallbackBody: deterministic.body,
      });
      subject = aiOut.subject;
      body = aiOut.body;
      if (!aiOut.usedAi) aiNotice = aiOut.reason;
    }

    const attachmentNote = website?.public_url?.trim()
      ? `Approved Public URL: ${website.public_url.trim()}`
      : website
        ? `Manual ZIP export (${website.output_type.toUpperCase()} v${website.version})`
        : '';

    const contentHash = computeMessageContentHash({
      contact_id: contact?.id ?? null,
      recipient: contact?.value ?? '',
      channel: ch,
      purpose: purp,
      subject,
      body,
      attachment_note: attachmentNote,
    });

    const now = new Date().toISOString();
    const cb = db
      .prepare('SELECT campaign_id FROM campaign_businesses WHERE business_id = ? LIMIT 1')
      .get(business.id) as { campaign_id: number } | undefined;

    const ins = db
      .prepare(
        `INSERT INTO messages (
          business_id, campaign_id, contact_id, website_id, channel, purpose,
          subject, body, attachment_note, content_hash, status, follow_up_enabled, follow_up_days,
          created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'review_required', ?, ?, ?, ?)`
      )
      .run(
        business.id,
        cb?.campaign_id || null,
        contact?.id ?? null,
        website?.id ?? null,
        ch,
        purp,
        subject,
        body,
        attachmentNote,
        contentHash,
        settings.followup_default_enabled ? 1 : 0,
        settings.followup_days,
        now,
        now
      );

    const msgId = Number(ins.lastInsertRowid);
    logAuditEvent('message', msgId, 'outreach_draft_created', 'operator', {
      businessId: business.id,
      channel: ch,
      purpose: purp,
    });

    const created = db
      .prepare(
        `SELECT m.*, b.name as business_name, ct.value as contact_value, ct.channel as contact_channel,
          ct.verification_status as contact_verification_status, w.status as website_status, w.public_url as website_public_url
         FROM messages m
         JOIN businesses b ON b.id = m.business_id
         LEFT JOIN contacts ct ON ct.id = m.contact_id
         LEFT JOIN websites w ON w.id = m.website_id
         WHERE m.id = ?`
      )
      .get(msgId) as MessageRecord;

    res.status(201).json({ message: hydrateMessage(created), ai_notice: aiNotice });
  });

  router.patch('/outreach/:id', (req: Request, res: Response) => {
    const id = Number(req.params.id);
    const existing = db
      .prepare(
        `SELECT m.*, ct.value as contact_value FROM messages m
         LEFT JOIN contacts ct ON ct.id = m.contact_id WHERE m.id = ?`
      )
      .get(id) as (MessageRecord & { contact_value?: string }) | undefined;
    if (!existing) {
      res.status(404).json({ error: 'Message draft not found.' });
      return;
    }

    const { contact_id, subject, body, attachment_note } = req.body as Partial<{
      contact_id: number | null;
      subject: string;
      body: string;
      attachment_note: string;
    }>;

    const nextContactId = contact_id !== undefined ? contact_id : existing.contact_id;
    const contactRow = nextContactId
      ? (db.prepare('SELECT value FROM contacts WHERE id = ?').get(nextContactId) as { value: string } | undefined)
      : undefined;

    const nextSubject = subject !== undefined ? subject : existing.subject;
    const nextBody = body !== undefined ? body : existing.body;
    const nextNote = attachment_note !== undefined ? attachment_note : existing.attachment_note;

    const nextHash = computeMessageContentHash({
      contact_id: nextContactId,
      recipient: contactRow?.value ?? '',
      channel: existing.channel,
      purpose: existing.purpose,
      subject: nextSubject,
      body: nextBody,
      attachment_note: nextNote,
    });

    const hashChanged = nextHash !== existing.content_hash;
    const now = new Date().toISOString();
    let revokedPrior = false;
    if (hashChanged) {
      const rev = db
        .prepare(
          `UPDATE approvals SET revoked_at = ?, revoke_reason = 'Message edited after approval'
           WHERE entity_type = 'message' AND entity_id = ? AND revoked_at IS NULL`
        )
        .run(now, id);
      revokedPrior = rev.changes > 0;
    }

    db.prepare(
      `UPDATE messages SET contact_id = ?, subject = ?, body = ?, attachment_note = ?, content_hash = ?,
       status = CASE WHEN ? THEN 'review_required' ELSE status END, updated_at = ?
       WHERE id = ?`
    ).run(nextContactId, nextSubject, nextBody, nextNote, nextHash, hashChanged ? 1 : 0, now, id);

    logAuditEvent('message', id, 'outreach_edited', 'operator', { hashChanged, revokedPrior });

    const updated = db
      .prepare(
        `SELECT m.*, b.name as business_name, ct.value as contact_value, ct.channel as contact_channel,
          ct.verification_status as contact_verification_status, w.status as website_status, w.public_url as website_public_url
         FROM messages m
         JOIN businesses b ON b.id = m.business_id
         LEFT JOIN contacts ct ON ct.id = m.contact_id
         LEFT JOIN websites w ON w.id = m.website_id
         WHERE m.id = ?`
      )
      .get(id) as MessageRecord;
    res.json({ message: hydrateMessage(updated), revoked_prior_approval: revokedPrior });
  });

  router.post('/outreach/:id/approve', (req: Request, res: Response) => {
    const id = Number(req.params.id);
    const msg = db
      .prepare(
        `SELECT m.*, b.name as business_name, ct.value as contact_value, ct.channel as contact_channel,
          ct.verification_status as contact_verification_status, w.status as website_status, w.public_url as website_public_url
         FROM messages m
         JOIN businesses b ON b.id = m.business_id
         LEFT JOIN contacts ct ON ct.id = m.contact_id
         LEFT JOIN websites w ON w.id = m.website_id
         WHERE m.id = ?`
      )
      .get(id) as MessageRecord | undefined;

    if (!msg) {
      res.status(404).json({ error: 'Message not found.' });
      return;
    }

    const blockers = computeMessageBlockers(msg);
    if (blockers.length > 0) {
      res.status(400).json({ error: blockers[0], blockers });
      return;
    }

    const now = new Date().toISOString();
    db.prepare(
      `UPDATE approvals SET revoked_at = ?, revoke_reason = 'Superseded by new message approval'
       WHERE entity_type = 'message' AND entity_id = ? AND revoked_at IS NULL`
    ).run(now, id);

    db.prepare(
      `INSERT INTO approvals (entity_type, entity_id, content_hash, approval_kind, approved_by, approved_at)
       VALUES ('message', ?, ?, 'message_send', 'operator', ?)`
    ).run(id, msg.content_hash, now);

    db.prepare("UPDATE messages SET status = 'approved', updated_at = ? WHERE id = ?").run(now, id);
    logAuditEvent('message', id, 'outreach_approved', 'operator', { content_hash: msg.content_hash });

    const updated = db
      .prepare(
        `SELECT m.*, b.name as business_name, ct.value as contact_value, ct.channel as contact_channel,
          ct.verification_status as contact_verification_status, w.status as website_status, w.public_url as website_public_url
         FROM messages m
         JOIN businesses b ON b.id = m.business_id
         LEFT JOIN contacts ct ON ct.id = m.contact_id
         LEFT JOIN websites w ON w.id = m.website_id
         WHERE m.id = ?`
      )
      .get(id) as MessageRecord;
    res.json(hydrateMessage(updated));
  });

  router.post('/outreach/:id/manual-send', (req: Request, res: Response) => {
    const id = Number(req.params.id);
    const msg = db
      .prepare(
        `SELECT m.*, b.name as business_name, ct.value as contact_value, ct.channel as contact_channel,
          ct.verification_status as contact_verification_status, w.status as website_status, w.public_url as website_public_url
         FROM messages m
         JOIN businesses b ON b.id = m.business_id
         LEFT JOIN contacts ct ON ct.id = m.contact_id
         LEFT JOIN websites w ON w.id = m.website_id
         WHERE m.id = ?`
      )
      .get(id) as MessageRecord | undefined;

    if (!msg) {
      res.status(404).json({ error: 'Message not found.' });
      return;
    }

    const blockers = computeMessageBlockers(msg);
    if (blockers.length > 0) {
      res.status(400).json({ error: blockers[0], blockers });
      return;
    }

    const approval = db
      .prepare(
        `SELECT * FROM approvals WHERE entity_type = 'message' AND entity_id = ? AND content_hash = ? AND revoked_at IS NULL`
      )
      .get(id, msg.content_hash);
    if (!approval) {
      res.status(400).json({ error: 'Exact message snapshot hash must be approved before sending.' });
      return;
    }

    const idempotencyKey = sha256(`msg:${id}:${msg.content_hash}`);
    const existingAttempt = db
      .prepare('SELECT id FROM send_attempts WHERE idempotency_key = ?')
      .get(idempotencyKey);
    if (existingAttempt) {
      res.status(409).json({ error: 'Duplicate send prevented by idempotency check.' });
      return;
    }

    const now = new Date().toISOString();
    db.prepare(
      `INSERT INTO send_attempts (message_id, idempotency_key, provider_id, status, attempted_at)
       VALUES (?, ?, 'manual_operator_confirmation', 'sent', ?)`
    ).run(id, idempotencyKey, now);

    db.prepare("UPDATE messages SET status = 'sent', updated_at = ? WHERE id = ?").run(now, id);
    logAuditEvent('message', id, 'outreach_manual_sent', 'operator', { idempotencyKey });

    const updated = db
      .prepare(
        `SELECT m.*, b.name as business_name, ct.value as contact_value, ct.channel as contact_channel,
          ct.verification_status as contact_verification_status, w.status as website_status, w.public_url as website_public_url
         FROM messages m
         JOIN businesses b ON b.id = m.business_id
         LEFT JOIN contacts ct ON ct.id = m.contact_id
         LEFT JOIN websites w ON w.id = m.website_id
         WHERE m.id = ?`
      )
      .get(id) as MessageRecord;
    res.json(hydrateMessage(updated));
  });

  router.post('/outreach/:id/response', (req: Request, res: Response) => {
    const id = Number(req.params.id);
    const { outcome, reason } = req.body as { outcome?: 'replied' | 'opt_out' | 'delivery_unknown'; reason?: string };
    const msg = db
      .prepare(
        `SELECT m.*, ct.value as contact_value FROM messages m
         LEFT JOIN contacts ct ON ct.id = m.contact_id WHERE m.id = ?`
      )
      .get(id) as (MessageRecord & { contact_value?: string }) | undefined;

    if (!msg) {
      res.status(404).json({ error: 'Message not found.' });
      return;
    }

    const now = new Date().toISOString();
    if (outcome === 'opt_out') {
      if (msg.contact_value) {
        const norm = normalizeContact(msg.channel, msg.contact_value);
        db.prepare(
          'INSERT OR IGNORE INTO suppressions (normalized_contact, channel, reason, created_at) VALUES (?, ?, ?, ?)'
        ).run(norm, msg.channel, reason || 'Opt-out recorded from outreach response', now);
      }
      db.prepare("UPDATE messages SET status = 'suppressed', updated_at = ? WHERE id = ?").run(now, id);
      db.prepare(
        "UPDATE tasks SET status = 'cancelled', last_error = 'Cancelled due to opt-out suppression', updated_at = ? WHERE business_id = ? AND task_type = 'follow_up_draft' AND status IN ('queued', 'paused')"
      ).run(now, msg.business_id);
      logAuditEvent('message', id, 'outreach_opt_out_recorded', 'operator');
    } else if (outcome === 'replied') {
      db.prepare(
        "UPDATE tasks SET status = 'cancelled', last_error = 'Cancelled: recipient replied', updated_at = ? WHERE business_id = ? AND task_type = 'follow_up_draft' AND status IN ('queued', 'paused')"
      ).run(now, msg.business_id);
      logAuditEvent('message', id, 'outreach_reply_recorded', 'operator');
    } else if (outcome === 'delivery_unknown') {
      db.prepare("UPDATE messages SET status = 'delivery_unknown', updated_at = ? WHERE id = ?").run(now, id);
      logAuditEvent('message', id, 'outreach_delivery_unknown', 'operator');
    }

    res.json({ ok: true });
  });

  // Suppressions
  router.get('/suppressions', (_req: Request, res: Response) => {
    res.json(db.prepare('SELECT * FROM suppressions ORDER BY id DESC').all());
  });

  router.post('/suppressions', (req: Request, res: Response) => {
    const { contact, channel, reason } = req.body as { contact?: string; channel?: string; reason?: string };
    if (!contact?.trim()) {
      res.status(400).json({ error: 'Contact value is required.' });
      return;
    }
    const ch = channel || 'email';
    const norm = normalizeContact(ch, contact);
    const now = new Date().toISOString();
    db.prepare(
      'INSERT OR IGNORE INTO suppressions (normalized_contact, channel, reason, created_at) VALUES (?, ?, ?, ?)'
    ).run(norm, ch, (reason || 'Manual opt-out suppression').trim(), now);

    // Suppress any unsent drafts matching this contact & cancel queued follow-ups
    const matchingContacts = db
      .prepare('SELECT id, business_id, value FROM contacts WHERE channel = ?')
      .all(ch) as Array<{ id: number; business_id: number; value: string }>;
    for (const c of matchingContacts) {
      if (normalizeContact(ch, c.value) === norm) {
        db.prepare(
          "UPDATE messages SET status = 'suppressed', updated_at = ? WHERE contact_id = ? AND status IN ('draft', 'review_required', 'approved')"
        ).run(now, c.id);
        db.prepare(
          "UPDATE tasks SET status = 'cancelled', last_error = 'Cancelled due to opt-out suppression', updated_at = ? WHERE business_id = ? AND task_type = 'follow_up_draft' AND status IN ('queued', 'paused')"
        ).run(now, c.business_id);
      }
    }

    logAuditEvent('suppression', 0, 'suppression_added', 'operator', { channel: ch, normalized_contact: norm });
    res.status(201).json(db.prepare('SELECT * FROM suppressions WHERE normalized_contact = ? AND channel = ?').get(norm, ch));
  });

  router.delete('/suppressions/:id', (req: Request, res: Response) => {
    const id = Number(req.params.id);
    db.prepare('DELETE FROM suppressions WHERE id = ?').run(id);
    logAuditEvent('suppression', id, 'suppression_removed', 'operator');
    res.json({ deleted: true });
  });

  // 7. Tasks / Orchestrator Queue + Follow-ups
  router.get('/tasks', (_req: Request, res: Response) => {
    const rows = db
      .prepare(
        `SELECT t.*, c.name as campaign_name, b.name as business_name
         FROM tasks t
         LEFT JOIN campaigns c ON c.id = t.campaign_id
         LEFT JOIN businesses b ON b.id = t.business_id
         ORDER BY t.id DESC`
      )
      .all();
    res.json(rows);
  });

  router.post('/tasks/schedule-followup', (req: Request, res: Response) => {
    const { message_id, days } = req.body as { message_id?: number; days?: number };
    const msg = db
      .prepare(
        `SELECT m.*, ct.value as contact_value FROM messages m
         LEFT JOIN contacts ct ON ct.id = m.contact_id WHERE m.id = ?`
      )
      .get(Number(message_id)) as (MessageRecord & { contact_value?: string }) | undefined;

    if (!msg) {
      res.status(404).json({ error: 'Original message not found.' });
      return;
    }
    if (msg.status !== 'sent') {
      res.status(400).json({ error: 'Follow-up can only be queued after the initial message has been sent.' });
      return;
    }
    if (msg.contact_value && isContactSuppressed(msg.channel, msg.contact_value)) {
      res.status(400).json({ error: 'Cannot schedule follow-up: recipient is suppressed.' });
      return;
    }

    const existingFollowup = db
      .prepare("SELECT id FROM messages WHERE business_id = ? AND purpose = 'follow_up'")
      .get(msg.business_id);
    if (existingFollowup) {
      res.status(400).json({ error: 'Policy limit: maximum 1 follow-up draft per lead.' });
      return;
    }

    const waitDays = Math.min(Math.max(Number(days) || 6, 5), 7);
    const now = new Date();
    const due = new Date(now.getTime() + waitDays * 86400_000).toISOString();

    const ins = db
      .prepare(
        `INSERT INTO tasks (campaign_id, business_id, task_type, status, attempt_count, max_attempts, due_at, payload_json, created_at, updated_at)
         VALUES (?, ?, 'follow_up_draft', 'queued', 0, 2, ?, ?, ?, ?)`
      )
      .run(
        msg.campaign_id,
        msg.business_id,
        due,
        JSON.stringify({ source_message_id: msg.id, contact_id: msg.contact_id, website_id: msg.website_id, channel: msg.channel }),
        now.toISOString(),
        now.toISOString()
      );

    logAuditEvent('task', Number(ins.lastInsertRowid), 'followup_scheduled', 'operator', { waitDays });
    res.status(201).json(db.prepare('SELECT * FROM tasks WHERE id = ?').get(ins.lastInsertRowid));
  });

  router.post('/tasks/run-next', (_req: Request, res: Response) => {
    const task = db
      .prepare("SELECT * FROM tasks WHERE status = 'queued' ORDER BY id ASC LIMIT 1")
      .get() as
      | {
          id: number;
          campaign_id: number | null;
          business_id: number | null;
          task_type: string;
          attempt_count: number;
          max_attempts: number;
          payload_json: string;
        }
      | undefined;

    if (!task) {
      res.json({ ran: false, message: 'No queued tasks waiting in orchestrator.' });
      return;
    }

    const now = new Date().toISOString();
    if (task.attempt_count >= task.max_attempts) {
      db.prepare("UPDATE tasks SET status = 'failed', last_error = 'Max bounded retry attempts reached.', updated_at = ? WHERE id = ?").run(
        now,
        task.id
      );
      res.json({ ran: false, message: 'Task exceeded max retries and moved to failed.' });
      return;
    }

    try {
      db.prepare('UPDATE tasks SET attempt_count = attempt_count + 1, updated_at = ? WHERE id = ?').run(now, task.id);

      if (task.task_type === 'website_build' && task.business_id) {
        const business = db.prepare('SELECT * FROM businesses WHERE id = ?').get(task.business_id) as Business;
        const facts = db.prepare('SELECT * FROM facts WHERE business_id = ?').all(task.business_id) as FactRecord[];
        const payload = JSON.parse(task.payload_json || '{}') as {
          template_key?: TemplateKey;
          language?: ContentLanguage;
          output_type?: OutputType;
        };
        const tKey = payload.template_key || inferTemplateKey(business.category);
        const lang = payload.language || 'bilingual';
        const outType = payload.output_type || 'html';
        const copy = buildDeterministicWebsiteCopy({ business, facts, templateKey: tKey, language: lang });
        const servicesJson = JSON.stringify(copy.services);
        const hash = computeWebsiteContentHash({
          template_key: tKey,
          language: lang,
          output_type: outType,
          headline: copy.headline,
          subheadline: copy.subheadline,
          about_copy: copy.about_copy,
          services_json: servicesJson,
          cta_label: copy.cta_label,
        });
        const mv =
          (db.prepare('SELECT MAX(version) as mv FROM websites WHERE business_id = ?').get(business.id) as { mv: number | null })
            ?.mv || 0;
        const ver = mv + 1;
        const wRes = db
          .prepare(
            `INSERT INTO websites (
              business_id, campaign_id, version, template_key, language, output_type,
              headline, subheadline, about_copy, services_json, cta_label, content_hash,
              local_path, public_url, status, created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, '', 'review_required', ?, ?)`
          )
          .run(
            business.id,
            task.campaign_id,
            ver,
            tKey,
            lang,
            outType,
            copy.headline,
            copy.subheadline,
            copy.about_copy,
            servicesJson,
            copy.cta_label,
            hash,
            `/api/websites/preview/${business.id}-v${ver}`,
            now,
            now
          );
        const qa = saveWebsiteQa(Number(wRes.lastInsertRowid));
        if (qa.hasFailure) {
          db.prepare("UPDATE websites SET status = 'qa_failed', updated_at = ? WHERE id = ?").run(
            now,
            wRes.lastInsertRowid
          );
        }
      } else if (task.task_type === 'follow_up_draft' && task.business_id) {
        const payload = JSON.parse(task.payload_json || '{}') as {
          contact_id?: number;
          website_id?: number;
          channel?: 'email' | 'whatsapp_link';
        };
        const contact = payload.contact_id
          ? (db.prepare('SELECT * FROM contacts WHERE id = ?').get(payload.contact_id) as ContactRecord | undefined)
          : undefined;
        if (contact && isContactSuppressed(contact.channel, contact.value)) {
          db.prepare("UPDATE tasks SET status = 'cancelled', last_error = 'Recipient opted out', updated_at = ? WHERE id = ?").run(
            now,
            task.id
          );
          res.json({ ran: true, message: 'Follow-up draft cancelled because contact opted out.' });
          return;
        }
        const business = db.prepare('SELECT * FROM businesses WHERE id = ?').get(task.business_id) as Business;
        const website = payload.website_id
          ? (db.prepare('SELECT * FROM websites WHERE id = ?').get(payload.website_id) as WebsiteRecord | undefined)
          : undefined;
        const settings = getAllSettings();
        const ch = payload.channel || 'email';
        const demoRef = website?.public_url || 'Attached concept demo ZIP package';
        const copy = buildDeterministicOutreachText({
          business,
          channel: ch,
          language: settings.ui_language,
          senderName: settings.agency_sender_name,
          demoRef,
          purpose: 'follow_up',
        });
        const hash = computeMessageContentHash({
          contact_id: contact?.id ?? null,
          recipient: contact?.value ?? '',
          channel: ch,
          purpose: 'follow_up',
          subject: copy.subject,
          body: copy.body,
          attachment_note: demoRef,
        });
        db.prepare(
          `INSERT INTO messages (
            business_id, campaign_id, contact_id, website_id, channel, purpose,
            subject, body, attachment_note, content_hash, status, follow_up_enabled, follow_up_days,
            created_at, updated_at
          ) VALUES (?, ?, ?, ?, ?, 'follow_up', ?, ?, ?, ?, 'review_required', 0, 6, ?, ?)`
        ).run(
          business.id,
          task.campaign_id,
          contact?.id ?? null,
          website?.id ?? null,
          ch,
          copy.subject,
          copy.body,
          demoRef,
          hash,
          now,
          now
        );
      }

      db.prepare("UPDATE tasks SET status = 'completed', updated_at = ? WHERE id = ?").run(now, task.id);
      logAuditEvent('task', task.id, 'task_completed', 'orchestrator', { task_type: task.task_type });
      res.json({ ran: true, task_id: task.id, task_type: task.task_type });
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Task execution failed';
      db.prepare("UPDATE tasks SET status = 'failed', last_error = ?, updated_at = ? WHERE id = ?").run(msg, now, task.id);
      res.status(500).json({ error: msg });
    }
  });

  router.patch('/tasks/:id', (req: Request, res: Response) => {
    const id = Number(req.params.id);
    const { status } = req.body as { status?: string };
    if (!['queued', 'paused', 'cancelled'].includes(status || '')) {
      res.status(400).json({ error: 'Invalid task action.' });
      return;
    }
    const now = new Date().toISOString();
    db.prepare('UPDATE tasks SET status = ?, updated_at = ? WHERE id = ?').run(status, now, id);
    res.json(db.prepare('SELECT * FROM tasks WHERE id = ?').get(id));
  });

  router.get('/audit', (_req: Request, res: Response) => {
    res.json(db.prepare('SELECT * FROM audit_events ORDER BY id DESC LIMIT 100').all());
  });

  // 8. Settings, Trial Reset, & Backups
  router.get('/settings', (_req: Request, res: Response) => {
    res.json(getAllSettings());
  });

  router.patch('/settings', (req: Request, res: Response) => {
    const body = req.body as Partial<AppSettings>;
    const upsert = db.prepare('INSERT INTO app_settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value');

    if (body.ui_language === 'en' || body.ui_language === 'hi') upsert.run('ui_language', body.ui_language);
    if (typeof body.ai_enabled === 'boolean') upsert.run('ai_enabled', String(body.ai_enabled));
    if (typeof body.followup_default_enabled === 'boolean')
      upsert.run('followup_default_enabled', String(body.followup_default_enabled));
    if (body.followup_days !== undefined) {
      const clamped = Math.min(Math.max(Number(body.followup_days) || 6, 5), 7);
      upsert.run('followup_days', String(clamped));
    }
    if (body.agency_sender_name !== undefined) upsert.run('agency_sender_name', body.agency_sender_name.trim());
    if (body.agency_sender_email !== undefined) upsert.run('agency_sender_email', body.agency_sender_email.trim());

    logAuditEvent('settings', 0, 'settings_updated', 'operator');
    res.json(getAllSettings());
  });

  router.post('/trial/reset-dental', (_req: Request, res: Response) => {
    const seeded = seedSampleDentalTrial(true);
    res.json({ ok: true, campaign_id: seeded.campaignId });
  });

  router.get('/backup/export', (_req: Request, res: Response) => {
    const backup = exportFullBackup();
    logAuditEvent('system', 0, 'backup_exported', 'operator');
    res.setHeader('Content-Type', 'application/json; charset=utf-8');
    res.setHeader('Content-Disposition', `attachment; filename="freshy-ai-backup-${Date.now()}.json"`);
    res.send(JSON.stringify(backup, null, 2));
  });

  router.post('/backup/restore', (req: Request, res: Response) => {
    try {
      const result = restoreFullBackup(req.body);
      res.json({ ok: true, restored_rows: result.restoredRows });
    } catch (err) {
      res.status(400).json({ error: err instanceof Error ? err.message : 'Restore failed.' });
    }
  });

  return router;
}
