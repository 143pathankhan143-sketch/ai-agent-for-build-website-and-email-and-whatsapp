import fs from 'node:fs';
import path from 'node:path';
import JSZip from 'jszip';
import type {
  Business,
  ContactRecord,
  ContentLanguage,
  FactRecord,
  TemplateKey,
  WebsiteRecord,
} from '../shared/types.ts';
import { escapeHtml } from './security.ts';

const TEMPLATE_IMAGE_MAP: Record<TemplateKey, string> = {
  dental: 'demo_dental_clinic_1795246251990.jpg',
  jewellery: 'demo_jewellery_atelier_1795246251616.jpg',
  salon: 'demo_salon_studio_1795246252323.jpg',
  restaurant: 'demo_restaurant_bistro_1795246252937.jpg',
  universal: 'demo_salon_studio_1795246252323.jpg',
};

export function getTemplateImagePublicUrl(templateKey: TemplateKey): string {
  const filename = TEMPLATE_IMAGE_MAP[templateKey] || TEMPLATE_IMAGE_MAP.universal;
  return `/src/assets/images/${filename}`;
}

export function getTemplateImageDiskPath(templateKey: TemplateKey): string {
  const filename = TEMPLATE_IMAGE_MAP[templateKey] || TEMPLATE_IMAGE_MAP.universal;
  return path.resolve(process.cwd(), 'src', 'assets', 'images', filename);
}

export function inferTemplateKey(category: string): TemplateKey {
  const c = category.toLowerCase();
  if (c.includes('dental') || c.includes('clinic') || c.includes('health') || c.includes('medical')) return 'dental';
  if (c.includes('jewel') || c.includes('gold') || c.includes('gem')) return 'jewellery';
  if (c.includes('salon') || c.includes('spa') || c.includes('hair') || c.includes('beauty')) return 'salon';
  if (c.includes('restaur') || c.includes('cafe') || c.includes('bistro') || c.includes('food')) return 'restaurant';
  return 'universal';
}

export function buildDeterministicWebsiteCopy(params: {
  business: Business;
  facts: FactRecord[];
  templateKey: TemplateKey;
  language: ContentLanguage;
}) {
  const { business, facts, language } = params;
  const verifiedServicesFact = facts.find(
    (f) => f.field_name === 'services' && f.verification_status === 'verified' && f.value.trim().length > 0
  );
  const verifiedAboutFact = facts.find(
    (f) => f.field_name === 'about' && f.verification_status === 'verified' && f.value.trim().length > 0
  );

  const services = verifiedServicesFact
    ? verifiedServicesFact.value
        .split(/\r?\n|,/)
        .map((s) => s.trim())
        .filter(Boolean)
    : [];

  if (language === 'hi') {
    return {
      headline: `${business.name} — ${business.locality}`,
      subheadline: `${business.locality} में ${business.category} सेवाओं के लिए स्वच्छ और आधुनिक डिजिटल परिचय।`,
      about_copy:
        verifiedAboutFact?.value ||
        `${business.name} (${business.locality}) के लिए सत्यापित तथ्यों पर आधारित एक अनौपचारिक कॉन्सेप्ट वेब डेमो।`,
      services,
      cta_label: 'संपर्क पूर्वावलोकन (डेमो)',
    };
  }

  if (language === 'bilingual') {
    return {
      headline: `${business.name} · ${business.locality}`,
      subheadline: `${business.category} concept showcase for ${business.locality} | ${business.locality} के लिए आधुनिक परिचय।`,
      about_copy:
        verifiedAboutFact?.value ||
        `${business.name} in ${business.locality}. Built strictly from verified business facts as an unofficial concept preview. | यह केवल सत्यापित तथ्यों पर आधारित एक अनौपचारिक कॉन्सेप्ट डेमो है।`,
      services,
      cta_label: 'Concept Preview / पूर्वावलोकन',
    };
  }

  return {
    headline: `${business.name} in ${business.locality}`,
    subheadline: `A calm, clear web concept tailored for ${business.category} visitors in ${business.locality}.`,
    about_copy:
      verifiedAboutFact?.value ||
      `${business.name} serves ${business.locality}. This concept demo presents only verified business details without fabricated claims.`,
    services,
    cta_label: 'Concept Inquiry Preview',
  };
}

interface PaletteSpec {
  accent: string;
  accentSoft: string;
  surface: string;
  bg: string;
}

function getTemplatePalette(templateKey: TemplateKey): PaletteSpec {
  switch (templateKey) {
    case 'dental':
      return { accent: '#0F766E', accentSoft: '#F0FDFA', surface: '#FFFFFF', bg: '#F8FAFC' };
    case 'jewellery':
      return { accent: '#7C2D12', accentSoft: '#FFFBEB', surface: '#FFFFFF', bg: '#FAFAF9' };
    case 'salon':
      return { accent: '#3F6212', accentSoft: '#F7FEE7', surface: '#FFFFFF', bg: '#F8FAF8' };
    case 'restaurant':
      return { accent: '#9A3412', accentSoft: '#FFF7ED', surface: '#FFFFFF', bg: '#FAF8F5' };
    default:
      return { accent: '#0F172A', accentSoft: '#F1F5F9', surface: '#FFFFFF', bg: '#F8FAFC' };
  }
}

export function renderDemoStylesCss(templateKey: TemplateKey): string {
  const palette = getTemplatePalette(templateKey);
  return `:root {
  --bg: ${palette.bg};
  --surface: ${palette.surface};
  --accent: ${palette.accent};
  --accent-soft: ${palette.accentSoft};
  --ink: #0f172a;
  --muted: #475569;
  --border: #e2e8f0;
}
* { box-sizing: border-box; }
html, body { margin: 0; padding: 0; overflow-x: hidden; background: var(--bg); color: var(--ink); font-family: system-ui, -apple-system, "Segoe UI", "Noto Sans Devanagari", sans-serif; line-height: 1.6; }
img { max-width: 100%; height: auto; display: block; }
a:focus-visible, button:focus-visible, input:focus-visible, textarea:focus-visible { outline: 2px solid var(--accent); outline-offset: 2px; }
.unofficial-banner { background: #0f172a; color: #f8fafc; font-size: 13px; padding: 10px 20px; text-align: center; border-bottom: 2px solid var(--accent); }
.container { max-width: 1120px; margin: 0 auto; padding: 0 24px; }
header.site-header { display: flex; flex-wrap: wrap; align-items: center; justify-content: space-between; gap: 16px; padding: 20px 0; border-bottom: 1px solid var(--border); }
.brand { font-weight: 700; font-size: 20px; color: var(--ink); text-decoration: none; }
nav.nav-links { display: flex; gap: 24px; font-size: 14px; }
nav.nav-links a { color: var(--muted); text-decoration: none; }
nav.nav-links a:hover { color: var(--ink); text-decoration: underline; }
.hero { display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 36px; align-items: center; padding: 56px 0; }
.hero-kicker { font-size: 13px; color: var(--accent); font-weight: 600; margin-bottom: 10px; }
.hero h1 { font-size: clamp(2rem, 4vw, 3rem); line-height: 1.15; margin: 0 0 16px; letter-spacing: -0.02em; }
.hero p { color: var(--muted); font-size: 17px; margin: 0 0 24px; max-width: 58ch; }
.btn-primary { display: inline-block; background: var(--accent); color: #ffffff; padding: 12px 22px; border-radius: 8px; text-decoration: none; font-weight: 600; font-size: 14px; border: none; cursor: pointer; }
.hero-media { border-radius: 12px; overflow: hidden; border: 1px solid var(--border); background: var(--accent-soft); aspect-ratio: 16 / 9; }
.hero-media img { width: 100%; height: 100%; object-fit: cover; }
section.band { padding: 48px 0; border-top: 1px solid var(--border); }
section.band h2 { font-size: 24px; margin: 0 0 18px; letter-spacing: -0.01em; }
.services-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 16px; }
.service-card { background: var(--surface); border: 1px solid var(--border); border-radius: 10px; padding: 20px; }
.service-card h3 { font-size: 16px; margin: 0 0 6px; }
.two-col { display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 32px; }
.fact-box { background: var(--surface); border: 1px solid var(--border); border-radius: 10px; padding: 24px; }
.fact-row { padding: 10px 0; border-bottom: 1px solid var(--border); font-size: 14px; }
.fact-row:last-child { border-bottom: none; }
.fact-label { color: var(--muted); display: block; font-size: 12px; }
.concept-form { background: var(--surface); border: 1px solid var(--border); border-radius: 10px; padding: 24px; }
.concept-form label { display: block; font-size: 13px; font-weight: 600; margin-bottom: 6px; }
.concept-form input, .concept-form textarea { width: 100%; padding: 10px 12px; border: 1px solid var(--border); border-radius: 6px; margin-bottom: 14px; background: #f8fafc; color: #64748b; }
.concept-form button[disabled] { opacity: 0.65; cursor: not-allowed; background: #475569; color: #fff; border: none; padding: 10px 18px; border-radius: 6px; font-weight: 600; }
.form-notice { font-size: 12px; color: #9a3412; background: #fff7ed; border: 1px solid #fed7aa; padding: 10px 12px; border-radius: 6px; margin-bottom: 14px; }
footer.site-footer { border-top: 1px solid var(--border); padding: 28px 0 44px; font-size: 13px; color: var(--muted); }
`;
}

export function renderWebsiteHtml(params: {
  website: WebsiteRecord;
  business: Business;
  facts: FactRecord[];
  contacts: ContactRecord[];
  assetSrc?: string;
  externalCssHref?: string;
}): string {
  const { website, business, facts, contacts, assetSrc, externalCssHref } = params;
  const htmlLang = website.language === 'hi' ? 'hi' : 'en';
  const services: string[] = (() => {
    try {
      const parsed = JSON.parse(website.services_json);
      return Array.isArray(parsed) ? parsed.map(String) : [];
    } catch {
      return [];
    }
  })();

  const verifiedHours = facts.find(
    (f) => f.field_name === 'opening_hours' && f.verification_status === 'verified' && f.value.trim()
  );
  const verifiedEmail = contacts.find(
    (c) => c.channel === 'email' && c.verification_status === 'verified' && c.value.trim()
  );
  const verifiedWhatsapp = contacts.find(
    (c) => c.channel === 'whatsapp_link' && c.verification_status === 'verified' && c.value.trim()
  );
  const verifiedPhone = contacts.find(
    (c) => c.channel === 'phone' && c.verification_status === 'verified' && c.value.trim()
  );

  const imgUrl = assetSrc || getTemplateImagePublicUrl(website.template_key);
  const isHindi = website.language === 'hi';
  const isBilingual = website.language === 'bilingual';

  const disclaimerText = isHindi
    ? 'अनौपचारिक कॉन्सेप्ट डेमो — इस व्यवसाय से संबद्ध नहीं (Unofficial concept demo — not affiliated with this business)'
    : isBilingual
      ? 'Unofficial concept demo — not affiliated with this business · अनौपचारिक कॉन्सेप्ट डेमो — इस व्यवसाय से संबद्ध नहीं'
      : 'Unofficial concept demo — not affiliated with this business';

  const servicesHeading = isHindi ? 'सत्यापित सेवाएँ' : isBilingual ? 'Verified Services · सत्यापित सेवाएँ' : 'Verified Services';
  const aboutHeading = isHindi ? 'परिचय' : isBilingual ? 'About · परिचय' : 'About';
  const contactHeading = isHindi ? 'संपर्क और समय' : isBilingual ? 'Contact & Hours · संपर्क' : 'Contact & Hours';
  const formNoticeText = isHindi
    ? 'यह केवल कॉन्सेप्ट पूर्वावलोकन फ़ॉर्म है — डेटा संग्रह बंद है।'
    : 'Concept preview only — inquiry submission is disabled and collects no customer data.';

  const cssBlock = externalCssHref
    ? `<link rel="stylesheet" href="${escapeHtml(externalCssHref)}" />`
    : `<style>\n${renderDemoStylesCss(website.template_key)}\n</style>`;

  const servicesHtml =
    services.length > 0
      ? services
          .map(
            (svc, idx) => `<article class="service-card">
          <h3>0${idx + 1}. ${escapeHtml(svc)}</h3>
          <p class="fact-label">${isHindi ? 'सत्यापित तथ्य स्रोत से' : 'Listed from verified business facts'}</p>
        </article>`
          )
          .join('\n')
      : `<div class="service-card">
          <h3>${isHindi ? 'सेवा विवरण समीक्षाधीन' : 'Service list awaiting verification'}</h3>
          <p class="fact-label">${
            isHindi ? 'बिना सत्यापित स्रोत के कोई सेवा नहीं जोड़ी गई।' : 'No unverified services fabricated.'
          }</p>
        </div>`;

  const clinicalNotice =
    website.template_key === 'dental'
      ? `<p class="fact-label" style="margin-top:12px;">${
          isHindi
            ? 'सूचना: कोई अपॉइंटमेंट बुकिंग, डॉक्टर दावा या बिना सत्यापित समीक्षा नहीं जोड़ी गई है।'
            : 'Notice: No unverified medical claims, doctor credentials, pricing, or patient testimonials are fabricated on this concept.'
        }</p>`
      : '';

  return `<!doctype html>
<html lang="${htmlLang}">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <meta name="robots" content="noindex, nofollow" />
  <title>${escapeHtml(business.name)} — Concept Demo</title>
  ${cssBlock}
</head>
<body>
  <div class="unofficial-banner" role="note">${escapeHtml(disclaimerText)}</div>
  <div class="container">
    <header class="site-header">
      <a href="#top" class="brand">${escapeHtml(business.name)}</a>
      <nav class="nav-links" aria-label="Primary">
        <a href="#services">${escapeHtml(servicesHeading)}</a>
        <a href="#about">${escapeHtml(aboutHeading)}</a>
        <a href="#contact">${escapeHtml(contactHeading)}</a>
      </nav>
    </header>

    <main id="top">
      <section class="hero">
        <div>
          <div class="hero-kicker">${escapeHtml(business.category)} · ${escapeHtml(business.locality)}</div>
          <h1>${escapeHtml(website.headline)}</h1>
          <p>${escapeHtml(website.subheadline)}</p>
          <a href="#contact" class="btn-primary">${escapeHtml(website.cta_label || 'Concept Preview')}</a>
        </div>
        <div class="hero-media">
          <img src="${escapeHtml(imgUrl)}" alt="${escapeHtml(business.name)} concept illustration" />
        </div>
      </section>

      <section id="services" class="band">
        <h2>${escapeHtml(servicesHeading)}</h2>
        <div class="services-grid">
          ${servicesHtml}
        </div>
      </section>

      <section id="about" class="band">
        <h2>${escapeHtml(aboutHeading)}</h2>
        <p style="max-width:70ch;color:var(--muted);">${escapeHtml(website.about_copy)}</p>
        ${clinicalNotice}
      </section>

      <section id="contact" class="band">
        <h2>${escapeHtml(contactHeading)}</h2>
        <div class="two-col">
          <div class="fact-box">
            <div class="fact-row">
              <span class="fact-label">${isHindi ? 'इलाका / पता' : 'Locality / Address'}</span>
              <span>${escapeHtml(business.address || business.locality)}</span>
            </div>
            ${
              verifiedHours
                ? `<div class="fact-row"><span class="fact-label">${
                    isHindi ? 'कार्य समय' : 'Verified Hours'
                  }</span><span>${escapeHtml(verifiedHours.value)}</span></div>`
                : ''
            }
            <div class="fact-row">
              <span class="fact-label">${isHindi ? 'सत्यापित ईमेल' : 'Verified Public Email'}</span>
              <span>${
                verifiedEmail
                  ? `<a href="mailto:${escapeHtml(verifiedEmail.value)}">${escapeHtml(verifiedEmail.value)}</a>`
                  : escapeHtml(isHindi ? 'उपलब्ध नहीं / अज्ञात' : 'Not verified / Unknown')
              }</span>
            </div>
            ${
              verifiedWhatsapp
                ? `<div class="fact-row"><span class="fact-label">Verified WhatsApp Link</span><a href="${escapeHtml(
                    verifiedWhatsapp.value
                  )}" rel="noopener noreferrer">${escapeHtml(verifiedWhatsapp.value)}</a></div>`
                : ''
            }
            ${
              verifiedPhone
                ? `<div class="fact-row"><span class="fact-label">${
                    isHindi ? 'फ़ोन' : 'Phone'
                  }</span><span>${escapeHtml(verifiedPhone.value)}</span></div>`
                : ''
            }
          </div>

          <form class="concept-form" onsubmit="return false;" aria-disabled="true">
            <div class="form-notice">${escapeHtml(formNoticeText)}</div>
            <label for="concept-name">${isHindi ? 'नाम (पूर्वावलोकन)' : 'Your Name (Preview)'}</label>
            <input id="concept-name" type="text" disabled placeholder="${escapeHtml(
              isHindi ? 'डेमो मोड में बंद' : 'Disabled in concept demo'
            )}" />
            <label for="concept-msg">${isHindi ? 'संदेश (पूर्वावलोकन)' : 'Message (Preview)'}</label>
            <textarea id="concept-msg" rows="3" disabled placeholder="${escapeHtml(
              isHindi ? 'कोई डेटा सबमिट नहीं होगा' : 'No data is submitted or stored'
            )}"></textarea>
            <button type="button" disabled aria-disabled="true">${escapeHtml(
              isHindi ? 'संपर्क फ़ॉर्म बंद (केवल डेमो)' : 'Inquiry Disabled (Concept Only)'
            )}</button>
          </form>
        </div>
      </section>
    </main>

    <footer class="site-footer">
      <div>${escapeHtml(disclaimerText)}</div>
      <div style="margin-top:6px;">Freshy AI Concept Preview · Version ${website.version} · Output: ${escapeHtml(
        website.output_type.toUpperCase()
      )}</div>
    </footer>
  </div>
</body>
</html>`;
}

export interface QaCheckInput {
  check_name: string;
  outcome: 'pass' | 'warning' | 'fail';
  details: string;
}

export function runWebsiteQaChecks(params: {
  website: WebsiteRecord;
  business: Business;
  facts: FactRecord[];
  contacts: ContactRecord[];
  sourcesCount: number;
  html: string;
}): QaCheckInput[] {
  const { website, facts, contacts, sourcesCount, html } = params;
  const checks: QaCheckInput[] = [];

  // 1. Required structure
  const hasSections =
    html.includes('id="services"') && html.includes('id="about"') && html.includes('id="contact"') && html.includes('<h1');
  checks.push({
    check_name: 'structure_sections',
    outcome: hasSections ? 'pass' : 'fail',
    details: hasSections
      ? 'Hero, verified services, about, and contact sections present.'
      : 'Missing one or more required structural sections.',
  });

  // 2. Missing placeholders
  const placeholderHits = ['{{', '}}', 'TODO', 'Lorem ipsum', '[INSERT', 'undefined'].filter((tok) =>
    html.includes(tok)
  );
  checks.push({
    check_name: 'no_placeholders',
    outcome: placeholderHits.length === 0 ? 'pass' : 'fail',
    details:
      placeholderHits.length === 0
        ? 'No unresolved template placeholders found.'
        : `Detected unresolved tokens: ${placeholderHits.join(', ')}`,
  });

  // 3. Unofficial disclaimer + noindex
  const hasDisclaimer = html.includes('Unofficial concept demo') && html.includes('noindex, nofollow');
  checks.push({
    check_name: 'unofficial_disclaimer_and_noindex',
    outcome: hasDisclaimer ? 'pass' : 'fail',
    details: hasDisclaimer
      ? 'Unofficial concept banner and robots noindex meta tag verified.'
      : 'Missing required unofficial demo disclaimer or noindex directive.',
  });

  // 4. Disabled concept contact form
  const hasDisabledForm = html.includes('aria-disabled="true"') && html.includes('disabled');
  checks.push({
    check_name: 'disabled_concept_form',
    outcome: hasDisabledForm ? 'pass' : 'fail',
    details: hasDisabledForm
      ? 'Concept contact form is disabled and collects zero customer data.'
      : 'Contact form must be explicitly disabled on unapproved concept demos.',
  });

  // 5. Verified email presence check (flags missing/unknown email cleanly!)
  const verifiedEmail = contacts.find(
    (c) => c.channel === 'email' && c.verification_status === 'verified' && c.value.trim().length > 0
  );
  checks.push({
    check_name: 'verified_email_availability',
    outcome: verifiedEmail ? 'pass' : 'warning',
    details: verifiedEmail
      ? `Verified public email available (${verifiedEmail.value}).`
      : 'Missing verified email (status: unknown). Demo preview is valid, but email outreach stays blocked until verified.',
  });

  // 6. Responsive viewport & overflow guard
  const hasResponsive = html.includes('width=device-width') && html.includes('overflow-x: hidden');
  checks.push({
    check_name: 'responsive_overflow_safety',
    outcome: hasResponsive ? 'pass' : 'fail',
    details: hasResponsive
      ? 'Viewport meta and horizontal-overflow guards verified.'
      : 'Missing viewport meta or horizontal overflow protection.',
  });

  // 7. Accessibility basics
  const h1Count = (html.match(/<h1[\s>]/g) || []).length;
  const hasAlt = html.includes('<img ') ? html.includes('alt="') : true;
  const a11yOk = html.includes('<html lang=') && h1Count === 1 && hasAlt;
  checks.push({
    check_name: 'accessibility_basics',
    outcome: a11yOk ? 'pass' : 'fail',
    details: a11yOk
      ? 'Language attribute, single H1 landmark, image alt text, and focus outlines verified.'
      : 'Check <html lang>, single <h1>, or image alt attribute.',
  });

  // 8. Verified fact & source attribution
  const verifiedFactsCount = facts.filter((f) => f.verification_status === 'verified').length;
  checks.push({
    check_name: 'source_attribution_and_facts',
    outcome: sourcesCount > 0 && verifiedFactsCount > 0 ? 'pass' : 'warning',
    details:
      sourcesCount > 0 && verifiedFactsCount > 0
        ? `${verifiedFactsCount} verified fact(s) linked across ${sourcesCount} collected source(s).`
        : `Only ${verifiedFactsCount} verified fact(s) and ${sourcesCount} source(s) found; human review recommended.`,
  });

  // 9. Local asset availability
  const assetDiskPath = getTemplateImageDiskPath(website.template_key);
  const assetExists = fs.existsSync(assetDiskPath);
  checks.push({
    check_name: 'local_asset_integrity',
    outcome: assetExists ? 'pass' : 'warning',
    details: assetExists
      ? `Licensed local template asset verified (${path.basename(assetDiskPath)}).`
      : 'Local template asset file missing; SVG/CSS fallback active.',
  });

  return checks;
}

export async function buildWebsiteZipBuffer(params: {
  website: WebsiteRecord;
  business: Business;
  facts: FactRecord[];
  contacts: ContactRecord[];
}): Promise<{ buffer: Buffer; filename: string }> {
  const { website, business, facts, contacts } = params;
  const zip = new JSZip();
  const slug = business.name
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-|-$/g, '') || 'demo-site';

  const imgDiskPath = getTemplateImageDiskPath(website.template_key);
  const hasImg = fs.existsSync(imgDiskPath);

  if (website.output_type === 'react') {
    const services: string[] = (() => {
      try {
        const parsed = JSON.parse(website.services_json);
        return Array.isArray(parsed) ? parsed.map(String) : [];
      } catch {
        return [];
      }
    })();

    if (hasImg) {
      zip.file('public/hero.jpg', fs.readFileSync(imgDiskPath));
    }

    zip.file(
      'package.json',
      JSON.stringify(
        {
          name: `${slug}-concept-demo`,
          private: true,
          version: '1.0.0',
          type: 'module',
          scripts: {
            dev: 'vite',
            build: 'tsc && vite build',
            preview: 'vite preview',
          },
          dependencies: {
            react: '^19.0.0',
            'react-dom': '^19.0.0',
          },
          devDependencies: {
            '@types/react': '^19.0.0',
            '@types/react-dom': '^19.0.0',
            '@vitejs/plugin-react': '^4.3.4',
            typescript: '^5.6.3',
            vite: '^6.0.0',
          },
        },
        null,
        2
      )
    );

    zip.file(
      'index.html',
      `<!doctype html>
<html lang="${website.language === 'hi' ? 'hi' : 'en'}">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="robots" content="noindex, nofollow" />
    <title>${escapeHtml(business.name)} — Concept Demo</title>
  </head>
  <body>
    <div id="root"></div>
    <script type="module" src="/src/main.tsx"></script>
  </body>
</html>
`
    );

    zip.file(
      'vite.config.ts',
      `import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
export default defineConfig({ plugins: [react()] });
`
    );

    zip.file(
      'tsconfig.json',
      JSON.stringify(
        {
          compilerOptions: {
            target: 'ES2020',
            module: 'ESNext',
            moduleResolution: 'bundler',
            jsx: 'react-jsx',
            strict: true,
            noEmit: true,
          },
          include: ['src'],
        },
        null,
        2
      )
    );

    zip.file('src/index.css', renderDemoStylesCss(website.template_key));
    zip.file(
      'src/main.tsx',
      `import { createRoot } from 'react-dom/client';
import App from './App';
import './index.css';
createRoot(document.getElementById('root')!).render(<App />);
`
    );

    const verifiedHours = facts.find(
      (f) => f.field_name === 'opening_hours' && f.verification_status === 'verified'
    )?.value;
    const verifiedEmail = contacts.find(
      (c) => c.channel === 'email' && c.verification_status === 'verified' && c.value.trim()
    )?.value;

    const dataJson = JSON.stringify(
      {
        businessName: business.name,
        category: business.category,
        locality: business.locality,
        address: business.address || business.locality,
        headline: website.headline,
        subheadline: website.subheadline,
        aboutCopy: website.about_copy,
        ctaLabel: website.cta_label,
        services,
        verifiedHours: verifiedHours || null,
        verifiedEmail: verifiedEmail || null,
        hasImage: hasImg,
      },
      null,
      2
    );

    zip.file(
      'src/App.tsx',
      `const DATA = ${dataJson};

export default function App() {
  return (
    <div>
      <div className="unofficial-banner" role="note">
        Unofficial concept demo — not affiliated with this business
      </div>
      <div className="container">
        <header className="site-header">
          <a href="#top" className="brand">{DATA.businessName}</a>
          <nav className="nav-links" aria-label="Primary">
            <a href="#services">Services</a>
            <a href="#about">About</a>
            <a href="#contact">Contact</a>
          </nav>
        </header>
        <main id="top">
          <section className="hero">
            <div>
              <div className="hero-kicker">{DATA.category} · {DATA.locality}</div>
              <h1>{DATA.headline}</h1>
              <p>{DATA.subheadline}</p>
              <a href="#contact" className="btn-primary">{DATA.ctaLabel}</a>
            </div>
            <div className="hero-media">
              {DATA.hasImage ? (
                <img src="/hero.jpg" alt={\`\${DATA.businessName} concept illustration\`} />
              ) : null}
            </div>
          </section>
          <section id="services" className="band">
            <h2>Verified Services</h2>
            <div className="services-grid">
              {DATA.services.length > 0 ? DATA.services.map((svc, idx) => (
                <article key={idx} className="service-card">
                  <h3>0{idx + 1}. {svc}</h3>
                  <p className="fact-label">Listed from verified business facts</p>
                </article>
              )) : (
                <div className="service-card">
                  <h3>Service list awaiting verification</h3>
                </div>
              )}
            </div>
          </section>
          <section id="about" className="band">
            <h2>About</h2>
            <p style={{ maxWidth: '70ch', color: 'var(--muted)' }}>{DATA.aboutCopy}</p>
          </section>
          <section id="contact" className="band">
            <h2>Contact & Hours</h2>
            <div className="two-col">
              <div className="fact-box">
                <div className="fact-row">
                  <span className="fact-label">Locality / Address</span>
                  <span>{DATA.address}</span>
                </div>
                {DATA.verifiedHours ? (
                  <div className="fact-row">
                    <span className="fact-label">Verified Hours</span>
                    <span>{DATA.verifiedHours}</span>
                  </div>
                ) : null}
                <div className="fact-row">
                  <span className="fact-label">Verified Email</span>
                  <span>{DATA.verifiedEmail || 'Not verified / Unknown'}</span>
                </div>
              </div>
              <form className="concept-form" onSubmit={(e) => e.preventDefault()} aria-disabled="true">
                <div className="form-notice">Concept preview only — inquiry submission disabled.</div>
                <label htmlFor="c-name">Your Name</label>
                <input id="c-name" type="text" disabled placeholder="Disabled in concept demo" />
                <label htmlFor="c-msg">Message</label>
                <textarea id="c-msg" rows={3} disabled placeholder="No data is submitted" />
                <button type="button" disabled aria-disabled="true">Inquiry Disabled (Concept Only)</button>
              </form>
            </div>
          </section>
        </main>
        <footer className="site-footer">
          Unofficial concept demo — not affiliated with this business · Content Hash: ${website.content_hash.slice(0, 12)}
        </footer>
      </div>
    </div>
  );
}
`
    );

    zip.file(
      'README.md',
      `# ${business.name} — React Concept Demo\n\nUnofficial concept demo generated by Freshy AI.\n\nRun locally:\n\`\`\`bash\nnpm install\nnpm run dev\n\`\`\`\n`
    );

    const buffer = await zip.generateAsync({ type: 'nodebuffer' });
    return { buffer, filename: `${slug}-react-v${website.version}.zip` };
  }

  // Plain HTML/CSS/JS package (opens directly without Node build)
  if (hasImg) {
    zip.file('assets/hero.jpg', fs.readFileSync(imgDiskPath));
  }
  zip.file('styles.css', renderDemoStylesCss(website.template_key));
  zip.file(
    'script.js',
    `// Concept demo script — zero tracking, zero form submission.\ndocument.addEventListener('DOMContentLoaded', function () {\n  var forms = document.querySelectorAll('form.concept-form');\n  forms.forEach(function (f) { f.addEventListener('submit', function (e) { e.preventDefault(); }); });\n});\n`
  );
  zip.file(
    'index.html',
    renderWebsiteHtml({
      website,
      business,
      facts,
      contacts,
      assetSrc: hasImg ? './assets/hero.jpg' : undefined,
      externalCssHref: './styles.css',
    }).replace('</body>', '  <script src="./script.js"></script>\n</body>')
  );
  zip.file(
    'README.txt',
    `${business.name} — Unofficial Concept Demo (HTML/CSS/JS)\nContent Hash: ${website.content_hash}\nOpen index.html directly in any browser. No Node build required.\n`
  );

  const buffer = await zip.generateAsync({ type: 'nodebuffer' });
  return { buffer, filename: `${slug}-html-v${website.version}.zip` };
}
