import { useCallback, useEffect, useState } from 'react';
import {
  Activity,
  FileSearch,
  FolderPlus,
  LayoutDashboard,
  LayoutTemplate,
  MailCheck,
  Menu,
  Settings,
  Users,
  X,
} from 'lucide-react';
import { api } from './lib/api.ts';
import { DICTIONARY, t, type ScreenId } from './shared/i18n.ts';
import type {
  AppSettings,
  AuditEventRecord,
  Business,
  Campaign,
  ContactRecord,
  FactRecord,
  LeadStatus,
  MessageRecord,
  OverviewSummary,
  SourceRecord,
  SuppressionRecord,
  TaskRecord,
  UiLanguage,
  WebsiteRecord,
} from './shared/types.ts';
import { ActivityScreen } from './components/ActivityScreen.tsx';
import { LeadsScreen } from './components/LeadsScreen.tsx';
import { NewCampaignScreen } from './components/NewCampaignScreen.tsx';
import { OutreachScreen } from './components/OutreachScreen.tsx';
import { OverviewScreen } from './components/OverviewScreen.tsx';
import { ResearchScreen } from './components/ResearchScreen.tsx';
import { SettingsScreen } from './components/SettingsScreen.tsx';
import { StudioScreen } from './components/StudioScreen.tsx';

const NAV_ITEMS: Array<{ id: ScreenId; group: 'pipeline' | 'governance'; icon: typeof LayoutDashboard }> = [
  { id: 'overview', group: 'pipeline', icon: LayoutDashboard },
  { id: 'new_campaign', group: 'pipeline', icon: FolderPlus },
  { id: 'leads', group: 'pipeline', icon: Users },
  { id: 'research', group: 'pipeline', icon: FileSearch },
  { id: 'studio', group: 'pipeline', icon: LayoutTemplate },
  { id: 'outreach', group: 'pipeline', icon: MailCheck },
  { id: 'activity', group: 'governance', icon: Activity },
  { id: 'settings', group: 'governance', icon: Settings },
];

export default function App() {
  const [screen, setScreen] = useState<ScreenId>('overview');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [lang, setLang] = useState<UiLanguage>('en');
  const [busy, setBusy] = useState(false);
  const [toast, setToast] = useState<{ kind: 'info' | 'error'; text: string } | null>(null);

  const [overview, setOverview] = useState<OverviewSummary | null>(null);
  const [campaigns, setCampaigns] = useState<Campaign[]>([]);
  const [leads, setLeads] = useState<Business[]>([]);
  const [selectedCampaignFilter, setSelectedCampaignFilter] = useState<number | null>(null);
  const [selectedLeadId, setSelectedLeadId] = useState<number | null>(null);
  const [leadDetail, setLeadDetail] = useState<{
    business: Business;
    sources: SourceRecord[];
    facts: FactRecord[];
    contacts: ContactRecord[];
  } | null>(null);
  const [websites, setWebsites] = useState<WebsiteRecord[]>([]);
  const [messages, setMessages] = useState<MessageRecord[]>([]);
  const [suppressions, setSuppressions] = useState<SuppressionRecord[]>([]);
  const [tasks, setTasks] = useState<TaskRecord[]>([]);
  const [audit, setAudit] = useState<AuditEventRecord[]>([]);
  const [settings, setSettings] = useState<AppSettings | null>(null);

  const notify = useCallback((text: string, kind: 'info' | 'error' = 'info') => {
    setToast({ text, kind });
  }, []);

  useEffect(() => {
    if (!toast) return;
    const timer = setTimeout(() => setToast(null), 4500);
    return () => clearTimeout(timer);
  }, [toast]);

  const refreshAll = useCallback(async (focusLeadId?: number | null) => {
    const [ov, camps, lds, webs, msgs, sups, tsks, aud, sets] = await Promise.all([
      api.getOverview(),
      api.getCampaigns(),
      api.getLeads(),
      api.getWebsites(),
      api.getOutreach(),
      api.getSuppressions(),
      api.getTasks(),
      api.getAudit(),
      api.getSettings(),
    ]);
    setOverview(ov);
    setCampaigns(camps);
    setLeads(lds);
    setWebsites(webs);
    setMessages(msgs);
    setSuppressions(sups);
    setTasks(tsks);
    setAudit(aud);
    setSettings(sets);
    setLang(sets.ui_language);

    const targetLead = focusLeadId ?? selectedLeadId ?? lds[0]?.id ?? null;
    if (targetLead) {
      setSelectedLeadId(targetLead);
      try {
        const det = await api.getLeadDetail(targetLead);
        setLeadDetail(det);
      } catch {
        setLeadDetail(null);
      }
    } else {
      setLeadDetail(null);
    }
  }, [selectedLeadId]);

  useEffect(() => {
    refreshAll().catch((err) => notify(err instanceof Error ? err.message : 'Failed to load workspace', 'error'));
  }, []);

  const loadLeadDetail = useCallback(async (id: number) => {
    setSelectedLeadId(id);
    try {
      const det = await api.getLeadDetail(id);
      setLeadDetail(det);
    } catch (err) {
      notify(err instanceof Error ? err.message : 'Failed to load lead detail', 'error');
    }
  }, [notify]);

  const runAction = async (fn: () => Promise<void>) => {
    setBusy(true);
    try {
      await fn();
    } catch (err) {
      notify(err instanceof Error ? err.message : 'Action failed', 'error');
    } finally {
      setBusy(false);
    }
  };

  const handleToggleLanguage = async (nextLang: UiLanguage) => {
    setLang(nextLang);
    await runAction(async () => {
      const updated = await api.updateSettings({ ui_language: nextLang });
      setSettings(updated);
    });
  };

  const dict = t(lang);

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex">
      {/* Desktop Sidebar */}
      <aside className="hidden lg:flex lg:w-64 lg:flex-col bg-white border-r border-slate-200 shrink-0">
        <div className="h-16 px-6 flex items-center border-b border-slate-200">
          <span className="text-lg font-bold tracking-tight text-slate-900 whitespace-nowrap shrink-0">
            {dict.brand}
          </span>
        </div>

        <nav className="flex-1 px-3 py-5 space-y-6 overflow-y-auto" aria-label="Workspace screens">
          {(['pipeline', 'governance'] as const).map((grp) => (
            <div key={grp}>
              <div className="px-3 mb-2 text-xs font-medium text-slate-400">
                {dict.navGroups[grp]}
              </div>
              <ul className="space-y-1">
                {NAV_ITEMS.filter((item) => item.group === grp).map((item) => {
                  const Icon = item.icon;
                  const active = screen === item.id;
                  return (
                    <li key={item.id}>
                      <button
                        type="button"
                        onClick={() => setScreen(item.id)}
                        className={`w-full flex items-center gap-3 px-3 py-2 text-sm rounded-md transition-colors cursor-pointer whitespace-nowrap ${
                          active
                            ? 'bg-teal-50 text-teal-800 font-medium'
                            : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
                        }`}
                      >
                        <Icon className="w-4 h-4 shrink-0" aria-hidden="true" />
                        <span className="truncate">{dict.screens[item.id]}</span>
                      </button>
                    </li>
                  );
                })}
              </ul>
            </div>
          ))}
        </nav>

        {/* Language Switcher in Sidebar Footer */}
        <div className="p-4 border-t border-slate-200 space-y-2">
          <div className="text-xs font-medium text-slate-500">{dict.labels.languageToggle}</div>
          <div className="grid grid-cols-2 gap-1 p-1 bg-slate-100 rounded-md">
            <button
              type="button"
              onClick={() => handleToggleLanguage('en')}
              className={`py-1.5 text-xs font-medium rounded cursor-pointer transition-colors ${
                lang === 'en' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              English
            </button>
            <button
              type="button"
              onClick={() => handleToggleLanguage('hi')}
              className={`py-1.5 text-xs font-medium rounded cursor-pointer transition-colors ${
                lang === 'hi' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              हिन्दी
            </button>
          </div>
        </div>
      </aside>

      {/* Mobile Navigation Drawer */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 z-50 lg:hidden flex">
          <div
            className="fixed inset-0 bg-slate-900/40"
            onClick={() => setMobileMenuOpen(false)}
            aria-hidden="true"
          />
          <div className="relative w-64 max-w-[80vw] bg-white h-full border-r border-slate-200 flex flex-col">
            <div className="h-16 px-5 flex items-center justify-between border-b border-slate-200">
              <span className="text-lg font-bold tracking-tight text-slate-900">{dict.brand}</span>
              <button
                type="button"
                onClick={() => setMobileMenuOpen(false)}
                className="p-1.5 text-slate-500 hover:text-slate-900"
                aria-label="Close navigation"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <nav className="flex-1 p-3 space-y-1 overflow-y-auto">
              {NAV_ITEMS.map((item) => {
                const Icon = item.icon;
                const active = screen === item.id;
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => {
                      setScreen(item.id);
                      setMobileMenuOpen(false);
                    }}
                    className={`w-full flex items-center gap-3 px-3 py-2 text-sm rounded-md ${
                      active ? 'bg-teal-50 text-teal-800 font-medium' : 'text-slate-600 hover:bg-slate-100'
                    }`}
                  >
                    <Icon className="w-4 h-4 shrink-0" aria-hidden="true" />
                    <span>{dict.screens[item.id]}</span>
                  </button>
                );
              })}
            </nav>
            <div className="p-4 border-t border-slate-200 grid grid-cols-2 gap-1 bg-slate-50">
              <button
                type="button"
                onClick={() => handleToggleLanguage('en')}
                className={`py-1.5 text-xs font-medium rounded ${lang === 'en' ? 'bg-white shadow-xs' : 'text-slate-600'}`}
              >
                English
              </button>
              <button
                type="button"
                onClick={() => handleToggleLanguage('hi')}
                className={`py-1.5 text-xs font-medium rounded ${lang === 'hi' ? 'bg-white shadow-xs' : 'text-slate-600'}`}
              >
                हिन्दी
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Main Content Area */}
      <div className="flex-1 min-w-0 flex flex-col">
        {/* Clean 3-Zone Top Bar */}
        <header className="h-16 bg-white border-b border-slate-200 px-6 flex items-center justify-between gap-8 shrink-0">
          <div className="flex items-center gap-3 min-w-0">
            <button
              type="button"
              onClick={() => setMobileMenuOpen(true)}
              className="lg:hidden p-1.5 -ml-1.5 text-slate-600 hover:text-slate-900"
              aria-label="Open navigation"
            >
              <Menu className="w-5 h-5" />
            </button>
            <div className="lg:hidden text-base font-bold tracking-tight text-slate-900 whitespace-nowrap shrink-0">
              {dict.brand}
            </div>
            <div className="text-sm text-slate-500 truncate">
              <span className="font-medium text-slate-900">{dict.screens[screen]}</span>
              <span className="hidden md:inline text-slate-400"> · {dict.screenDescriptions[screen]}</span>
            </div>
          </div>

          <div className="flex items-center gap-3 shrink-0">
            <button
              type="button"
              onClick={() => setScreen('new_campaign')}
              className="px-4 py-2 text-xs font-medium bg-teal-700 text-white rounded-md hover:bg-teal-800 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              {dict.newCampaignCta}
            </button>
          </div>
        </header>

        {/* Toast Notification */}
        {toast && (
          <div
            role="status"
            className={`mx-6 mt-4 px-4 py-2.5 text-xs font-medium rounded-md border flex items-center justify-between gap-4 ${
              toast.kind === 'error'
                ? 'bg-red-50 border-red-200 text-red-800'
                : 'bg-teal-50 border-teal-200 text-teal-900'
            }`}
          >
            <span>{toast.text}</span>
            <button type="button" onClick={() => setToast(null)} className="text-current opacity-70 hover:opacity-100">
              ×
            </button>
          </div>
        )}

        {/* Active Viewport */}
        <main className="flex-1 p-6 max-w-[1440px] w-full mx-auto">
          {screen === 'overview' && (
            <OverviewScreen
              overview={overview}
              lang={lang}
              busy={busy}
              onNavigate={setScreen}
              onResetTrial={() =>
                runAction(async () => {
                  const res = await api.resetDentalTrial();
                  await refreshAll();
                  setSelectedCampaignFilter(res.campaign_id);
                  notify(DICTIONARY[lang].resetTrialCta + ' complete');
                })
              }
              onRunNextTask={() =>
                runAction(async () => {
                  const res = await api.runNextTask();
                  await refreshAll();
                  notify(res.ran ? `Completed task: ${res.task_type}` : res.message || 'No queued tasks');
                })
              }
            />
          )}

          {screen === 'new_campaign' && (
            <NewCampaignScreen
              campaigns={campaigns}
              lang={lang}
              busy={busy}
              onCreateCampaign={(payload) =>
                runAction(async () => {
                  const created = await api.createCampaign(payload);
                  await refreshAll();
                  setSelectedCampaignFilter(created.id);
                  notify(`Campaign "${created.name}" created.`);
                })
              }
              onToggleCampaignStatus={(id, nextStatus) =>
                runAction(async () => {
                  await api.setCampaignStatus(id, nextStatus);
                  await refreshAll();
                  notify(`Campaign status updated to ${nextStatus}.`);
                })
              }
              onSelectCampaignForLeads={(id) => {
                setSelectedCampaignFilter(id);
                setScreen('leads');
              }}
            />
          )}

          {screen === 'leads' && (
            <LeadsScreen
              leads={leads}
              campaigns={campaigns}
              selectedCampaignId={selectedCampaignFilter}
              lang={lang}
              busy={busy}
              onSelectCampaignFilter={setSelectedCampaignFilter}
              onAddLead={(payload) =>
                runAction(async () => {
                  const res = await api.createLead(payload);
                  await refreshAll(res.lead.id);
                  notify(
                    res.duplicate_flagged
                      ? 'Lead added with duplicate review warning.'
                      : `Lead "${res.lead.name}" added.`
                  );
                })
              }
              onImportCsv={(csvText, campId) =>
                runAction(async () => {
                  const res = await api.importCsv(csvText, campId);
                  await refreshAll();
                  notify(`Imported ${res.imported} lead(s); ${res.duplicates} flagged for duplicate review.`);
                })
              }
              onUpdateStatus={(id: number, status: LeadStatus, purgePii?: boolean) =>
                runAction(async () => {
                  await api.updateLeadStatus(id, status, purgePii);
                  await refreshAll(id);
                  notify(`Lead marked ${status}.`);
                })
              }
              onOpenResearch={(id) => {
                loadLeadDetail(id);
                setScreen('research');
              }}
              onOpenStudio={(id) => {
                setSelectedLeadId(id);
                setScreen('studio');
              }}
            />
          )}

          {screen === 'research' && (
            <ResearchScreen
              leads={leads}
              selectedLeadId={selectedLeadId}
              detail={leadDetail}
              lang={lang}
              busy={busy}
              onSelectLead={(id) => loadLeadDetail(id)}
              onUpdateLeadStatus={(id, status) =>
                runAction(async () => {
                  await api.updateLeadStatus(id, status);
                  await refreshAll(id);
                  notify(`Lead status set to ${status}.`);
                })
              }
              onFetchOfficialUrl={(businessId, url) =>
                runAction(async () => {
                  await api.fetchOfficialUrl(businessId, url);
                  await refreshAll(businessId);
                  notify('Fetched page metadata as unverified candidates for your review.');
                })
              }
              onAddSource={(businessId, url, notes) =>
                runAction(async () => {
                  await api.addSource(businessId, { url, permitted_use_notes: notes });
                  await refreshAll(businessId);
                  notify('Source added.');
                })
              }
              onAddFact={(businessId, payload) =>
                runAction(async () => {
                  await api.addFact(businessId, payload);
                  await refreshAll(businessId);
                  notify('Fact recorded.');
                })
              }
              onUpdateFact={(factId, payload) =>
                runAction(async () => {
                  await api.updateFact(factId, payload);
                  await refreshAll(selectedLeadId);
                  notify('Fact updated.');
                })
              }
              onAddContact={(businessId, payload) =>
                runAction(async () => {
                  await api.addContact(businessId, payload);
                  await refreshAll(businessId);
                  notify('Contact saved.');
                })
              }
              onUpdateContact={(contactId, payload) =>
                runAction(async () => {
                  await api.updateContact(contactId, payload);
                  await refreshAll(selectedLeadId);
                  notify('Contact verification updated.');
                })
              }
              onAddPermission={(contactId, evidence) =>
                runAction(async () => {
                  await api.addPermission(contactId, { evidence });
                  await refreshAll(selectedLeadId);
                  notify('Permission evidence recorded.');
                })
              }
              onOpenStudio={(id) => {
                setSelectedLeadId(id);
                setScreen('studio');
              }}
            />
          )}

          {screen === 'studio' && (
            <StudioScreen
              leads={leads}
              websites={websites}
              selectedBusinessId={selectedLeadId}
              settings={settings}
              lang={lang}
              busy={busy}
              onSelectBusiness={(id) => setSelectedLeadId(id)}
              onGenerateWebsite={async (payload) => {
                let created: WebsiteRecord | null = null;
                await runAction(async () => {
                  const res = await api.generateWebsite(payload);
                  created = res.website;
                  await refreshAll(payload.business_id);
                  notify(res.ai_notice || `Demo v${res.website.version} generated & QA checked.`);
                });
                return created;
              }}
              onUpdateWebsite={(id, payload) =>
                runAction(async () => {
                  const res = await api.updateWebsite(id, payload);
                  await refreshAll();
                  notify(
                    res.revoked_prior_approval
                      ? 'Draft updated. Prior approval was automatically invalidated—reapproval required.'
                      : 'Draft updated and QA re-run.'
                  );
                })
              }
              onRefineWithAi={(id) =>
                runAction(async () => {
                  await api.refineWebsiteWithAi(id);
                  await refreshAll();
                  notify('AI copy draft applied for human review. Prior approval invalidated.');
                })
              }
              onRunQa={(id) =>
                runAction(async () => {
                  await api.runWebsiteQa(id);
                  await refreshAll();
                  notify('Automated QA completed.');
                })
              }
              onApproveWebsite={(id) =>
                runAction(async () => {
                  await api.approveWebsite(id);
                  await refreshAll();
                  notify('Website content hash approved.');
                })
              }
              onPublishReview={(id, publicUrl, markPublished) =>
                runAction(async () => {
                  await api.publishReviewWebsite(id, { public_url: publicUrl, mark_published: markPublished });
                  await refreshAll();
                  notify('Publish review updated.');
                })
              }
              onOpenOutreach={(bizId) => {
                setSelectedLeadId(bizId);
                setScreen('outreach');
              }}
            />
          )}

          {screen === 'outreach' && (
            <OutreachScreen
              leads={leads}
              websites={websites}
              messages={messages}
              settings={settings}
              lang={lang}
              busy={busy}
              onCreateDraft={(payload) =>
                runAction(async () => {
                  const res = await api.createOutreachDraft(payload);
                  await refreshAll();
                  notify(res.ai_notice || 'Outreach draft created for individual review.');
                })
              }
              onUpdateDraft={(id, payload) =>
                runAction(async () => {
                  const res = await api.updateOutreachDraft(id, payload);
                  await refreshAll();
                  notify(
                    res.revoked_prior_approval
                      ? 'Draft updated; prior approval invalidated.'
                      : 'Draft updated.'
                  );
                })
              }
              onApproveDraft={(id) =>
                runAction(async () => {
                  await api.approveOutreach(id);
                  await refreshAll();
                  notify('Exact message snapshot approved.');
                })
              }
              onManualSend={(id) =>
                runAction(async () => {
                  await api.manualSendOutreach(id);
                  await refreshAll();
                  notify('Manual send confirmed and recorded.');
                })
              }
              onRecordResponse={(id, outcome) =>
                runAction(async () => {
                  await api.recordOutreachResponse(id, outcome);
                  await refreshAll();
                  notify(
                    outcome === 'opt_out'
                      ? 'Opt-out recorded; contact suppressed and follow-ups cancelled.'
                      : `Outcome "${outcome}" logged.`
                  );
                })
              }
              onScheduleFollowup={(msgId, days) =>
                runAction(async () => {
                  await api.scheduleFollowup(msgId, days);
                  await refreshAll();
                  notify(`Follow-up draft queued (${days} days delay).`);
                })
              }
            />
          )}

          {screen === 'activity' && (
            <ActivityScreen
              tasks={tasks}
              suppressions={suppressions}
              audit={audit}
              lang={lang}
              busy={busy}
              onRunNextTask={() =>
                runAction(async () => {
                  const res = await api.runNextTask();
                  await refreshAll();
                  notify(res.ran ? `Executed ${res.task_type}` : res.message || 'Queue empty');
                })
              }
              onUpdateTaskStatus={(id, status) =>
                runAction(async () => {
                  await api.updateTaskStatus(id, status);
                  await refreshAll();
                  notify(`Task updated to ${status}.`);
                })
              }
              onAddSuppression={(contact, channel, reason) =>
                runAction(async () => {
                  await api.addSuppression({ contact, channel, reason });
                  await refreshAll();
                  notify('Opt-out suppression added; matching unsent drafts blocked.');
                })
              }
              onDeleteSuppression={(id) =>
                runAction(async () => {
                  await api.deleteSuppression(id);
                  await refreshAll();
                  notify('Suppression entry removed.');
                })
              }
            />
          )}

          {screen === 'settings' && (
            <SettingsScreen
              settings={settings}
              lang={lang}
              busy={busy}
              onSaveSettings={(payload) =>
                runAction(async () => {
                  const updated = await api.updateSettings(payload);
                  setSettings(updated);
                  setLang(updated.ui_language);
                  notify('Settings saved.');
                })
              }
              onRestoreBackup={(jsonObj) =>
                runAction(async () => {
                  const res = await api.restoreBackup(jsonObj);
                  await refreshAll();
                  notify(`Backup restored (${res.restored_rows} rows).`);
                })
              }
              onResetTrial={() =>
                runAction(async () => {
                  await api.resetDentalTrial();
                  await refreshAll();
                  notify('Section 9 Dental Trial reset cleanly.');
                })
              }
            />
          )}
        </main>
      </div>
    </div>
  );
}
