export type UiLanguage = 'en' | 'hi';
export type ContentLanguage = 'en' | 'hi' | 'bilingual';
export type OutputType = 'html' | 'react';
export type TemplateKey = 'universal' | 'dental' | 'jewellery' | 'salon' | 'restaurant';

export type LeadStatus = 'new' | 'researched' | 'review_required' | 'verified' | 'rejected';
export type VerificationStatus = 'verified' | 'unverified' | 'unknown';
export type ContactChannel = 'email' | 'whatsapp_link' | 'phone';
export type WebsiteStatus = 'draft' | 'qa_failed' | 'review_required' | 'approved' | 'publish_review' | 'published';
export type MessageStatus = 'draft' | 'review_required' | 'approved' | 'sending' | 'sent' | 'failed' | 'delivery_unknown' | 'suppressed' | 'cancelled';

export interface Campaign {
  id: number;
  name: string;
  area: string;
  category: string;
  language: ContentLanguage;
  output_type: OutputType;
  max_leads: number;
  status: 'active' | 'paused' | 'completed';
  created_at: string;
  updated_at: string;
  lead_count?: number;
}

export interface Business {
  id: number;
  name: string;
  category: string;
  locality: string;
  address: string;
  official_url: string;
  normalized_identity: string;
  review_status: LeadStatus;
  notes: string;
  created_at: string;
  updated_at: string;
  duplicate_warning?: string | null;
  campaign_id?: number;
  campaign_name?: string;
  primary_email?: string | null;
  email_status?: VerificationStatus;
  website_count?: number;
  latest_website_status?: WebsiteStatus | null;
  suppressed?: boolean;
}

export interface SourceRecord {
  id: number;
  business_id: number;
  url: string;
  retrieved_at: string;
  permitted_use_notes: string;
}

export interface FactRecord {
  id: number;
  business_id: number;
  field_name: string;
  value: string;
  source_id: number | null;
  source_url?: string | null;
  verified_at: string | null;
  verification_status: VerificationStatus;
  confidence: 'high' | 'medium' | 'low';
}

export interface ContactRecord {
  id: number;
  business_id: number;
  channel: ContactChannel;
  value: string;
  source_id: number | null;
  source_url?: string | null;
  verification_status: VerificationStatus;
  created_at: string;
  is_suppressed?: boolean;
  permission?: PermissionRecord | null;
}

export interface PermissionRecord {
  id: number;
  contact_id: number;
  channel: ContactChannel;
  scope: string;
  evidence: string;
  recorded_at: string;
  revoked_at: string | null;
}

export interface QaResultRecord {
  id: number;
  website_id: number;
  check_name: string;
  outcome: 'pass' | 'warning' | 'fail';
  details: string;
  checked_at: string;
}

export interface WebsiteRecord {
  id: number;
  business_id: number;
  business_name?: string;
  business_category?: string;
  business_locality?: string;
  campaign_id: number | null;
  version: number;
  template_key: TemplateKey;
  language: ContentLanguage;
  output_type: OutputType;
  headline: string;
  subheadline: string;
  about_copy: string;
  services_json: string;
  cta_label: string;
  content_hash: string;
  local_path: string;
  public_url: string;
  status: WebsiteStatus;
  created_at: string;
  updated_at: string;
  qa_results?: QaResultRecord[];
  active_approval?: ApprovalRecord | null;
}

export interface ApprovalRecord {
  id: number;
  entity_type: 'website' | 'message';
  entity_id: number;
  content_hash: string;
  approval_kind: 'website_review' | 'publish_review' | 'message_send';
  approved_by: string;
  approved_at: string;
  revoked_at: string | null;
  revoke_reason: string | null;
}

export interface MessageRecord {
  id: number;
  business_id: number;
  business_name?: string;
  campaign_id: number | null;
  contact_id: number | null;
  contact_value?: string | null;
  contact_channel?: ContactChannel | null;
  contact_verification_status?: VerificationStatus | null;
  website_id: number | null;
  website_status?: WebsiteStatus | null;
  website_public_url?: string | null;
  channel: 'email' | 'whatsapp_link';
  purpose: 'initial_demo' | 'follow_up';
  subject: string;
  body: string;
  attachment_note: string;
  content_hash: string;
  status: MessageStatus;
  follow_up_enabled: number;
  follow_up_days: number;
  created_at: string;
  updated_at: string;
  is_suppressed?: boolean;
  active_approval?: ApprovalRecord | null;
  blockers?: string[];
}

export interface SuppressionRecord {
  id: number;
  normalized_contact: string;
  channel: string;
  reason: string;
  created_at: string;
}

export interface TaskRecord {
  id: number;
  campaign_id: number | null;
  campaign_name?: string | null;
  business_id: number | null;
  business_name?: string | null;
  task_type: 'research_fetch' | 'website_build' | 'qa_check' | 'follow_up_draft';
  status: 'queued' | 'paused' | 'running' | 'completed' | 'failed' | 'cancelled';
  attempt_count: number;
  max_attempts: number;
  due_at: string;
  last_error: string | null;
  payload_json: string;
  created_at: string;
  updated_at: string;
}

export interface AuditEventRecord {
  id: number;
  entity_type: string;
  entity_id: number;
  action: string;
  actor: string;
  created_at: string;
  safe_metadata: string;
}

export interface AppSettings {
  ui_language: UiLanguage;
  ai_enabled: boolean;
  ai_available: boolean;
  followup_default_enabled: boolean;
  followup_days: number;
  agency_sender_name: string;
  agency_sender_email: string;
}

export interface OverviewSummary {
  campaigns_count: number;
  active_campaign: Campaign | null;
  leads_total: number;
  leads_verified: number;
  leads_review_required: number;
  websites_total: number;
  websites_needing_review: number;
  websites_approved: number;
  messages_awaiting_approval: number;
  messages_sent: number;
  suppressions_count: number;
  tasks_failed: number;
  tasks_queued: number;
  recent_audit: AuditEventRecord[];
}
