# Freshy AI — Bilingual Web Agency Workbench

Freshy AI is a full-stack, zero-budget agency operations workbench that guides a solo operator from city-and-category campaign setup and verified lead research to compliant demo website generation, automated quality checks, hash-locked approvals, and manual-first outreach with opt-out protection.

---

### User Review & Critical Decisions

> [!IMPORTANT]
> All core architectural and product preferences from Phase 1 are locked below. Review the scope and workflow safeguards before approving to begin implementation.

- **Confirmed Stack Adaptation**: Full-stack React, TypeScript, and Express application backed by a local file-based SQLite database (`data/`) and real downloadable ZIP exports for both plain HTML/CSS/JS and React/Vite website packages.
- **Confirmed Release Scope**: All 8 dashboard screens (`Overview`, `New Campaign`, `Leads`, `Research Detail`, `Website Studio`, `Outreach Review`, `Activity`, and `Settings`), including the full versioning/approval engine, opt-out suppression, automated QA checks, and database backup/restore.
- **Confirmed Copy Generation**: Deterministic business-fact templates by default, paired with an optional server-side Gemini (`gemini-4-hydrogen`) copy helper that requires explicit human review and never fabricates business claims, prices, hours, or reviews.
- **Confirmed Language & Aesthetic**: Instant `EN` / `HI` / `Bilingual` dashboard toggle with a crisp light editorial workspace theme, tabular metrics, and flat hairline-bordered surfaces.

---

### 1. Overview & Core Concept

- **What It Does**: Freshy AI manages the complete pre-sales website demo lifecycle for local businesses without unauthorized scraping or automated bulk spam. Operators define a campaign (area, business category, language, output target, lead cap), import or enter leads with source URLs, verify facts field-by-field, generate responsive HTML or React concept demos, run automated QA, approve snapshots via content hashes, prepare compliant outreach drafts, and track opt-outs and follow-ups.
- **Target Audience / Persona**: A solo local web agency builder operating on desktop in English and Hindi who needs strict factual accuracy, clear legal/consent boundaries, and reproducible exports.
- **Key Value**: Separates lead discovery, website creation, public publishing, and outreach into distinct approval gates—preventing accidental unverified claims, broken exports, or messaging suppressed contacts.

---

### 2. User Experience & Visual Design

- **Key User Flows**:
  1. **Zero-State & Trial Onboarding**: On first launch, the operator can immediately create a custom campaign or run the built-in **Sample Dental Studio** end-to-end trial preset (3 fictional leads, intentional missing email for QA testing, approval-invalidation check, and opt-out block verification).
  2. **Campaign & Leads Pipeline**: Create a campaign (`New Campaign`), add leads manually or import/export CSV (`Leads`), review duplicate warnings (normalized name + locality or contact), and transition leads through `new → researched → review_required → verified / rejected`.
  3. **Verified Research Desk**: Inspect each lead in `Research Detail` alongside its source URL, retrieval timestamp, and verification state (`verified`, `unverified`, `unknown`). Optionally run a safe user-triggered webpage metadata fetch on the business's official URL, keeping all third-party text sanitized and editable.
  4. **Website Studio & QA**: Choose a template (universal business-agnostic layout or dental/clinic, jewellery, salon, restaurant variants), toggle `EN` / `HI` / `Bilingual` copy, optionally refine prose via Gemini while leaving missing facts flagged rather than invented, inspect the live sandboxed preview, run the automated QA checker (structure, placeholder detection, broken links/assets, mobile/desktop overflow, contact links, `noindex`, and unofficial concept disclaimer), approve the exact content hash, and export a standalone HTML/CSS/JS or React/Vite ZIP. Any subsequent edit automatically revokes prior approval.
  5. **Outreach Review & Activity**: Generate recipient-specific email or permitted-WhatsApp drafts in `Outreach Review` (blocked automatically if recipient is missing, contact is unverified, demo URL/attachment requirement isn't met, or contact is suppressed). Approve exact recipient + body hash, confirm manual sending, log replies or opt-outs, and manage scheduled follow-up drafts (default off, max 1 draft after 5–7 days) and orchestrator jobs in `Activity`.
  6. **Settings & Backups**: Switch dashboard language (`EN` / `HI`), toggle optional AI copy assistance, manage the global opt-out suppression list, and perform one-click JSON/SQLite database backup and restore.

- **Visual Identity & Theme**:
  - *Aesthetic Direction*: Crisp Light Editorial Workbench—clean paper-white canvas, restrained structural surfaces, high information clarity, and zero ornamental clutter.
  - *Color Palette & Mood*:
    - `--background`: `#F8FAFC` (60% crisp cool-neutral canvas)
    - `--surface`: `#FFFFFF` with `1px solid #E2E8F0` hairline borders (30% structural surfaces, single-elevation depth)
    - `--foreground`: `#0F172A` primary ink, `#475569` secondary prose, `#64748B` muted metadata
    - `--primary`: `#0F766E` deep editorial teal (10% accent budget for primary CTAs and active navigation)
    - Semantic states paired with explicit text/icons: `#15803D` (Verified / Approved), `#B45309` (Review Required / Warning), `#B91C1C` (QA Failed / Blocked / Suppressed).
  - *Typography & Hierarchy*: `Plus Jakarta Sans` for display headings and navigation, `DM Sans` (with `Noto Sans Devanagari` webfont support for crisp Hindi script) for body prose, and `JetBrains Mono` with `tabular-nums` for hashes, IDs, timestamps, and metrics.
  - *Component Styling & Layout*: Fixed `256px` left sidebar for the 8 core screens, clean 3-zone top bar (`Freshy AI` wordmark · active screen breadcrumb & campaign context · single primary action + `EN / HI` workspace toggle in the toolbar below), compact `40px` data grid rows, unboxed metadata separated by `·`, and no nested card-in-card boxes or thick left accent stripes.

- **Interactive Feedback & Motion**:
  - Micro-interactions settle within `150ms–200ms` using `transform` and `opacity` transitions.
  - Every data view provides populated, empty (with primary action CTA), loading skeleton, and live filter/search states.
  - Toast notifications confirm saves, approval invalidations, suppression blocks, and ZIP/backup downloads.

---

### 3. Key Product Decisions & Trade-Offs

- **Local SQLite Persistence over In-Memory or External Cloud DB**:
  - *Chosen Approach*: Server-side SQLite file database managed by Express in `data/`, mirrored by full export/restore endpoints.
  - *Why*: Matches the zero-budget local agency philosophy, requires zero external accounts or paid hosting, and preserves all 15 normalized blueprint tables (`campaigns`, `businesses`, `campaign_businesses`, `sources`, `facts`, `contacts`, `permissions`, `websites`, `qa_results`, `messages`, `approvals`, `send_attempts`, `suppressions`, `tasks`, `audit_events`) across server restarts.
  - *Alternatives Considered*: Browser `localStorage` (rejected because server-side ZIP bundling, safe URL fetching, and atomic approval/idempotency checks need backend persistence).

- **Content-Hash Approval Gate & Reapproval Invalidation**:
  - *Chosen Approach*: Every website build and message draft computes a deterministic SHA-256 `content_hash` stored in `approvals`. Editing any website field, recipient, subject, or body updates the draft's hash, immediately marking prior approvals invalidated (`revoked_at`) and blocking export-publish or send confirmation until reapproved.
  - *Why*: Prevents stale approvals from authorizing modified copy, unverified numbers, or wrong recipients.

- **Deterministic Templates + Opt-In Server-Side Gemini Copy**:
  - *Chosen Approach*: Websites and outreach drafts always render cleanly using verified facts and deterministic bilingual templates without requiring AI. When enabled, a server-side Express route invokes `@google/genai` (`gemini-4-hydrogen`) strictly constrained to provided verified facts, flagging any missing fields as `unknown` rather than inventing claims.
  - *Why*: Ensures reliability when offline or operating at zero cost, while offering polished Hindi/English prose refinement when desired.

- **No Bulk Sending & Mandatory Suppression Checks**:
  - *Chosen Approach*: Removed any "approve all" or "message everyone" shortcuts. Each outreach draft requires explicit recipient verification, permission evidence, non-suppression check, and individual approval before manual-send logging.
  - *Why*: Enforces anti-spam discipline and keeps human judgment in the loop at every external touchpoint.

---

### 4. Technical Architecture & Data Strategy *(Technical Reference)*

- **Architecture & Component Diagram**:

```text
┌────────────────────────────────────────────────────────────────────────────┐
│  React Client Workspace (Vite + Tailwind CSS, EN / HI / Bilingual UI)      │
│  ┌──────────────┐  ┌────────────────────────────────────────────────────┐  │
│  │ 8-Screen Nav │  │ Active Screen Viewport                             │  │
│  │ • Overview   │  │ • Campaign Wizard & Orchestrator Controls          │  │
│  │ • Campaigns  │  │ • CSV Lead Importer + Duplicate Detector           │  │
│  │ • Leads      │  │ • Fact & Source Verifier                           │  │
│  │ • Research   │  │ • Website Studio (HTML/React Preview, QA, Hash)    │  │
│  │ • Studio     │  │ • Outreach Approval & Suppression Gate             │  │
│  │ • Outreach   │  │ • Activity Queue, Follow-ups & Backup Console      │  │
│  │ • Activity   │  └────────────────────────────────────────────────────┘  │
│  │ • Settings   │                          │                               │
└──┴──────────────┴──────────────────────────┼───────────────────────────────┘
                                             │ REST JSON + Binary Streams
┌────────────────────────────────────────────▼───────────────────────────────┐
│  Express API & Orchestration Server (Node.js / TypeScript, Port 3000)      │
│  ┌──────────────────────┐  ┌───────────────────────┐  ┌─────────────────┐  │
│  │ Core Modules         │  │ Template & Export     │  │ External / AI   │  │
│  │ • Lead Deduplication │  │ • HTML/CSS/JS Builder │  │ • Safe URL Fetch│  │
│  │ • Approval & Hashing │  │ • React/Vite Scaffolder│ │ • Gemini Copy   │  │
│  │ • QA Rule Engine     │  │ • ZIP Bundler         │  │   (Server-Only) │  │
│  │ • Suppression Guard  │  │ • JSON/DB Backup      │  └────────┬────────┘  │
│  │ • Job Orchestrator   │  └───────────────────────┘           │           │
│  └──────────┬───────────┘                                      │           │
│             ▼                                                  ▼           │
│  ┌──────────────────────────────────────────┐       ┌───────────────────┐  │
│  │ SQLite Database (15 Blueprint Tables)    │       │ @google/genai SDK │  │
│  │ Campaigns, Leads, Facts, Websites, QA,   │       │ (gemini-4-hydrogen│  │
│  │ Approvals, Messages, Suppressions, Audit │       │  via env secret)  │  │
│  └──────────────────────────────────────────┘       └───────────────────┘  │
└────────────────────────────────────────────────────────────────────────────┘
```

- **Data Model & State**:
  - *Discovery & Verification*: `campaigns` links to `businesses` through `campaign_businesses`. Every business connects to `sources` (URL + retrieval timestamp + permitted-use notes), `facts` (field name, value, verification status, source link), and `contacts` (`email`, `whatsapp_link`, `phone`, each strictly typed with `verification_status` so unverified phone numbers are never auto-converted into WhatsApp recipients).
  - *Websites & QA*: `websites` tracks version number, `output_type` (`html` | `react`), `content_hash`, generated bundle payload, `status` (`draft` → `qa_failed` / `review_required` → `approved` → `publish_review` → `published`), and linked `qa_results` rows.
  - *Approvals, Outreach & Compliance*: `approvals` binds `entity_type` + `entity_id` + `content_hash`. `messages` tracks `draft` → `review_required` → `approved` → `sending` → `sent` / `failed` / `delivery_unknown` / `suppressed` / `cancelled`, guarded by `permissions`, `suppressions`, and `send_attempts` (`idempotency_key`). `tasks` and `audit_events` record orchestrator runs and state transitions.

- **Interactive Component & State Mapping**:
  - *CSV Import & Deduplication*: Client parses/uploads CSV rows → server normalizes business identity and contact values, flags likely duplicates (`review_required`) without auto-merging, and persists valid rows.
  - *Safe Official URL Research Fetch*: User clicks "Fetch Official Metadata" → backend validates scheme (`http:`/`https:`), blocks loopback/private/link-local IP ranges and revalidates redirects, enforces timeout and byte-size limits, extracts page title/meta description/public links without executing scripts, and stores candidate facts marked `review_required`.
  - *Website Studio Edit & Reapproval Loop*: Editing any template, language, or copy field recalculates `content_hash` on save; if the hash differs from the active row in `approvals`, the server revokes the approval and resets status to `review_required`, locking ZIP publish/outreach linking until QA passes and the user re-approves.
  - *Outreach Pre-Send Guard*: Before marking a draft ready or confirming manual send, the server verifies: (1) recipient is non-empty and verified, (2) active `content_hash` matches `approvals`, (3) contact is absent from `suppressions`, (4) permission/channel policy checks pass, and (5) `idempotency_key` has not already been sent.

- **Security & Data Safeguards**:
  - Gemini API credentials remain strictly server-side (`process.env.GEMINI_API_KEY`) with zero client-side key exposure or key-entry UI.
  - All SQLite queries use parameterized prepared statements, and all imported or AI-assisted business text is HTML-escaped before entering generated website demos or previews.
  - Outbound research fetches enforce URL scheme allowlisting, private/local network blocking, redirect revalidation, response size limits, and request timeouts.
