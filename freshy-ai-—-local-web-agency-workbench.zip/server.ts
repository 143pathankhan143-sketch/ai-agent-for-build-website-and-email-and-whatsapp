import 'dotenv/config';
import express from 'express';
import fs from 'node:fs';
import path from 'node:path';
import { initDatabase } from './src/server/db.ts';
import { createApiRouter } from './src/server/routes.ts';

async function startServer() {
  initDatabase();

  const app = express();
  const PORT = 3000;

  app.use(express.json({ limit: '5mb' }));

  // Mount backend API routes
  app.use('/api', createApiRouter());

  // Explicitly serve generated demo images if requested in preview routes
  const assetsImagesDir = path.resolve(process.cwd(), 'src', 'assets', 'images');
  if (fs.existsSync(assetsImagesDir)) {
    app.use('/src/assets/images', express.static(assetsImagesDir));
  }

  const isProd = process.env.NODE_ENV === 'production';
  if (!isProd) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Freshy AI server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start Freshy AI server:', err);
  process.exit(1);
});
